/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.util.Formatting
 *  net.minecraft.text.Text
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.screen.ScreenTexts
 *  net.minecraft.client.gui.tooltip.Tooltip
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.Executor;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.account.OfflineAccount;
import mods.acountswiher.ru.vidtu.ias.auth.microsoft.MSAuth;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import mods.acountswiher.ru.vidtu.ias.screen.PopupBox;
import mods.acountswiher.ru.vidtu.ias.screen.PopupButton;
import net.minecraft.class_11908;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;

final class OfflinePopupScreen
extends class_437 {
    private final AccountScreen parent;
    private final Account original;
    private PopupBox name;
    private PopupButton done;
    private boolean locked;

    OfflinePopupScreen(AccountScreen parent, Account original) {
        super((class_2561)class_2561.method_43471((String)"ias.offline"));
        this.parent = parent;
        this.original = original;
    }

    protected void method_25426() {
        assert (this.field_22787 != null);
        this.method_37067();
        this.parent.method_25410(this.field_22789, this.field_22790);
        this.name = new PopupBox(this.field_22793, this.field_22789 / 2 - 75, this.field_22790 / 2 - 5, 148, 20, (class_2561)class_2561.method_43471((String)"ias.offline.nick"), this::save, false);
        this.name.method_1880(16);
        this.name.method_47404((class_2561)class_2561.method_43470((String)(this.original != null ? this.original.name() : "Steve")).method_27661().method_27692(class_124.field_1063));
        if (this.original != null) {
            this.name.method_1852(this.original.name());
        }
        this.name.method_1863(value -> this.updateButton(false));
        this.method_37063(this.name);
        this.done = new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 + 27, 74, 20, class_5244.field_24334, button -> this.save());
        this.done.color = new float[]{1.0f, 0.5f, 0.5f, 1.0f};
        this.method_37063(this.done);
        this.method_37063(new PopupButton(this.field_22789 / 2 + 1, this.field_22790 / 2 + 27, 74, 20, class_5244.field_24335, button -> this.method_25419()));
        this.updateButton(true);
    }

    public void method_25419() {
        this.field_22787.method_1507((class_437)this.parent);
    }

    public boolean method_25404(class_11908 event) {
        int keyCode = event.comp_4795();
        int scanCode = event.comp_4796();
        int modifiers = event.comp_4797();
        boolean result = super.method_25404(event);
        if (keyCode == 342 || keyCode == 346) {
            this.updateButton(false);
        }
        return result;
    }

    public boolean method_16803(class_11908 event) {
        int keyCode = event.comp_4795();
        int scanCode = event.comp_4796();
        int modifiers = event.comp_4797();
        boolean result = super.method_16803(event);
        if (keyCode == 342 || keyCode == 346) {
            this.updateButton(false);
        }
        return result;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_51448().pushMatrix();
        context.method_51448().scale(2.0f, 2.0f);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 4, this.field_22790 / 4 - 24, -1);
        context.method_51448().popMatrix();
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43471((String)"ias.offline.nick"), this.field_22789 / 2, this.field_22790 / 2 - 15, -1);
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent != null) {
            this.parent.method_47413(context, 0, 0, delta);
            context.method_25294(0, 0, this.field_22789, this.field_22790, Integer.MIN_VALUE);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        context.method_25294(centerX - 80, centerY - 50, centerX + 80, centerY + 50, -132112336);
        context.method_25294(centerX - 79, centerY - 51, centerX + 79, centerY - 50, -132112336);
        context.method_25294(centerX - 79, centerY + 50, centerX + 79, centerY + 51, -132112336);
    }

    private void save() {
        if (this.name == null) {
            return;
        }
        String value = this.name.method_1882().trim();
        if (value.isBlank()) {
            return;
        }
        int length = value.length();
        if (length < 3 || length > 16) {
            this.parent.addOrReplace(this.original, new OfflineAccount(value, null));
            this.method_25419();
            return;
        }
        for (int i = 0; i < length; ++i) {
            int c = value.codePointAt(i);
            if (c == 95 || c >= 48 && c <= 57 || c >= 97 && c <= 122 || c >= 65 && c <= 90) continue;
            this.parent.addOrReplace(this.original, new OfflineAccount(value, null));
            this.method_25419();
            return;
        }
        this.locked = true;
        this.updateButton(false);
        MSAuth.nameToMcp(value).whenCompleteAsync((profile, throwable) -> {
            UUID skin = profile != null ? profile.uuid() : null;
            this.parent.addOrReplace(this.original, new OfflineAccount(value, skin));
            if (this.field_22787 != null) {
                this.field_22787.method_1507((class_437)this.parent);
            }
        }, (Executor)this.field_22787);
    }

    private void updateButton(boolean instant) {
        if (this.done == null || this.name == null) {
            return;
        }
        if (this.locked) {
            this.done.field_22763 = false;
            this.name.field_22763 = false;
            this.done.method_47400(null);
            this.done.color = new float[]{0.5f, 0.5f, 0.5f, instant ? 1.0f : 0.0f};
            return;
        }
        String value = this.name.method_1882();
        this.name.field_22763 = true;
        if (value.isBlank()) {
            this.done.field_22763 = false;
            this.done.method_47400(class_7919.method_47407((class_2561)class_2561.method_43471((String)"ias.offline.nick.blank")));
            this.done.method_47402(Duration.ZERO);
            this.done.color = new float[]{1.0f, 0.5f, 0.5f, instant ? 1.0f : 0.0f};
            return;
        }
        int length = value.length();
        boolean alt = class_310.method_1551().method_74189();
        this.done.field_22763 = true;
        if (length < 3) {
            this.done.field_22763 = alt;
            this.done.method_47400(class_7919.method_47407((class_2561)class_2561.method_43469((String)"ias.offline.nick.short", (Object[])new Object[]{class_2561.method_43471((String)"key.keyboard.left.alt")})));
            this.done.method_47402(Duration.ZERO);
            this.done.color = new float[]{alt ? 0.75f : 1.0f, alt ? 0.75f : 1.0f, 0.25f, instant ? 1.0f : 0.0f};
            return;
        }
        if (length > 16) {
            this.done.field_22763 = alt;
            this.done.method_47400(class_7919.method_47407((class_2561)class_2561.method_43469((String)"ias.offline.nick.long", (Object[])new Object[]{class_2561.method_43471((String)"key.keyboard.left.alt")})));
            this.done.method_47402(Duration.ZERO);
            this.done.color = new float[]{alt ? 0.75f : 1.0f, alt ? 0.75f : 1.0f, 0.25f, instant ? 1.0f : 0.0f};
            return;
        }
        for (int i = 0; i < length; ++i) {
            int c = value.codePointAt(i);
            if (c == 95 || c >= 48 && c <= 57 || c >= 97 && c <= 122 || c >= 65 && c <= 90) continue;
            this.done.field_22763 = alt;
            this.done.method_47400(class_7919.method_47407((class_2561)class_2561.method_43469((String)"ias.offline.nick.chars", (Object[])new Object[]{Character.toString(c), class_2561.method_43471((String)"key.keyboard.left.alt")})));
            this.done.method_47402(Duration.ZERO);
            this.done.color = new float[]{alt ? 0.75f : 1.0f, alt ? 0.75f : 1.0f, 0.25f, instant ? 1.0f : 0.0f};
            return;
        }
        this.done.method_47400(null);
        this.done.color = new float[]{0.5f, 1.0f, 0.5f, instant ? 1.0f : 0.0f};
    }
}

