/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.DefaultSkinHelper
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Util
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.widget.TextFieldWidget
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.NoticeScreen
 *  net.minecraft.client.gui.screen.multiplayer.ConnectScreen
 *  net.minecraft.client.gui.widget.ButtonWidget
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.screen.ScreenTexts
 *  net.minecraft.client.network.ServerAddress
 *  net.minecraft.client.network.ServerInfo
 *  net.minecraft.client.network.ServerInfo$ServerType
 *  net.minecraft.client.gui.tooltip.Tooltip
 *  net.minecraft.client.gui.widget.PlayerSkinWidget
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import mods.acountswiher.IasService;
import mods.acountswiher.ru.vidtu.ias.IAS;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.account.OfflineAccount;
import mods.acountswiher.ru.vidtu.ias.auth.LoginData;
import mods.acountswiher.ru.vidtu.ias.config.IASServerShortcutsConfig;
import mods.acountswiher.ru.vidtu.ias.config.IASStorage;
import mods.acountswiher.ru.vidtu.ias.screen.AccountEntry;
import mods.acountswiher.ru.vidtu.ias.screen.AccountList;
import mods.acountswiher.ru.vidtu.ias.screen.AddPopupScreen;
import mods.acountswiher.ru.vidtu.ias.screen.DeletePopupScreen;
import mods.acountswiher.ru.vidtu.ias.screen.LoginPopupScreen;
import mods.acountswiher.ru.vidtu.ias.screen.ServerShortcutButton;
import net.minecraft.class_1068;
import net.minecraft.class_11908;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_403;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_7919;
import net.minecraft.class_8765;

public final class AccountScreen
extends class_437 {
    private final class_437 parent;
    private final List<ServerShortcut> serverShortcuts = new ArrayList<ServerShortcut>();
    private class_342 search;
    private AccountList list;
    private class_8765 skin;
    private class_4185 login;
    private class_4185 offlineLogin;
    private class_4185 edit;
    private class_4185 delete;

    public AccountScreen(class_437 parent) {
        super((class_2561)class_2561.method_43471((String)"ias.accounts"));
        this.parent = parent;
    }

    protected void method_25426() {
        assert (this.field_22787 != null);
        if (IAS.disabled()) {
            this.field_22787.method_1507((class_437)new class_403(this::method_25419, (class_2561)class_2561.method_43471((String)"ias.disabled.title").method_27661().method_27692(class_124.field_1061), (class_2561)class_2561.method_43471((String)"ias.disabled.text"), class_5244.field_24339, true));
            return;
        }
        if (!IASStorage.gameDisclaimerShown) {
            this.field_22787.method_1507((class_437)new class_403(() -> {
                try {
                    IAS.gameDisclaimerShownStorage();
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                this.field_22787.method_1507((class_437)this);
            }, (class_2561)class_2561.method_43471((String)"ias.disclaimer.title").method_27661().method_27692(class_124.field_1054), (class_2561)class_2561.method_43471((String)"ias.disclaimer.text"), class_5244.field_41873, false));
            return;
        }
        this.search = (class_342)this.method_37063(new class_342(this.field_22793, this.field_22789 / 2 - 75, 11, 150, 20, this.search, (class_2561)class_2561.method_43471((String)"ias.accounts.search")));
        this.search.method_47404((class_2561)class_2561.method_43471((String)"ias.accounts.search").method_27661().method_27692(class_124.field_1063));
        this.ensureServerShortcuts();
        this.addServerShortcutButtons();
        if (this.skin == null) {
            this.skin = new class_8765(85, 120, this.field_22787.method_31974(), () -> {
                AccountEntry selected = this.list != null ? this.list.getSelected() : null;
                return selected != null ? this.list.skin(selected) : class_1068.method_4648((UUID)class_156.field_25140);
            });
        }
        this.skin.method_46421(5);
        this.skin.method_46419(this.field_22790 / 2 - 60);
        this.method_37063(this.skin);
        this.login = (class_4185)this.method_37063(class_4185.method_46430((class_2561)class_2561.method_43471((String)"ias.accounts.login"), button -> this.list.login(true)).method_46434(this.field_22789 / 2 - 154, this.field_22790 - 48, 100, 20).method_46431());
        this.offlineLogin = (class_4185)this.method_37063(class_4185.method_46430((class_2561)class_2561.method_43471((String)"ias.accounts.offlineLogin"), button -> this.list.login(false)).method_46434(this.field_22789 / 2 - 154, this.field_22790 - 24, 100, 20).method_46431());
        this.edit = (class_4185)this.method_37063(class_4185.method_46430((class_2561)class_2561.method_43471((String)"ias.accounts.edit"), button -> this.list.edit()).method_46434(this.field_22789 / 2 - 50, this.field_22790 - 48, 100, 20).method_46431());
        this.delete = (class_4185)this.method_37063(class_4185.method_46430((class_2561)class_2561.method_43471((String)"ias.accounts.delete"), button -> this.list.delete(!class_310.method_1551().method_74187())).method_46434(this.field_22789 / 2 - 50, this.field_22790 - 24, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430((class_2561)class_2561.method_43471((String)"ias.accounts.add"), button -> this.list.add()).method_46434(this.field_22789 / 2 + 54, this.field_22790 - 48, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430((class_2561)class_5244.field_24339, button -> this.method_25419()).method_46434(this.field_22789 / 2 + 54, this.field_22790 - 24, 100, 20).method_46431());
        this.list = new AccountList(this, this.field_22787, this.field_22789, this.field_22790 - 24 - 24 - 4 - 34, 34, 12);
        this.method_37063(this.list);
        this.search.method_1863(this.list::update);
        this.list.update(this.search.method_1882());
        this.updateSelected();
    }

    public void method_25419() {
        assert (this.field_22787 != null);
        this.field_22787.method_1507(this.parent);
    }

    public void method_25432() {
        super.method_25432();
        this.serverShortcuts.clear();
    }

    public boolean method_25404(class_11908 event) {
        AccountEntry selected;
        int keyCode = event.comp_4795();
        int scanCode = event.comp_4796();
        int modifiers = event.comp_4797();
        boolean shift = class_310.method_1551().method_74187();
        boolean control = class_310.method_1551().method_74188();
        if (keyCode == 264 && shift || keyCode == 267) {
            this.list.swapDown(this.list.getSelected());
            return true;
        }
        if (keyCode == 265 && shift || keyCode == 266) {
            this.list.swapUp(this.list.getSelected());
            return true;
        }
        if (keyCode == 67 && control && (selected = this.list.getSelected()) != null && this.field_22787 != null) {
            Account account = selected.account();
            this.field_22787.field_1774.method_1455(shift ? account.uuid().toString() : account.name());
            return true;
        }
        if (super.method_25404(event)) {
            return true;
        }
        if (keyCode == 257 || keyCode == 335) {
            this.list.login(!shift);
            return true;
        }
        if (keyCode == 261 || keyCode == 333) {
            this.list.delete(!shift);
            return true;
        }
        if (keyCode == 78 && control || keyCode == 334) {
            this.list.add();
            return true;
        }
        if (keyCode == 82 && control || keyCode == 332) {
            this.list.edit();
            return true;
        }
        return false;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 1, -1);
    }

    class_342 search() {
        return this.search;
    }

    void refresh() {
        this.list.update(this.search != null ? this.search.method_1882() : "");
        this.updateSelected();
    }

    void addOrReplace(Account original, Account replacement) {
        List<Account> accounts = IasService.accounts();
        int index = original != null ? accounts.indexOf(original) : -1;
        accounts.removeIf(Predicate.isEqual(replacement));
        if (original != null) {
            accounts.remove(original);
        }
        if (index >= 0 && index <= accounts.size()) {
            accounts.add(index, replacement);
        } else {
            accounts.add(replacement);
        }
        IasService.replaceRememberedAccount(original, replacement);
        IAS.saveStorage();
        this.refresh();
    }

    void login(Account account, boolean online) {
        if (!online || account instanceof OfflineAccount || !account.canLogin()) {
            IasService.rememberLastAccount(account, false);
            IasService.apply(new LoginData(account.name(), OfflineAccount.uuid(account.name()), "ias:offline", false));
            return;
        }
        assert (this.field_22787 != null);
        this.field_22787.method_1507((class_437)new LoginPopupScreen(this, account));
    }

    void openEdit(Account account) {
        assert (this.field_22787 != null);
        this.field_22787.method_1507((class_437)new AddPopupScreen(this, true, account));
    }

    void openDelete(Account account, boolean confirm) {
        if (!confirm) {
            IasService.remove(account);
            this.refresh();
            return;
        }
        assert (this.field_22787 != null);
        this.field_22787.method_1507((class_437)new DeletePopupScreen(this, account));
    }

    void openAdd() {
        assert (this.field_22787 != null);
        this.field_22787.method_1507((class_437)new AddPopupScreen(this, false, null));
    }

    void updateSelected() {
        AccountEntry selected;
        AccountEntry accountEntry = selected = this.list != null ? this.list.getSelected() : null;
        if (selected == null) {
            this.login.field_22763 = false;
            this.offlineLogin.field_22763 = false;
            this.edit.field_22763 = false;
            this.delete.field_22763 = false;
            this.login.method_47400(null);
            this.skin.field_22764 = false;
            return;
        }
        this.offlineLogin.field_22763 = true;
        this.edit.field_22763 = true;
        this.delete.field_22763 = true;
        if (selected.account().canLogin()) {
            this.login.field_22763 = true;
            this.login.method_47400(null);
        } else {
            this.login.field_22763 = false;
            this.login.method_47400(class_7919.method_47407((class_2561)class_2561.method_43471((String)"ias.accounts.login.offline")));
            this.login.method_47402(Duration.ZERO);
        }
        this.skin.field_22764 = true;
    }

    private void addServerShortcutButtons() {
        int startX = 8;
        int y = 8;
        int size = 18;
        int gap = 2;
        for (int i = 0; i < this.serverShortcuts.size(); ++i) {
            ServerShortcut shortcut = this.serverShortcuts.get(i);
            ServerShortcutButton shortcutButton = new ServerShortcutButton(startX + i * (size + gap), y, shortcut::textureId, shortcut.name(), pressedButton -> this.connectToShortcut(shortcut));
            shortcutButton.method_47400(class_7919.method_47407((class_2561)class_2561.method_43470((String)shortcut.name())));
            shortcutButton.method_47402(Duration.ZERO);
            this.method_37063(shortcutButton);
        }
    }

    private void ensureServerShortcuts() {
        if (!this.serverShortcuts.isEmpty()) {
            return;
        }
        for (IASServerShortcutsConfig.ShortcutEntry spec : IASServerShortcutsConfig.load(IAS.configDirectory())) {
            ServerShortcut shortcut = new ServerShortcut(spec.name(), spec.address(), this.textureId(spec.icon()));
            this.serverShortcuts.add(shortcut);
        }
    }

    private class_2960 textureId(String icon) {
        return class_2960.method_60655((String)"ias", (String)("textures/gui/server_shortcuts/" + icon + ".png"));
    }

    private void connectToShortcut(ServerShortcut shortcut) {
        assert (this.field_22787 != null);
        class_642 serverInfo = new class_642(shortcut.name(), shortcut.address(), class_642.class_8678.field_45611);
        try {
            class_412.method_36877((class_437)this, (class_310)this.field_22787, (class_639)class_639.method_2950((String)shortcut.address()), (class_642)serverInfo, (boolean)false, null);
        }
        catch (Throwable throwable) {
            this.field_22787.method_1507((class_437)new class_403(() -> this.field_22787.method_1507((class_437)this), (class_2561)class_2561.method_43470((String)shortcut.name()).method_27661().method_27692(class_124.field_1061), (class_2561)class_2561.method_43471((String)"multiplayer.status.cannot_connect"), class_5244.field_24339, true));
        }
    }

    private static final class ServerShortcut {
        private final String name;
        private final String address;
        private final class_2960 textureId;

        private ServerShortcut(String name, String address, class_2960 textureId) {
            this.name = name;
            this.address = address;
            this.textureId = textureId;
        }

        private String name() {
            return this.name;
        }

        private String address() {
            return this.address;
        }

        private class_2960 textureId() {
            return this.textureId;
        }
    }
}

