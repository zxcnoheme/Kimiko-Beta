/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.RenderPipelines
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.widget.ButtonWidget
 *  net.minecraft.client.gui.widget.ButtonWidget$PressAction
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.util.Locale;
import java.util.function.Supplier;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public final class ServerShortcutButton
extends class_4185 {
    private final Supplier<class_2960> textureSupplier;
    private final String label;

    public ServerShortcutButton(int x, int y, Supplier<class_2960> textureSupplier, String name, class_4185.class_4241 onPress) {
        super(x, y, 18, 18, net.minecraft.class_2561.method_43473(), onPress, field_40754);
        this.textureSupplier = textureSupplier;
        this.label = ServerShortcutButton.initials(name);
    }

    protected void method_75752(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        int x = this.method_46426();
        int y = this.method_46427();
        this.method_75794(context);
        class_2960 texture = this.textureSupplier.get();
        if (ServerShortcutButton.hasTexture(texture)) {
            context.method_25302(class_10799.field_56883, texture, x + 1, y + 1, 0.0f, 0.0f, 16, 16, 64, 64, 64, 64);
        } else {
            class_310 mc = class_310.method_1551();
            context.method_25300(mc.field_1772, this.label, x + 9, y + 6, -1);
        }
    }

    private static boolean hasTexture(class_2960 id) {
        if (id == null) {
            return false;
        }
        try {
            return class_310.method_1551().method_1478().method_14486(id).isPresent();
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static String initials(String name) {
        if (name == null || name.isBlank()) {
            return "?";
        }
        String s = name.trim();
        StringBuilder out = new StringBuilder(2);
        for (int i = 0; i < s.length() && out.length() < 2; ++i) {
            char c = s.charAt(i);
            if (!Character.isLetterOrDigit(c)) continue;
            out.append(Character.toUpperCase(c));
        }
        return out.length() == 0 ? s.substring(0, 1).toUpperCase(Locale.ROOT) : out.toString();
    }
}

