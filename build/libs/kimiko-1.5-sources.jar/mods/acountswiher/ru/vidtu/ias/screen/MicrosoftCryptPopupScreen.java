/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.text.Text
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.screen.ScreenTexts
 *  net.minecraft.client.gui.tooltip.Tooltip
 *  org.lwjgl.glfw.GLFW
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.time.Duration;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.config.IASConfig;
import mods.acountswiher.ru.vidtu.ias.crypt.DummyCrypt;
import mods.acountswiher.ru.vidtu.ias.crypt.HardwareCrypt;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import mods.acountswiher.ru.vidtu.ias.screen.MicrosoftPopupScreen;
import mods.acountswiher.ru.vidtu.ias.screen.PopupButton;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import org.lwjgl.glfw.GLFW;

final class MicrosoftCryptPopupScreen
extends class_437 {
    private final AccountScreen parent;
    private final Account original;
    private PopupButton plain;

    MicrosoftCryptPopupScreen(AccountScreen parent, Account original) {
        super((class_2561)class_2561.method_43471((String)"ias.microsoft"));
        this.parent = parent;
        this.original = original;
    }

    protected void method_25426() {
        assert (this.field_22787 != null);
        this.method_37067();
        this.parent.method_25410(this.field_22789, this.field_22790);
        PopupButton password = new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 - 36, 150, 20, (class_2561)class_2561.method_43471((String)"ias.microsoft.password"), button -> this.field_22787.method_1507((class_437)new MicrosoftPopupScreen(this.parent, this.original, null)));
        password.method_47400(class_7919.method_47407((class_2561)class_2561.method_43471((String)"ias.microsoft.password.tip")));
        password.method_47402(Duration.ofMillis(250L));
        password.color = new float[]{0.5f, 1.0f, 0.5f, 1.0f};
        this.method_37063(password);
        PopupButton hardware = new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 - 12, 150, 20, (class_2561)class_2561.method_43471((String)"ias.microsoft.hardware"), button -> this.field_22787.method_1507((class_437)new MicrosoftPopupScreen(this.parent, this.original, HardwareCrypt.INSTANCE_V2)));
        hardware.method_47400(class_7919.method_47407((class_2561)class_2561.method_43471((String)"ias.microsoft.hardware.tip")));
        hardware.method_47402(Duration.ofMillis(250L));
        hardware.color = new float[]{1.0f, 1.0f, 0.5f, 1.0f};
        this.method_37063(hardware);
        this.plain = new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 + 12, 150, 20, (class_2561)class_2561.method_43471((String)"ias.microsoft.plain"), button -> this.field_22787.method_1507((class_437)new MicrosoftPopupScreen(this.parent, this.original, DummyCrypt.INSTANCE)));
        if (IASConfig.allowNoCrypt) {
            this.plain.method_47400(class_7919.method_47407((class_2561)class_2561.method_43469((String)"ias.microsoft.plain.tip.off", (Object[])new Object[]{class_2561.method_43471((String)"key.keyboard.left.alt"), class_2561.method_43470((String)String.valueOf(GLFW.glfwGetKeyName((int)89, (int)-1)))})));
        } else {
            this.plain.method_47400(class_7919.method_47407((class_2561)class_2561.method_43471((String)"ias.microsoft.plain.tip.no")));
        }
        this.plain.method_47402(Duration.ofMillis(250L));
        this.plain.color = new float[]{1.0f, 0.5f, 0.5f, 1.0f};
        this.plain.field_22763 = false;
        this.method_37063(this.plain);
        this.method_37063(new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 + 57, 150, 20, class_5244.field_24335, button -> this.method_25419()));
    }

    public void method_25419() {
        assert (this.field_22787 != null);
        this.field_22787.method_1507((class_437)this.parent);
    }

    public boolean method_25404(class_11908 event) {
        int keyCode = event.comp_4795();
        int scanCode = event.comp_4796();
        int modifiers = event.comp_4797();
        if (keyCode == 89 && IASConfig.allowNoCrypt && this.plain != null && !this.plain.field_22763 && class_310.method_1551().method_74189()) {
            this.plain.field_22763 = true;
            this.plain.method_47400(class_7919.method_47407((class_2561)class_2561.method_43471((String)"ias.microsoft.plain.tip.on")));
            this.plain.method_47402(Duration.ofMillis(250L));
            this.plain.color = new float[]{1.0f, 0.25f, 0.25f, 0.0f};
        }
        return super.method_25404(event);
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_51448().pushMatrix();
        context.method_51448().scale(2.0f, 2.0f);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 4, this.field_22790 / 4 - 39, -1);
        context.method_51448().popMatrix();
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent != null) {
            this.parent.method_47413(context, 0, 0, delta);
            context.method_25294(0, 0, this.field_22789, this.field_22790, Integer.MIN_VALUE);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        context.method_25294(centerX - 80, centerY - 80, centerX + 80, centerY + 80, -132112336);
        context.method_25294(centerX - 79, centerY - 81, centerX + 79, centerY - 80, -132112336);
        context.method_25294(centerX - 79, centerY + 80, centerX + 79, centerY + 81, -132112336);
    }
}

