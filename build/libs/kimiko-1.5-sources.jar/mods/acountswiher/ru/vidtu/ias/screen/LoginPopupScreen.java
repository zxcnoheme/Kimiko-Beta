/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Formatting
 *  net.minecraft.text.Text
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.screen.ScreenTexts
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.util.concurrent.CompletableFuture;
import mods.acountswiher.IasService;
import mods.acountswiher.ru.vidtu.ias.IAS;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.auth.LoginData;
import mods.acountswiher.ru.vidtu.ias.auth.handlers.LoginHandler;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import mods.acountswiher.ru.vidtu.ias.screen.MultiLineLabelCompat;
import mods.acountswiher.ru.vidtu.ias.screen.PopupBox;
import mods.acountswiher.ru.vidtu.ias.screen.PopupButton;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5244;

final class LoginPopupScreen
extends class_437
implements LoginHandler {
    private final AccountScreen parent;
    private final Account account;
    private final Object lock = new Object();
    private class_2561 stage = class_2561.method_43471((String)"ias.login.initializing").method_27661().method_27692(class_124.field_1054);
    private MultiLineLabelCompat label = MultiLineLabelCompat.EMPTY;
    private PopupBox password;
    private CompletableFuture<String> passwordFuture;
    private MultiLineLabelCompat passwordTip = MultiLineLabelCompat.EMPTY;
    private MultiLineLabelCompat errorNote = MultiLineLabelCompat.EMPTY;
    private float error = Float.NaN;
    private boolean started;

    LoginPopupScreen(AccountScreen parent, Account account) {
        super((class_2561)class_2561.method_43471((String)"ias.login"));
        this.parent = parent;
        this.account = account;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    protected void method_25426() {
        assert (this.field_22787 != null);
        this.method_37067();
        this.parent.method_25410(this.field_22789, this.field_22790);
        Object object = this.lock;
        synchronized (object) {
            this.label = MultiLineLabelCompat.EMPTY;
        }
        this.method_37063(new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 + 52, 150, 20, class_5244.field_24335, button -> this.method_25419()));
        if (this.passwordFuture != null) {
            this.password = new PopupBox(this.field_22793, this.field_22789 / 2 - 100, this.field_22790 / 2 - 5, 178, 20, this.password, (class_2561)class_2561.method_43471((String)"ias.password"), this::submitPassword, true);
            this.password.method_1880(32);
            this.password.method_47404((class_2561)class_2561.method_43471((String)"ias.password.hint").method_27661().method_27692(class_124.field_1063));
            this.method_37063(this.password);
            PopupButton enter = new PopupButton(this.field_22789 / 2 + 80, this.field_22790 / 2 - 5, 20, 20, (class_2561)class_2561.method_43470((String)">>"), button -> this.submitPassword());
            enter.field_22763 = !this.password.method_1882().isBlank();
            this.password.method_1863(value -> {
                enter.field_22763 = !value.isBlank();
            });
            this.method_37063(enter);
            this.passwordTip = MultiLineLabelCompat.create(this.field_22793, (class_2561)class_2561.method_43471((String)"ias.password.tip").method_27661().method_27692(class_124.field_1054), 320);
        } else {
            this.password = null;
            this.passwordTip = MultiLineLabelCompat.EMPTY;
        }
        if (!this.started) {
            this.started = true;
            IAS.executor().execute(() -> this.account.login(this));
        }
    }

    @Override
    public boolean cancelled() {
        return this.field_22787 == null || this.field_22787.field_1755 != this;
    }

    @Override
    public void stage(String stage, Object ... args) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 != this) {
                return;
            }
            Object object = this.lock;
            synchronized (object) {
                this.stage = class_2561.method_43469((String)stage, (Object[])args).method_27661().method_27692(class_124.field_1054);
                this.label = MultiLineLabelCompat.EMPTY;
            }
        });
    }

    @Override
    public CompletableFuture<String> password() {
        if (this.passwordFuture != null) {
            return this.passwordFuture;
        }
        this.passwordFuture = new CompletableFuture();
        this.passwordFuture.whenComplete((value, throwable) -> {
            this.password = null;
            this.passwordTip = MultiLineLabelCompat.EMPTY;
            this.passwordFuture = null;
            if (this.field_22787 != null) {
                this.field_22787.execute(this::method_25426);
            }
        });
        if (this.field_22787 != null) {
            this.field_22787.execute(this::method_25426);
        }
        return this.passwordFuture;
    }

    @Override
    public void success(LoginData data, boolean changed) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 != this) {
                return;
            }
            if (data == null) {
                this.method_25419();
                return;
            }
            IasService.rememberLastAccount(this.account, data.online());
            IasService.apply(data);
            IasService.saveIfChanged(changed);
            this.method_25419();
        });
    }

    @Override
    public void error(Throwable error) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 != this) {
                return;
            }
            Object object = this.lock;
            synchronized (object) {
                this.stage = class_2561.method_43471((String)"ias.error").method_27661().method_27692(class_124.field_1061);
                this.label = MultiLineLabelCompat.EMPTY;
                this.error = 1.0f;
            }
        });
    }

    public void method_25419() {
        if (this.passwordFuture != null && !this.passwordFuture.isDone()) {
            this.passwordFuture.complete(null);
        }
        if (this.field_22787 != null) {
            this.field_22787.method_1507((class_437)this.parent);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        MultiLineLabelCompat currentLabel;
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_51448().pushMatrix();
        context.method_51448().scale(2.0f, 2.0f);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 4, this.field_22790 / 4 - 37, -1);
        context.method_51448().popMatrix();
        if (this.passwordFuture != null && this.password != null) {
            context.method_27534(this.field_22793, this.password.method_25369(), this.field_22789 / 2, this.field_22790 / 2 - 15, -1);
            this.passwordTip.renderCentered(context, this.field_22789 / 2, this.field_22790 / 2 + 22);
            return;
        }
        Object object = this.lock;
        synchronized (object) {
            if (this.label == MultiLineLabelCompat.EMPTY) {
                this.label = MultiLineLabelCompat.create(this.field_22793, this.stage, 240);
            }
            currentLabel = this.label;
        }
        currentLabel.renderCentered(context, this.field_22789 / 2, (this.field_22790 - currentLabel.getLineCount() * 9) / 2 - 4);
        if (Float.isFinite(this.error)) {
            if (this.errorNote == MultiLineLabelCompat.EMPTY) {
                this.errorNote = MultiLineLabelCompat.create(this.field_22793, (class_2561)class_2561.method_43471((String)"ias.error.note").method_27661().method_27692(class_124.field_1075), 245);
            }
            this.errorNote.renderCentered(context, this.field_22789 / 2, this.field_22790 / 2 + 87);
        }
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent != null) {
            this.parent.method_47413(context, 0, 0, delta);
            context.method_25294(0, 0, this.field_22789, this.field_22790, Integer.MIN_VALUE);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        context.method_25294(centerX - 125, centerY - 75, centerX + 125, centerY + 75, -132112336);
        context.method_25294(centerX - 124, centerY - 76, centerX + 124, centerY - 75, -132112336);
        context.method_25294(centerX - 124, centerY + 75, centerX + 124, centerY + 76, -132112336);
    }

    private void submitPassword() {
        if (this.password == null || this.passwordFuture == null) {
            return;
        }
        String value = this.password.method_1882();
        if (value.isBlank()) {
            return;
        }
        this.passwordFuture.complete(value);
    }
}

