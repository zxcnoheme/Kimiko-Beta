/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.util.DefaultSkinHelper
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.widget.EntryListWidget$Entry
 *  net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget
 *  net.minecraft.entity.player.SkinTextures
 *  org.jetbrains.annotations.Nullable
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import com.mojang.authlib.GameProfile;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import mods.acountswiher.IasService;
import mods.acountswiher.ru.vidtu.ias.IAS;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.config.IASStorage;
import mods.acountswiher.ru.vidtu.ias.screen.AccountEntry;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import net.minecraft.class_1068;
import net.minecraft.class_310;
import net.minecraft.class_4280;
import net.minecraft.class_8685;
import org.jetbrains.annotations.Nullable;

final class AccountList
extends class_4280<AccountEntry> {
    private static final Map<UUID, class_8685> SKINS = new WeakHashMap<UUID, class_8685>(4);
    private final AccountScreen screen;

    AccountList(AccountScreen screen, class_310 client, int width, int height, int offset, int itemHeight) {
        super(client, width, height, offset, itemHeight);
        this.screen = screen;
        this.update(this.screen.search() != null ? this.screen.search().method_1882() : "");
    }

    public int method_25322() {
        return Math.min(super.method_25322(), this.screen.field_22789 - 190);
    }

    public void setSelected(@Nullable AccountEntry entry) {
        super.method_25313(entry);
        this.screen.updateSelected();
    }

    @Nullable
    public AccountEntry getSelected() {
        return (AccountEntry)super.method_25334();
    }

    void update(String query) {
        AccountEntry selected = this.getSelected();
        if (query == null || query.isBlank()) {
            this.method_25314(IASStorage.ACCOUNTS.stream().map(account -> new AccountEntry(this.field_22740, this, (Account)account)).toList());
        } else {
            String lowerQuery = query.toLowerCase(Locale.ROOT);
            this.method_25314(IASStorage.ACCOUNTS.stream().filter(account -> account.name().toLowerCase(Locale.ROOT).contains(lowerQuery)).sorted((first, second) -> Boolean.compare(second.name().toLowerCase(Locale.ROOT).startsWith(lowerQuery), first.name().toLowerCase(Locale.ROOT).startsWith(lowerQuery))).map(account -> new AccountEntry(this.field_22740, this, (Account)account)).toList());
        }
        this.setSelected(this.wirst$restoreSelection(selected));
        this.screen.updateSelected();
    }

    void login(boolean online) {
        AccountEntry selected = this.getSelected();
        if (selected != null) {
            this.screen.login(selected.account(), online);
        }
    }

    void edit() {
        AccountEntry selected = this.getSelected();
        if (selected != null) {
            this.screen.openEdit(selected.account());
        }
    }

    void delete(boolean confirm) {
        AccountEntry selected = this.getSelected();
        if (selected != null) {
            this.screen.openDelete(selected.account(), confirm);
        }
    }

    void add() {
        this.screen.openAdd();
    }

    class_8685 skin(AccountEntry entry) {
        UUID uuid = entry.account().skin();
        class_8685 skin = SKINS.get(uuid);
        if (skin != null) {
            return skin;
        }
        skin = class_1068.method_4648((UUID)uuid);
        SKINS.put(uuid, skin);
        if (uuid.version() != 4) {
            return skin;
        }
        GameProfile profile = new GameProfile(entry.account().skin(), entry.account().name());
        ((CompletableFuture)this.field_22740.method_1582().method_52863(profile).thenAcceptAsync(optional -> optional.ifPresent(loaded -> SKINS.put(uuid, (class_8685)loaded)), (Executor)this.field_22740)).exceptionally(throwable -> null);
        return skin;
    }

    void swapUp(AccountEntry entry) {
        int index = this.method_25396().indexOf((Object)entry);
        if (index < 0 || index >= IASStorage.ACCOUNTS.size()) {
            return;
        }
        int upIndex = index - 1;
        if (upIndex < 0) {
            return;
        }
        IASStorage.ACCOUNTS.set(index, IASStorage.ACCOUNTS.get(upIndex));
        IASStorage.ACCOUNTS.set(upIndex, entry.account());
        this.saveStorage();
        this.method_25396().set(index, (AccountEntry)((Object)this.method_25396().get(upIndex)));
        this.method_25396().set(upIndex, entry);
        this.setSelected(entry);
    }

    void swapDown(AccountEntry entry) {
        int index = this.method_25396().indexOf((Object)entry);
        if (index < 0 || index >= IASStorage.ACCOUNTS.size()) {
            return;
        }
        int downIndex = index + 1;
        if (downIndex >= this.method_25396().size() || downIndex >= IASStorage.ACCOUNTS.size()) {
            return;
        }
        IASStorage.ACCOUNTS.set(index, IASStorage.ACCOUNTS.get(downIndex));
        IASStorage.ACCOUNTS.set(downIndex, entry.account());
        this.saveStorage();
        this.method_25396().set(index, (AccountEntry)((Object)this.method_25396().get(downIndex)));
        this.method_25396().set(downIndex, entry);
        this.setSelected(entry);
    }

    private void saveStorage() {
        try {
            IAS.disclaimersStorage();
            IAS.saveStorage();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private AccountEntry wirst$restoreSelection(@Nullable AccountEntry previous) {
        if (previous != null) {
            for (AccountEntry entry : this.method_25396()) {
                if (!entry.equals((Object)previous)) continue;
                return entry;
            }
        }
        for (AccountEntry entry : this.method_25396()) {
            if (!IasService.isRememberedAccount(entry.account())) continue;
            return entry;
        }
        return null;
    }
}

