/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.text.StringVisitable
 *  net.minecraft.text.OrderedText
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public final class MultiLineLabelCompat {
    public static final MultiLineLabelCompat EMPTY = new MultiLineLabelCompat(null, List.of());
    private final class_327 font;
    private final List<class_5481> lines;

    private MultiLineLabelCompat(class_327 font, List<class_5481> lines) {
        this.font = font;
        this.lines = lines;
    }

    public static MultiLineLabelCompat create(class_327 font, class_2561 text, int width) {
        return new MultiLineLabelCompat(font, font.method_1728((class_5348)text, width));
    }

    public int getLineCount() {
        return this.lines.size();
    }

    public void renderCentered(class_332 graphics, int x, int y) {
        if (this.font == null) {
            return;
        }
        int yy = y;
        for (class_5481 line : this.lines) {
            graphics.method_35719(this.font, line, x, yy, -1);
            yy += 9;
        }
    }
}

