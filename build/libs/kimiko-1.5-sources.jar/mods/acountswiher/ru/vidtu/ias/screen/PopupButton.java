/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.client.gui.widget.ButtonWidget
 *  net.minecraft.client.gui.widget.ButtonWidget$PressAction
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;

final class PopupButton
extends class_4185 {
    float[] color = new float[]{1.0f, 1.0f, 1.0f, 0.0f};
    private float currentRed = 1.0f;
    private float currentGreen = 1.0f;
    private float currentBlue = 1.0f;
    private float multiplier = 1.0f;

    PopupButton(int x, int y, int width, int height, net.minecraft.class_2561 text, class_4185.class_4241 onPress) {
        super(x, y, width, height, text, onPress, field_40754);
    }

    protected void method_75752(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        float shade = 0.78f;
        this.multiplier = this.method_25367() && this.field_22763 ? class_3532.method_15363((float)(this.multiplier - deltaTicks * 0.25f), (float)0.75f, (float)1.0f) : class_3532.method_15363((float)(this.multiplier + deltaTicks * 0.25f), (float)0.75f, (float)1.0f);
        if (this.color[3] != 0.0f) {
            this.currentRed = this.color[0];
            this.currentGreen = this.color[1];
            this.currentBlue = this.color[2];
            this.color[3] = 0.0f;
        }
        this.currentRed += (this.color[0] - this.currentRed) * deltaTicks;
        this.currentGreen += (this.color[1] - this.currentGreen) * deltaTicks;
        this.currentBlue += (this.color[2] - this.currentBlue) * deltaTicks;
        int r = (int)(this.multiplier * 255.0f * shade * this.currentRed);
        int g = (int)(this.multiplier * 255.0f * shade * this.currentGreen);
        int elementCodec = (int)(this.multiplier * 255.0f * shade * this.currentBlue);
        int color = 0xFF000000 | r << 16 | g << 8 | elementCodec;
        int x = this.method_46426();
        int y = this.method_46427();
        int width = this.method_25368();
        int height = this.method_25364();
        context.method_25294(x, y + 1, x + width, y + height - 1, color);
        context.method_25294(x + 1, y, x + width - 1, y + 1, color);
        context.method_25294(x + 1, y + height - 1, x + width - 1, y + height, color);
        int textColor = this.field_22763 ? -1 : -6250336;
        context.method_27534(class_310.method_1551().field_1772, this.method_25369(), x + width / 2, y + height / 2 - 4, textColor);
    }
}

