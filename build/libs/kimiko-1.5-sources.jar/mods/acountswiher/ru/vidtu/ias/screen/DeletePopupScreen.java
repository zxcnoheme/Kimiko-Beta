/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.screen.ScreenTexts
 *  net.minecraft.client.gui.tooltip.Tooltip
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.time.Duration;
import mods.acountswiher.IasService;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import mods.acountswiher.ru.vidtu.ias.screen.MultiLineLabelCompat;
import mods.acountswiher.ru.vidtu.ias.screen.PopupButton;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;

final class DeletePopupScreen
extends class_437 {
    private final AccountScreen parent;
    private final Account account;
    private MultiLineLabelCompat label = MultiLineLabelCompat.EMPTY;

    DeletePopupScreen(AccountScreen parent, Account account) {
        super((class_2561)class_2561.method_43471((String)"ias.delete"));
        this.parent = parent;
        this.account = account;
    }

    protected void method_25426() {
        assert (this.field_22787 != null);
        this.method_37067();
        this.parent.method_25410(this.field_22789, this.field_22790);
        this.label = MultiLineLabelCompat.create(this.field_22793, (class_2561)class_2561.method_43469((String)"ias.delete.confirm", (Object[])new Object[]{this.account.name()}), 150);
        PopupButton delete = new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 + 27, 74, 20, this.field_22785, button -> {
            IasService.remove(this.account);
            this.parent.refresh();
            this.method_25419();
        });
        delete.method_47400(class_7919.method_47407((class_2561)class_2561.method_43469((String)"ias.delete.hint", (Object[])new Object[]{class_2561.method_43471((String)"key.keyboard.left.shift")})));
        delete.method_47402(Duration.ofMillis(250L));
        delete.color = new float[]{1.0f, 0.5f, 0.5f, 1.0f};
        this.method_37063(delete);
        this.method_37063(new PopupButton(this.field_22789 / 2 + 1, this.field_22790 / 2 + 27, 74, 20, class_5244.field_24335, button -> this.method_25419()));
    }

    public void method_25419() {
        this.field_22787.method_1507((class_437)this.parent);
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_51448().pushMatrix();
        context.method_51448().scale(2.0f, 2.0f);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 4, this.field_22790 / 4 - 24, -1);
        context.method_51448().popMatrix();
        this.label.renderCentered(context, this.field_22789 / 2, (this.field_22790 - this.label.getLineCount() * 9) / 2 - 4);
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent != null) {
            this.parent.method_47413(context, 0, 0, delta);
            context.method_25294(0, 0, this.field_22789, this.field_22790, Integer.MIN_VALUE);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        context.method_25294(centerX - 80, centerY - 50, centerX + 80, centerY + 50, -132112336);
        context.method_25294(centerX - 79, centerY - 51, centerX + 79, centerY - 50, -132112336);
        context.method_25294(centerX - 79, centerY + 50, centerX + 79, centerY + 51, -132112336);
    }
}

