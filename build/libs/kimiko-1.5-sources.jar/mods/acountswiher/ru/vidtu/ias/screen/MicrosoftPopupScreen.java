/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mods.acountswiher.ru.vidtu.ias.account.MicrosoftAccount
 *  mods.acountswiher.ru.vidtu.ias.crypt.Crypt
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.Util
 *  net.minecraft.util.Util$OperatingSystem
 *  net.minecraft.text.Text
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.screen.ScreenTexts
 *  org.lwjgl.glfw.GLFW
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import mods.acountswiher.ru.vidtu.ias.IAS;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.account.MicrosoftAccount;
import mods.acountswiher.ru.vidtu.ias.auth.handlers.CreateHandler;
import mods.acountswiher.ru.vidtu.ias.auth.microsoft.MSAuthClient;
import mods.acountswiher.ru.vidtu.ias.auth.microsoft.MSAuthServer;
import mods.acountswiher.ru.vidtu.ias.auth.microsoft.fields.DeviceAuth;
import mods.acountswiher.ru.vidtu.ias.config.IASConfig;
import mods.acountswiher.ru.vidtu.ias.crypt.Crypt;
import mods.acountswiher.ru.vidtu.ias.crypt.PasswordCrypt;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import mods.acountswiher.ru.vidtu.ias.screen.MultiLineLabelCompat;
import mods.acountswiher.ru.vidtu.ias.screen.PopupBox;
import mods.acountswiher.ru.vidtu.ias.screen.PopupButton;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import org.lwjgl.glfw.GLFW;
import recovery.privacy.NetworkPolicy;

final class MicrosoftPopupScreen
extends class_437
implements CreateHandler {
    private final AccountScreen parent;
    private final Account original;
    private final Object lock = new Object();
    private Crypt crypt;
    private MSAuthClient authClient;
    private MSAuthServer authServer;
    private class_2561 stage = class_2561.method_43471((String)"ias.login.initializing").method_27661().method_27692(class_124.field_1054);
    private MultiLineLabelCompat label = MultiLineLabelCompat.EMPTY;
    private PopupBox password;
    private MultiLineLabelCompat passwordTip = MultiLineLabelCompat.EMPTY;
    private MultiLineLabelCompat errorNote = MultiLineLabelCompat.EMPTY;
    private float error = Float.NaN;

    MicrosoftPopupScreen(AccountScreen parent, Account original, Crypt crypt) {
        super((class_2561)class_2561.method_43471((String)"ias.login"));
        this.parent = parent;
        this.original = original;
        this.crypt = crypt;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    protected void method_25426() {
        assert (this.field_22787 != null);
        this.method_37067();
        this.parent.method_25410(this.field_22789, this.field_22790);
        Object object = this.lock;
        synchronized (object) {
            this.label = MultiLineLabelCompat.EMPTY;
        }
        this.method_37063(new PopupButton(this.field_22789 / 2 - 75, this.field_22790 / 2 + 52, 150, 20, class_5244.field_24339, button -> this.method_25419()));
        if (this.crypt == null) {
            this.password = new PopupBox(this.field_22793, this.field_22789 / 2 - 100, this.field_22790 / 2 - 5, 178, 20, this.password, (class_2561)class_2561.method_43471((String)"ias.password"), this::submitPassword, true);
            this.password.method_1880(32);
            this.password.method_47404((class_2561)class_2561.method_43471((String)"ias.password.hint").method_27661().method_27692(class_124.field_1063));
            this.method_37063(this.password);
            PopupButton enter = new PopupButton(this.field_22789 / 2 + 80, this.field_22790 / 2 - 5, 20, 20, (class_2561)class_2561.method_43470((String)">>"), button -> this.submitPassword());
            enter.field_22763 = !this.password.method_1882().isBlank();
            this.password.method_1863(value -> {
                enter.field_22763 = !value.isBlank();
            });
            this.method_37063(enter);
            this.passwordTip = MultiLineLabelCompat.create(this.field_22793, (class_2561)class_2561.method_43471((String)"ias.password.tip").method_27661().method_27692(class_124.field_1054), 320);
            return;
        }
        this.password = null;
        this.passwordTip = MultiLineLabelCompat.EMPTY;
        if (this.authClient == null && this.authServer == null) {
            IAS.executor().execute(() -> {
                if (IASConfig.useServerAuth()) {
                    this.startServerAuth();
                } else {
                    this.startClientAuth();
                }
            });
        }
    }

    @Override
    public boolean cancelled() {
        return this.field_22787 == null || this.field_22787.field_1755 != this;
    }

    @Override
    public void stage(String stage, Object ... args) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 != this) {
                return;
            }
            if ("ias.login.processing".equals(stage)) {
                try {
                    long handle = client.method_22683().method_4490();
                    GLFW.glfwRequestWindowAttention((long)handle);
                    GLFW.glfwFocusWindow((long)handle);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            Object object = this.lock;
            synchronized (object) {
                this.stage = class_2561.method_43469((String)stage, (Object[])args).method_27661().method_27692(class_124.field_1054);
                this.label = MultiLineLabelCompat.EMPTY;
            }
        });
    }

    @Override
    public void success(MicrosoftAccount account) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 != this) {
                return;
            }
            this.parent.addOrReplace(this.original, (Account)account);
            this.method_25419();
        });
    }

    @Override
    public void error(Throwable error) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 != this) {
                return;
            }
            Object object = this.lock;
            synchronized (object) {
                this.stage = class_2561.method_43471((String)"ias.error").method_27661().method_27692(class_124.field_1061);
                this.label = MultiLineLabelCompat.EMPTY;
                this.error = 1.0f;
            }
        });
    }

    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507((class_437)this.parent);
        }
    }

    public void method_25432() {
        super.method_25432();
        IAS.executor().execute(() -> {
            if (this.authClient != null) {
                this.authClient.close();
                this.authClient = null;
            }
            if (this.authServer != null) {
                this.authServer.close();
                this.authServer = null;
            }
        });
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        MultiLineLabelCompat currentLabel;
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_51448().pushMatrix();
        context.method_51448().scale(2.0f, 2.0f);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 4, this.field_22790 / 4 - 37, -1);
        context.method_51448().popMatrix();
        if (this.crypt == null && this.password != null) {
            context.method_27534(this.field_22793, this.password.method_25369(), this.field_22789 / 2, this.field_22790 / 2 - 15, -1);
            this.passwordTip.renderCentered(context, this.field_22789 / 2, this.field_22790 / 2 + 22);
            return;
        }
        Object object = this.lock;
        synchronized (object) {
            if (this.label == MultiLineLabelCompat.EMPTY) {
                this.label = MultiLineLabelCompat.create(this.field_22793, this.stage, 240);
            }
            currentLabel = this.label;
        }
        currentLabel.renderCentered(context, this.field_22789 / 2, (this.field_22790 - currentLabel.getLineCount() * 9) / 2 - 4);
        if (Float.isFinite(this.error)) {
            if (this.errorNote == MultiLineLabelCompat.EMPTY) {
                this.errorNote = MultiLineLabelCompat.create(this.field_22793, (class_2561)class_2561.method_43471((String)"ias.error.note").method_27661().method_27692(class_124.field_1075), 245);
            }
            this.errorNote.renderCentered(context, this.field_22789 / 2, this.field_22790 / 2 + 87);
        }
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent != null) {
            this.parent.method_47413(context, 0, 0, delta);
            context.method_25294(0, 0, this.field_22789, this.field_22790, Integer.MIN_VALUE);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        context.method_25294(centerX - 125, centerY - 75, centerX + 125, centerY + 75, -132112336);
        context.method_25294(centerX - 124, centerY - 76, centerX + 124, centerY - 75, -132112336);
        context.method_25294(centerX - 124, centerY + 75, centerX + 124, centerY + 76, -132112336);
    }

    private void submitPassword() {
        if (this.password == null) {
            return;
        }
        String value = this.password.method_1882();
        if (value.isBlank()) {
            return;
        }
        this.crypt = new PasswordCrypt(value);
        this.password = null;
        this.passwordTip = MultiLineLabelCompat.EMPTY;
        this.method_25426();
    }

    private void startClientAuth() {
        if (this.crypt == null || this.authClient != null || this.authServer != null) {
            return;
        }
        try {
            this.authClient = new MSAuthClient(this.crypt, this);
            ((CompletableFuture)this.authClient.start().thenAcceptAsync(this::openDeviceAuth, (Executor)class_310.method_1551())).exceptionally(throwable -> {
                this.error(new RuntimeException("Unable to handle client auth.", (Throwable)throwable));
                return null;
            });
        }
        catch (Throwable throwable2) {
            this.error(new RuntimeException("Unable to create client auth.", throwable2));
        }
    }

    private void startServerAuth() {
        if (this.crypt == null || this.authClient != null || this.authServer != null) {
            return;
        }
        try {
            this.authServer = new MSAuthServer(class_2561.method_43471((String)"ias.login.done").getString(), this.crypt, this);
            ((CompletableFuture)CompletableFuture.runAsync(this.authServer, IAS.executor()).thenRunAsync(() -> {
                if (this.authServer == null) {
                    return;
                }
                String url = this.authServer.authUrl();
                this.stage("ias.login.link", new Object[0]);
                MicrosoftPopupScreen.privacy$openAllowedLink(class_156.method_668(), url);
                if (this.field_22787 != null) {
                    this.field_22787.field_1774.method_1455(url);
                }
            }, (Executor)class_310.method_1551())).exceptionally(throwable -> {
                this.error(new RuntimeException("Unable to handle server auth.", (Throwable)throwable));
                return null;
            });
        }
        catch (Throwable throwable2) {
            this.error(new RuntimeException("Unable to create server auth.", throwable2));
        }
    }

    private void openDeviceAuth(DeviceAuth auth) {
        if (auth == null) {
            return;
        }
        this.stage("ias.login.linkClient", class_2561.method_43470((String)auth.uri().toString()).method_27661().method_27692(class_124.field_1065), class_2561.method_43470((String)auth.user()).method_27661().method_27692(class_124.field_1065));
        MicrosoftPopupScreen.privacy$openAllowedLink(class_156.method_668(), auth.uri().toString());
        if (this.field_22787 != null) {
            this.field_22787.field_1774.method_1455(auth.user());
        }
    }

    private static /* synthetic */ void privacy$openAllowedLink(class_156.class_158 operatingSystem2, String string) {
        if (NetworkPolicy.allowedLink(string)) {
            operatingSystem2.method_670(string);
        }
    }
}

