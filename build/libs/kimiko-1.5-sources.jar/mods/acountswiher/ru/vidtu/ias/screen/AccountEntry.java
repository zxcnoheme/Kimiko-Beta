/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.RenderPipelines
 *  net.minecraft.client.gui.Click
 *  net.minecraft.util.Util
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.session.Session
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget$Entry
 *  net.minecraft.screen.ScreenTexts
 *  net.minecraft.text.OrderedText
 *  net.minecraft.client.gui.PlayerSkinDrawer
 *  net.minecraft.entity.player.SkinTextures
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import java.util.List;
import java.util.Objects;
import mods.acountswiher.ru.vidtu.ias.account.Account;
import mods.acountswiher.ru.vidtu.ias.screen.AccountList;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_332;
import net.minecraft.class_4280;
import net.minecraft.class_5244;
import net.minecraft.class_5481;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

final class AccountEntry
extends class_4280.class_4281<AccountEntry> {
    private static final class_2960 UP_PLAIN = class_2960.method_60655((String)"ias", (String)"up_plain");
    private static final class_2960 UP_DISABLED = class_2960.method_60655((String)"ias", (String)"up_disabled");
    private static final class_2960 UP_FOCUS = class_2960.method_60655((String)"ias", (String)"up_focus");
    private static final class_2960 DOWN_PLAIN = class_2960.method_60655((String)"ias", (String)"down_plain");
    private static final class_2960 DOWN_DISABLED = class_2960.method_60655((String)"ias", (String)"down_disabled");
    private static final class_2960 DOWN_FOCUS = class_2960.method_60655((String)"ias", (String)"down_focus");
    private static final class_2960 WARNING_OFF = class_2960.method_60655((String)"ias", (String)"warning_off");
    private static final class_2960 WARNING_ON = class_2960.method_60655((String)"ias", (String)"warning_on");
    private final class_310 client;
    private final AccountList list;
    private final Account account;
    private final List<class_5481> tooltip;
    private long clicked = class_156.method_658();
    private long lastFree = System.nanoTime();

    AccountEntry(class_310 client, AccountList list, Account account) {
        this.client = client;
        this.list = list;
        this.account = account;
        this.tooltip = List.of(class_5244.method_32700((class_2561)class_2561.method_43471((String)"ias.accounts.tip.nick"), (class_2561)class_2561.method_43470((String)account.name())).method_30937(), class_5244.method_32700((class_2561)class_2561.method_43471((String)"ias.accounts.tip.uuid"), (class_2561)class_2561.method_43470((String)account.uuid().toString())).method_30937(), class_5244.method_32700((class_2561)class_2561.method_43471((String)"ias.accounts.tip.type"), (class_2561)class_2561.method_43471((String)account.typeTipKey())).method_30937());
    }

    public void method_25343(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
        String username;
        int x = this.method_73380();
        int y = this.method_73382();
        int width = this.method_73387();
        int height = this.method_73384();
        if (hovered) {
            if (System.nanoTime() - this.lastFree >= 500000000L) {
                context.method_51447(this.client.field_1772, this.tooltip, mouseX, mouseY);
            }
        } else {
            this.lastFree = System.nanoTime();
        }
        class_8685 skin = this.list.skin(this);
        class_7532.method_52722((class_332)context, (class_8685)skin, (int)x, (int)y, (int)8);
        class_320 session = this.client.method_1548();
        String string = username = session != null ? session.method_1676() : "";
        int color = !this.account.name().equalsIgnoreCase(username) ? -1 : (session != null && Objects.equals(this.account.uuid(), session.method_44717()) ? -16711936 : (this.account.name().equals(username) ? -256 : Short.MIN_VALUE));
        context.method_51433(this.client.field_1772, this.account.name(), x + 10, y, color, false);
        if (this.account.insecure()) {
            boolean warning = System.nanoTime() / 1000000000L % 2L == 0L;
            context.method_52706(class_10799.field_56883, warning ? WARNING_ON : WARNING_OFF, x - 6, y - 1, 2, 10);
            if (mouseX >= x - 10 && mouseX <= x && mouseY >= y && mouseY <= y + height) {
                context.method_51438(this.client.field_1772, (class_2561)class_2561.method_43471((String)"ias.accounts.tip.insecure"), mouseX, mouseY);
            }
        }
        if (this.equals(this.list.method_25336()) || this.equals((Object)this.list.getSelected())) {
            int upX = x + width - 28;
            class_2960 upTexture = this == this.list.method_25396().getFirst() ? UP_DISABLED : (mouseX >= upX && mouseY >= y && mouseX <= upX + 11 && mouseY <= y + height ? UP_FOCUS : UP_PLAIN);
            context.method_52706(class_10799.field_56883, upTexture, upX, y, 11, 7);
            int downX = x + width - 15;
            class_2960 downTexture = this == this.list.method_25396().getLast() ? DOWN_DISABLED : (mouseX >= downX && mouseY >= y && mouseX <= downX + 11 && mouseY <= y + height ? DOWN_FOCUS : DOWN_PLAIN);
            context.method_52706(class_10799.field_56883, downTexture, downX, y, 11, 7);
        }
    }

    public boolean method_25402(class_11909 event, boolean doubleClick) {
        double mouseX = event.comp_4798();
        double mouseY = event.comp_4799();
        int button = event.method_74245();
        this.list.setSelected(this);
        if (this.equals(this.list.method_25336()) || this.equals((Object)this.list.getSelected())) {
            int right = this.method_73389();
            int upX = right - 28;
            if (mouseX >= (double)upX && mouseX <= (double)(upX + 11)) {
                this.list.swapUp(this);
                return true;
            }
            int downX = right - 15;
            if (mouseX >= (double)downX && mouseX <= (double)(downX + 11)) {
                this.list.swapDown(this);
                return true;
            }
        }
        if (class_156.method_658() - this.clicked < 250L) {
            this.list.login(!class_310.method_1551().method_74187());
        }
        this.clicked = class_156.method_658();
        return true;
    }

    public class_2561 method_37006() {
        return class_2561.method_43470((String)this.account.name());
    }

    Account account() {
        return this.account;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AccountEntry)) {
            return false;
        }
        AccountEntry that = (AccountEntry)((Object)obj);
        return Objects.equals(this.account, that.account);
    }

    public int hashCode() {
        return Objects.hashCode(this.account);
    }
}

