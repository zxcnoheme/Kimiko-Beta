/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.text.Text
 *  net.minecraft.text.Style
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.widget.TextFieldWidget
 *  net.minecraft.text.MutableText
 *  net.minecraft.text.OrderedText
 */
package mods.acountswiher.ru.vidtu.ias.screen;

import mods.acountswiher.ru.vidtu.ias.config.IASConfig;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_5250;
import net.minecraft.class_5481;

final class PopupBox
extends class_342 {
    private final Runnable enterAction;
    private final boolean secure;

    PopupBox(class_327 textRenderer, int x, int y, int width, int height, class_2561 title, Runnable enterAction, boolean secure) {
        super(textRenderer, x, y, width, height, title);
        this.enterAction = enterAction;
        this.secure = secure;
        this.wirst$installMask();
    }

    PopupBox(class_327 textRenderer, int x, int y, int width, int height, PopupBox inherit, class_2561 title, Runnable enterAction, boolean secure) {
        this(textRenderer, x, y, width, height, title, enterAction, secure);
        if (inherit != null) {
            this.method_1852(inherit.method_1882());
        }
    }

    public void method_48579(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        int x = this.method_46426();
        int y = this.method_46427();
        int width = this.method_25368();
        int height = this.method_25364();
        context.method_25294(x + 1, y + 1, x + width - 1, y + height - 1, -16777216);
        context.method_25294(x + 1, y, x + width - 1, y + 1, -1);
        context.method_25294(x + 1, y + height - 1, x + width - 1, y + height, -1);
        context.method_25294(x, y + 1, x + 1, y + height - 1, -1);
        context.method_25294(x + width - 1, y + 1, x + width, y + height - 1, -1);
        super.method_48579(context, mouseX, mouseY, deltaTicks);
    }

    public boolean method_25404(class_11908 event) {
        int keyCode = event.comp_4795();
        int scanCode = event.comp_4796();
        int modifiers = event.comp_4797();
        if (this.enterAction != null && this.field_22763 && this.method_25370() && (keyCode == 257 || keyCode == 335)) {
            this.enterAction.run();
            return true;
        }
        if (this.secure && (keyCode == 67 && class_310.method_1551().method_74188() || keyCode == 88 && class_310.method_1551().method_74188())) {
            return true;
        }
        return super.method_25404(event);
    }

    protected class_5250 method_25360() {
        if (!this.secure) {
            return super.method_25360();
        }
        return class_2561.method_43469((String)"gui.narrate.editBox", (Object[])new Object[]{this.method_25369(), class_2561.method_43473()});
    }

    public boolean method_1851() {
        return false;
    }

    private void wirst$installMask() {
        if (!this.secure) {
            return;
        }
        this.method_73210((text, firstCharacterIndex) -> {
            if (!IASConfig.passwordEchoing) {
                return class_5481.field_26385;
            }
            return class_5481.method_30747((String)"*".repeat(text.length()), (class_2583)class_2583.field_24360);
        });
    }
}

