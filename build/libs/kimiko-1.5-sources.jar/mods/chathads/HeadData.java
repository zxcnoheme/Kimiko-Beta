/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.PlayerListEntry
 */
package mods.chathads;

import net.minecraft.class_640;

public final class HeadData {
    public static final HeadData EMPTY = new HeadData(null, -1);
    public final class_640 playerInfo;
    public final int codePointIndex;

    public HeadData(class_640 playerInfo, int codePointIndex) {
        if (playerInfo == null && codePointIndex >= 0) {
            throw new AssertionError();
        }
        this.playerInfo = playerInfo;
        this.codePointIndex = codePointIndex;
    }

    public static HeadData of(class_640 playerInfo) {
        if (playerInfo == null) {
            return EMPTY;
        }
        return new HeadData(playerInfo, -1);
    }

    public boolean hasHeadPosition() {
        return this.codePointIndex >= 0;
    }
}

