/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.PlayerListEntry
 */
package mods.chathads.mixininterface;

import net.minecraft.class_640;

public interface Ownable {
    public class_640 chatheads$getOwner();

    public void chatheads$setOwner(class_640 var1);
}

