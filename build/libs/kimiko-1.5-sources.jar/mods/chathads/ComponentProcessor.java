/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.datafixers.util.Pair
 *  net.minecraft.text.ObjectTextContent
 *  net.minecraft.text.object.TextObjectContents
 *  net.minecraft.text.object.PlayerTextObjectContents
 *  net.minecraft.util.Formatting
 *  net.minecraft.text.ClickEvent
 *  net.minecraft.text.ClickEvent$SuggestCommand
 *  net.minecraft.text.Text
 *  net.minecraft.text.Style
 *  net.minecraft.text.TranslatableTextContent
 *  net.minecraft.text.TextVisitFactory
 *  net.minecraft.text.MutableText
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.text.TextContent
 *  net.minecraft.text.PlainTextContent
 *  net.minecraft.component.type.ProfileComponent
 *  org.jetbrains.annotations.Nullable
 */
package mods.chathads;

import com.mojang.authlib.GameProfile;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import mods.chathads.ChatHeads;
import mods.chathads.HeadData;
import net.minecraft.class_11722;
import net.minecraft.class_11724;
import net.minecraft.class_11885;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2588;
import net.minecraft.class_5223;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_7417;
import net.minecraft.class_8828;
import net.minecraft.class_9296;
import org.jetbrains.annotations.Nullable;

public class ComponentProcessor {
    public static void walkTree(class_2561 component, class_2583 currentStyle, StyledComponentConsumer consumer) {
        currentStyle = component.method_10866().method_27702(currentStyle);
        consumer.accept(component, currentStyle);
        for (class_2561 sibling : component.method_10855()) {
            ComponentProcessor.walkTree(sibling, currentStyle, consumer);
        }
    }

    public static void walkTree(class_2561 component, StyledComponentConsumer consumer) {
        ComponentProcessor.walkTree(component, class_2583.field_24360, consumer);
    }

    public static ArrayList<class_2561> split(class_2561 component) {
        ArrayList<class_2561> components = new ArrayList<class_2561>();
        ComponentProcessor.walkTree(component, (c, cStyle) -> {
            class_7417 patt0$temp = c.method_10851();
            if (patt0$temp instanceof class_8828) {
                class_8828 literal = (class_8828)patt0$temp;
                class_2583[] prevStyle = new class_2583[]{cStyle};
                StringBuilder elementCodec = new StringBuilder();
                class_5223.method_27479((String)literal.comp_737(), (class_2583)prevStyle[0], (index, style, cp) -> {
                    if (!style.equals((Object)prevStyle[0])) {
                        if (!elementCodec.isEmpty()) {
                            components.add((class_2561)class_2561.method_43470((String)elementCodec.toString()).method_10862(prevStyle[0]));
                        }
                        elementCodec.setLength(0);
                        prevStyle[0] = style;
                    }
                    elementCodec.appendCodePoint(cp);
                    return true;
                });
                if (!elementCodec.isEmpty()) {
                    components.add((class_2561)class_2561.method_43470((String)elementCodec.toString()).method_10862(prevStyle[0]));
                }
            } else {
                class_5250 copy = c.method_27662().method_10862(cStyle);
                components.add((class_2561)copy);
            }
        });
        return components;
    }

    public static class_2561 join(List<class_2561> components) {
        if (components.size() == 1) {
            return components.getFirst();
        }
        class_5250 combined = class_2561.method_43473();
        for (class_2561 c : components) {
            combined.method_10855().add(c);
        }
        return combined;
    }

    public static void walkLiteralSequencesAndTranslatables(ArrayList<class_2561> components, Predicate<FoundLiteralSequence> literalsCallback, Predicate<FoundTranslatable> translatableCallback) {
        StringBuilder textSequence = new StringBuilder();
        int startIndex = -1;
        int endIndex = -1;
        for (int i = 0; i < components.size(); ++i) {
            class_2588 translatableContents;
            class_7417 contents = components.get(i).method_10851();
            if (contents instanceof class_8828) {
                class_8828 textContents = (class_8828)contents;
                if (startIndex == -1) {
                    startIndex = i;
                }
                endIndex = i;
                textSequence.append(textContents.comp_737());
                continue;
            }
            if (!textSequence.isEmpty() && literalsCallback.test(new FoundLiteralSequence(textSequence.toString(), startIndex, endIndex))) {
                return;
            }
            textSequence = new StringBuilder();
            startIndex = -1;
            if (!(contents instanceof class_2588) || !translatableCallback.test(new FoundTranslatable(translatableContents = (class_2588)contents, i))) continue;
            return;
        }
        endIndex = components.size() - 1;
        if (!textSequence.isEmpty() && literalsCallback.test(new FoundLiteralSequence(textSequence.toString(), startIndex, endIndex))) {
            return;
        }
    }

    public static String codePointSubstring(String string, int start) {
        return string.substring(string.offsetByCodePoints(0, start));
    }

    public static String codePointSubstring(String string, int start, int end) {
        int i = string.offsetByCodePoints(0, start);
        int j = string.offsetByCodePoints(i, end - start);
        return string.substring(i, j);
    }

    @Nullable
    public static Pair<class_5250, class_5250> splitLiteral(class_2561 literal, int i) {
        if (i == 0) {
            return null;
        }
        String text = ((class_8828)literal.method_10851()).comp_737();
        String leftText = ComponentProcessor.codePointSubstring(text, 0, i);
        String rightText = ComponentProcessor.codePointSubstring(text, i);
        class_5250 left = class_2561.method_43470((String)leftText).method_10862(literal.method_10866());
        class_5250 right = class_2561.method_43470((String)rightText).method_10862(literal.method_10866());
        literal.method_10855().forEach(arg_0 -> ((class_5250)right).method_10852(arg_0));
        return new Pair((Object)left, (Object)right);
    }

    @Nullable
    public static class_640 addChatHeadForClickTellCommand(ArrayList<class_2561> components, ChatHeads.PlayerInfoCache playerInfoCache) {
        for (int i = 0; i < components.size(); ++i) {
            final int finalI = i;
            class_2561 c = components.get(i);
            String profileName = ComponentProcessor.getTellReceiver(c);
            if (profileName != null) {
                class_640 playerInfo2 = playerInfoCache.get(profileName);
                if (playerInfo2 != null) {
                    class_5250 chatHead = ComponentProcessor.createChatHeadComponent(playerInfo2, c);
                    class_5250 decorated = class_2561.method_43473().method_10852((class_2561)chatHead).method_10852(c);
                    components.set(i, (class_2561)decorated);
                    return playerInfo2;
                }
            }
            class_7417 chatHead = c.method_10851();
            if (chatHead instanceof class_2588 translatable) {
                class_640 playerInfo = ComponentProcessor.processTranslatableArguments(
                    c,
                    translatable,
                    splitArg -> ComponentProcessor.addChatHeadForClickTellCommand(splitArg, playerInfoCache),
                    decorated -> components.set(finalI, decorated)
                );
                if (playerInfo != null) {
                    return playerInfo;
                }
            }
        }
        return null;
    }

    @Nullable
    public static <T> T processTranslatableArguments(class_2561 translatable, class_2588 contents, Function<ArrayList<class_2561>, @Nullable T> processSplitArg, Consumer<class_2561> processedCallback) {
        Object[] args = contents.method_11023();
        int argsLength = Objects.equals(contents.method_11022(), "chat.type.text") ? 1 : args.length;
        for (int i = 0; i < argsLength; ++i) {
            class_2561 argComponent;
            ArrayList<class_2561> splitArg;
            T returnValue;
            Object object = args[i];
            if (object instanceof String) {
                String text = (String)object;
                args[i] = class_2561.method_43470((String)text);
            }
            if (!((object = args[i]) instanceof class_2561) || (returnValue = processSplitArg.apply(splitArg = ComponentProcessor.split(argComponent = (class_2561)object))) == null) continue;
            class_2561 processedArg = ComponentProcessor.join(splitArg);
            Object[] processedArgs = Arrays.copyOf(args, args.length);
            processedArgs[i] = processedArg;
            class_5250 processed = class_2561.method_48322((String)contents.method_11022(), (String)contents.method_48323(), (Object[])processedArgs);
            processed.method_10862(translatable.method_10866());
            translatable.method_10855().forEach(arg_0 -> ((class_5250)processed).method_10852(arg_0));
            processedCallback.accept((class_2561)processed);
            return returnValue;
        }
        return null;
    }

    public static class_640 addChatHeadForPlayerName(ArrayList<class_2561> components, ChatHeads.PlayerInfoCache playerInfoCache) {
        class_640[] returnValue = new class_640[1];
        ComponentProcessor.walkLiteralSequencesAndTranslatables(components, literals -> {
            HeadData headData = ChatHeads.scanForPlayerName(literals.text, playerInfoCache);
            if (headData == HeadData.EMPTY) {
                return false;
            }
            int codePointIndex = headData.codePointIndex;
            for (int i = literals.startIndex; i <= literals.endIndex; ++i) {
                class_5250 decorated;
                class_2561 literal = (class_2561)components.get(i);
                class_8828 contents = (class_8828)literal.method_10851();
                int codePointCount = (int)contents.comp_737().codePoints().count();
                if (codePointIndex >= codePointCount) {
                    codePointIndex -= codePointCount;
                    continue;
                }
                class_5250 chatHead = ComponentProcessor.createChatHeadComponent(headData.playerInfo, literal);
                Pair<class_5250, class_5250> pair = ComponentProcessor.splitLiteral(literal, codePointIndex);
                if (pair == null) {
                    decorated = class_2561.method_43473().method_10852((class_2561)chatHead).method_10852(literal);
                } else {
                    class_5250 left = (class_5250)pair.getFirst();
                    class_5250 right = (class_5250)pair.getSecond();
                    decorated = class_2561.method_43473().method_10852((class_2561)left).method_10852((class_2561)chatHead).method_10852((class_2561)right);
                }
                components.set(i, (class_2561)decorated);
                returnValue[0] = headData.playerInfo;
                return true;
            }
            return false;
        }, foundTranslatable -> {
            class_2588 contents;
            class_2561 translatable = (class_2561)components.get(foundTranslatable.index);
            class_640 foundPlayerInfo = ComponentProcessor.processTranslatableArguments(translatable, contents = foundTranslatable.contents, splitArg -> ComponentProcessor.addChatHeadForPlayerName(splitArg, playerInfoCache), decorated -> components.set(foundTranslatable.index, (class_2561)decorated));
            if (foundPlayerInfo != null) {
                returnValue[0] = foundPlayerInfo;
                return true;
            }
            return false;
        });
        return returnValue[0];
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean containsPlayerSprite(ArrayList<class_2561> components) {
        Iterator<class_2561> iterator = components.iterator();
        while (true) {
            if (!iterator.hasNext()) {
                return false;
            }
            class_2561 c = iterator.next();
            class_7417 textContent2 = c.method_10851();
            if (!(textContent2 instanceof class_11722)) continue;
            class_11722 objectTextContent2 = (class_11722)textContent2;
            try {
                // empty try
            }
            catch (Throwable throwable) {
                throw new MatchException(throwable.toString(), throwable);
            }
            class_11724 textObjectContents2 = objectTextContent2.comp_4591();
            class_11724 objectInfo = textObjectContents2;
            if (objectInfo instanceof class_11885) break;
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Nullable
    public static String getTellReceiver(class_2561 component) {
        class_2558 clickEvent2 = component.method_10866().method_10970();
        if (!(clickEvent2 instanceof class_2558.class_10610)) return null;
        class_2558.class_10610 suggestCommand2 = (class_2558.class_10610)clickEvent2;
        try {
            String string;
            String command = string = suggestCommand2.comp_3507();
            if (command == null) return null;
            if (!command.startsWith("/tell ")) return null;
            return command.substring("/tell ".length()).trim();
        }
        catch (Throwable throwable) {
            throw new MatchException(throwable.toString(), throwable);
        }
    }

    public static class_5250 createChatHeadComponent(class_640 playerInfo) {
        return class_2561.method_74062((class_11724)new class_11885(class_9296.method_73307((GameProfile)playerInfo.method_2966()), playerInfo.method_65195())).method_27692(class_124.field_1068);
    }

    public static class_5250 createChatHeadComponent(class_640 playerInfo, class_2561 message) {
        class_5250 chatHead = ComponentProcessor.createChatHeadComponent(playerInfo);
        if (message.method_10866().method_10986()) {
            return chatHead.method_27692(class_124.field_1055);
        }
        return chatHead;
    }


    public static interface StyledComponentConsumer {
        public void accept(class_2561 var1, class_2583 var2);
    }

    public record FoundLiteralSequence(String text, int startIndex, int endIndex) {
    }

    public record FoundTranslatable(class_2588 contents, int index) {
    }
}

