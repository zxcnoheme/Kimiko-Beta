/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.Window
 *  net.minecraft.util.Formatting
 *  net.minecraft.item.BlockItem
 *  net.minecraft.util.DyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.block.Block
 *  net.minecraft.util.collection.DefaultedList
 *  net.minecraft.block.ShulkerBoxBlock
 *  net.minecraft.text.Text
 *  net.minecraft.text.Style
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.text.MutableText
 *  net.minecraft.component.type.ContainerComponent
 *  net.minecraft.component.DataComponentTypes
 */
package mods.shulkerview;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2371;
import net.minecraft.class_2480;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import rtx.kimiko.api.modules.impl.Utils.ShulkerPreview;

public final class ShulkerPreviewHelper {
    public static final int SHULKER_SIZE = 27;
    public static final int ROW_SIZE = 9;
    private static class_1799 frozenShulker = null;
    private static float frozenOverlayX = 0.0f;
    private static float frozenOverlayY = 0.0f;
    private static class_1799 lastShownShulker = null;
    private static float lastRenderedX = 0.0f;
    private static float lastRenderedY = 0.0f;
    private static long lastRenderedTime = 0L;

    private ShulkerPreviewHelper() {
    }

    public static boolean canPreview(class_1799 stack) {
        class_1747 blockItem;
        class_1792 item2;
        return ShulkerPreview.enabled() && stack != null && !stack.method_7960() && (item2 = stack.method_7909()) instanceof class_1747 && (blockItem = (class_1747)item2).method_7711() instanceof class_2480 && stack.method_58694(class_9334.field_49622) != null && ShulkerPreviewHelper.hasVisibleContent(stack);
    }

    public static boolean shouldShowPreview(class_1799 stack) {
        if (!ShulkerPreviewHelper.canPreview(stack)) {
            return false;
        }
        if (ShulkerPreviewHelper.isFrozen()) {
            return false;
        }
        return ShulkerPreviewHelper.previewKeyPressed();
    }

    public static boolean previewKeyPressed() {
        class_310 mc = class_310.method_1551();
        return mc != null && mc.method_22683() != null && class_3675.method_15987((class_1041)mc.method_22683(), (int)340);
    }

    public static boolean ctrlKeyPressed() {
        class_310 mc = class_310.method_1551();
        return mc != null && mc.method_22683() != null && class_3675.method_15987((class_1041)mc.method_22683(), (int)341);
    }

    public static boolean isFrozen() {
        return frozenShulker != null;
    }

    public static class_1799 getFrozenShulker() {
        return frozenShulker;
    }

    public static float getFrozenOverlayX() {
        return frozenOverlayX;
    }

    public static float getFrozenOverlayY() {
        return frozenOverlayY;
    }

    public static void tryFreeze() {
        long now = System.currentTimeMillis();
        if (lastShownShulker != null && ShulkerPreviewHelper.canPreview(lastShownShulker) && now - lastRenderedTime < 200L) {
            frozenShulker = lastShownShulker.method_7972();
            frozenOverlayX = lastRenderedX;
            frozenOverlayY = lastRenderedY;
        }
    }

    public static void unfreeze() {
        frozenShulker = null;
    }

    public static void recordTooltipPosition(class_1799 source, int tooltipX, int tooltipY) {
        lastShownShulker = source;
        lastRenderedX = tooltipX;
        lastRenderedY = tooltipY;
        lastRenderedTime = System.currentTimeMillis();
    }

    public static int contentStackCount(class_1799 stack) {
        int count = 0;
        for (class_1799 item : ShulkerPreviewHelper.getItems(stack)) {
            if (item.method_7960() || item.method_7909() == class_1802.field_8162) continue;
            ++count;
        }
        return count;
    }

    public static int shulkerColor(class_1799 stack) {
        class_1767 dyeColor2;
        class_2248 block;
        class_1792 item2 = stack.method_7909();
        if (item2 instanceof class_1747) {
            class_1747 blockItem = (class_1747)item2;
            block = blockItem.method_7711();
        } else {
            block = null;
        }
        if (block instanceof class_2480) {
            class_2480 shulker = (class_2480)block;
            dyeColor2 = shulker.method_10528();
        } else {
            dyeColor2 = null;
        }
        class_1767 dye = dyeColor2;
        int rgb = dye == null ? 0x976797 : ShulkerPreviewHelper.dyeColor(dye);
        return 0xFF000000 | rgb;
    }

    public static List<class_1799> getItems(class_1799 stack) {
        class_2371 items = class_2371.method_10213((int)27, (Object)class_1799.field_8037);
        class_9288 contents = (class_9288)stack.method_58694(class_9334.field_49622);
        if (contents != null) {
            contents.method_57492(items);
        }
        return List.copyOf(items);
    }

    public static List<class_1799> getCompactItems(class_1799 stack) {
        ArrayList<class_1799> compact = new ArrayList<class_1799>();
        for (class_1799 item : ShulkerPreviewHelper.getItems(stack)) {
            if (item.method_7960() || item.method_7909() == class_1802.field_8162) continue;
            class_1799 existing = ShulkerPreviewHelper.findMatching(compact, item);
            if (existing == null) {
                compact.add(item.method_7972());
                continue;
            }
            existing.method_7933(item.method_7947());
        }
        compact.sort((keyCodec, elementCodec) -> Integer.compare(elementCodec.method_7947(), keyCodec.method_7947()));
        return compact;
    }

    public static List<class_2561> tooltipLines(class_1799 stack) {
        if (!ShulkerPreviewHelper.canPreview(stack)) {
            return List.of();
        }
        class_5250 shiftHint = class_2561.method_43470((String)"Shift").method_10862(class_2583.field_24360.method_10977(class_124.field_1054)).method_10852((class_2561)class_2561.method_43470((String)": preview").method_10862(class_2583.field_24360.method_10977(class_124.field_1080)));
        class_5250 ctrlHint = class_2561.method_43470((String)"  Ctrl").method_10862(class_2583.field_24360.method_10977(class_124.field_1054)).method_10852((class_2561)class_2561.method_43470((String)": pin  ").method_10862(class_2583.field_24360.method_10977(class_124.field_1080))).method_10852((class_2561)class_2561.method_43470((String)"Shift+Ctrl").method_10862(class_2583.field_24360.method_10977(class_124.field_1054))).method_10852((class_2561)class_2561.method_43470((String)": item info").method_10862(class_2583.field_24360.method_10977(class_124.field_1080)));
        return List.of(class_2561.method_43469((String)"container.shulkerbox.contains", (Object[])new Object[]{ShulkerPreviewHelper.contentStackCount(stack)}), shiftHint, ctrlHint);
    }

    private static boolean hasVisibleContent(class_1799 stack) {
        class_9288 contents = (class_9288)stack.method_58694(class_9334.field_49622);
        if (contents == null) {
            return false;
        }
        class_2371<class_1799> items = class_2371.method_10213(27, class_1799.field_8037);
        contents.method_57492(items);
        for (class_1799 item : items) {
            if (item.method_7960() || item.method_7909() == class_1802.field_8162) continue;
            return true;
        }
        return false;
    }

    private static class_1799 findMatching(List<class_1799> stacks, class_1799 needle) {
        for (class_1799 stack : stacks) {
            if (!class_1799.method_7973((class_1799)stack, (class_1799)needle)) continue;
            return stack;
        }
        return null;
    }

    private static int dyeColor(class_1767 dye) {
        int color = dye.method_7787();
        int r = Math.max(38, color >> 16 & 0xFF);
        int g = Math.max(38, color >> 8 & 0xFF);
        int elementCodec = Math.max(38, color & 0xFF);
        return r << 16 | g << 8 | elementCodec;
    }
}

