/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.tooltip.TooltipData
 */
package mods.shulkerview.tooltip;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_5632;

public record ShulkerPreviewTooltipComponent(class_1799 source, List<class_1799> items, boolean fullPreview) implements class_5632
{
}

