/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.RenderPipelines
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.tooltip.TooltipComponent
 *  org.jetbrains.annotations.NotNull
 */
package mods.shulkerview.tooltip;

import java.util.List;
import mods.shulkerview.ShulkerPreviewHelper;
import mods.shulkerview.hook.ShulkerPreviewGuiGraphics;
import mods.shulkerview.tooltip.ShulkerPreviewTooltipComponent;
import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import org.jetbrains.annotations.NotNull;

public final class ShulkerPreviewClientTooltipComponent
implements class_5684 {
    private static final int SLOT_SIZE = 18;
    private static final int SLOT_OFFSET = 8;
    private static final int PADDING = 14;
    private static final class_2960 WINDOW_TEXTURE = class_2960.method_60655((String)"shulkerboxtooltip", (String)"shulker_box_tooltip");
    private static final class_2960 SLOT_HIGHLIGHT_BACK = class_2960.method_60656((String)"container/slot_highlight_back");
    private static final class_2960 SLOT_HIGHLIGHT_FRONT = class_2960.method_60656((String)"container/slot_highlight_front");
    private final class_1799 source;
    private final List<class_1799> items;
    private final boolean fullPreview;

    public ShulkerPreviewClientTooltipComponent(ShulkerPreviewTooltipComponent component) {
        this.source = component.source();
        this.items = component.items();
        this.fullPreview = component.fullPreview();
    }

    public int method_32661(@NotNull class_327 font) {
        return 14 + this.rows() * 18 + 2;
    }

    public int method_32664(@NotNull class_327 font) {
        return 14 + this.columns() * 18;
    }

    public void method_32666(@NotNull class_327 font, int x, int y, int totalWidth, int totalHeight, @NotNull class_332 graphics) {
        int width = this.method_32664(font);
        int height = this.method_32661(font) - 2;
        int mouseX = (graphics instanceof ShulkerPreviewGuiGraphics ext) ? ext.kimiko$getMouseX() : Integer.MIN_VALUE;
        int mouseY = (graphics instanceof ShulkerPreviewGuiGraphics ext) ? ext.kimiko$getMouseY() : Integer.MIN_VALUE;
        ShulkerPreviewHelper.recordTooltipPosition(this.source, x, y);
        graphics.method_52707(class_10799.field_56883, WINDOW_TEXTURE, x, y, width, height, ShulkerPreviewHelper.shulkerColor(this.source));
        for (int slot = 0; slot < this.items.size(); ++slot) {
            class_1799 stack;
            boolean hovered;
            int slotX = x + 8 + slot % this.columns() * 18;
            int slotY = y + 8 + slot / this.columns() * 18;
            boolean bl = hovered = mouseX >= slotX && mouseX < slotX + 16 && mouseY >= slotY && mouseY < slotY + 16;
            if (hovered) {
                graphics.method_52706(class_10799.field_56883, SLOT_HIGHLIGHT_BACK, slotX - 4, slotY - 4, 24, 24);
            }
            if (!(stack = this.items.get(slot)).method_7960()) {
                String count = stack.method_7947() > 1 ? String.valueOf(stack.method_7947()) : "";
                graphics.method_51427(stack, slotX, slotY);
                graphics.method_51432(font, stack, slotX, slotY, count);
            }
            if (!hovered) continue;
            graphics.method_52706(class_10799.field_56883, SLOT_HIGHLIGHT_FRONT, slotX - 4, slotY - 4, 24, 24);
        }
    }

    private int columns() {
        return this.fullPreview ? 9 : Math.max(1, Math.min(9, this.items.size()));
    }

    private int rows() {
        return Math.max(1, (int)Math.ceil((double)this.items.size() / (double)this.columns()));
    }
}

