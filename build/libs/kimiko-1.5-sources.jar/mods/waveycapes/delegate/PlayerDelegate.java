/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.minecraft.entity.PlayerLikeEntity
 *  net.minecraft.client.network.ClientMannequinEntity
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 */
package mods.waveycapes.delegate;

import lombok.Generated;
import mods.waveycapes.versionless.nms.MinecraftPlayer;
import net.minecraft.class_11890;
import net.minecraft.class_11903;
import net.minecraft.class_310;
import net.minecraft.class_742;

public class PlayerDelegate
implements MinecraftPlayer {
    private class_11890 player;

    @Override
    public double getXCloak() {
        float delta = class_310.method_1551().method_61966().method_60637(false);
        class_11890 playerLikeEntity2 = this.player;
        if (playerLikeEntity2 instanceof class_742) {
            class_742 acp = (class_742)playerLikeEntity2;
            return acp.method_74192().method_74200(delta);
        }
        playerLikeEntity2 = this.player;
        if (playerLikeEntity2 instanceof class_11903) {
            class_11903 cm = (class_11903)playerLikeEntity2;
            return cm.method_74192().method_74200(delta);
        }
        return 0.0;
    }

    @Override
    public double getZCloak() {
        float delta = class_310.method_1551().method_61966().method_60637(false);
        class_11890 playerLikeEntity2 = this.player;
        if (playerLikeEntity2 instanceof class_742) {
            class_742 acp = (class_742)playerLikeEntity2;
            return acp.method_74192().method_74202(delta);
        }
        playerLikeEntity2 = this.player;
        if (playerLikeEntity2 instanceof class_11903) {
            class_11903 cm = (class_11903)playerLikeEntity2;
            return cm.method_74192().method_74202(delta);
        }
        return 0.0;
    }

    @Override
    public float getYBodyRotO() {
        return this.player.field_6220;
    }

    @Override
    public float getYBodyRot() {
        return this.player.field_6283;
    }

    @Override
    public double getYo() {
        return this.player.field_6036;
    }

    @Override
    public double getXo() {
        return this.player.field_6014;
    }

    @Override
    public double getZo() {
        return this.player.field_5969;
    }

    @Generated
    public PlayerDelegate(class_11890 player) {
        this.player = player;
    }

    @Generated
    public class_11890 getPlayer() {
        return this.player;
    }

    @Override
    @Generated
    public boolean isVisuallySwimming() {
        return this.getPlayer().method_20232();
    }

    @Override
    @Generated
    public float getXRot() {
        return this.getPlayer().method_36455();
    }

    @Override
    @Generated
    public boolean isCrouching() {
        return this.getPlayer().method_18276();
    }

    @Override
    @Generated
    public double getY() {
        return this.getPlayer().method_23318();
    }

    @Override
    @Generated
    public float getYRot() {
        return this.getPlayer().method_36454();
    }

    @Override
    @Generated
    public double getZ() {
        return this.getPlayer().method_23321();
    }

    @Override
    @Generated
    public double getX() {
        return this.getPlayer().method_23317();
    }

    @Override
    @Generated
    public boolean isUnderWater() {
        return this.getPlayer().method_5869();
    }
}

