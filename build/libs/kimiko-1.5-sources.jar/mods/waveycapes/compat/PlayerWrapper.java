/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.item.equipment.EquipmentAssetKeys
 *  net.minecraft.component.type.EquippableComponent
 *  net.minecraft.entity.PlayerLikeEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.component.DataComponentTypes
 */
package mods.waveycapes.compat;

import net.minecraft.class_10055;
import net.minecraft.class_10191;
import net.minecraft.class_10192;
import net.minecraft.class_11890;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_9334;

public class PlayerWrapper {
    private final class_10055 renderState;
    private final class_11890 avatar;

    public PlayerWrapper(class_10055 renderState) {
        this.renderState = renderState;
        this.avatar = PlayerWrapper.findAvatar(renderState);
    }

    public PlayerWrapper(class_742 player) {
        this.renderState = null;
        this.avatar = player;
    }

    public class_10055 getRenderState() {
        return this.renderState;
    }

    public class_11890 getAvatar() {
        return this.avatar;
    }

    public class_11890 getEntity() {
        return this.avatar;
    }

    public class_2960 getCapeTexture() {
        class_742 player;
        if (this.renderState != null && this.renderState.field_53520 != null && this.renderState.field_53520.comp_1627() != null) {
            return this.renderState.field_53520.comp_1627().comp_3627();
        }
        class_11890 playerLikeEntity2 = this.avatar;
        if (playerLikeEntity2 instanceof class_742 && (player = (class_742)playerLikeEntity2).method_52814().comp_1627() != null) {
            return player.method_52814().comp_1627().comp_3627();
        }
        return null;
    }

    public boolean isCapeVisible() {
        return this.renderState == null || this.renderState.field_53532;
    }

    public boolean isLocalPlayer() {
        class_746 localPlayer = class_310.method_1551().field_1724;
        return localPlayer != null && this.avatar != null && this.avatar.method_5667().equals(localPlayer.method_5667());
    }

    public boolean isPlayerInvisible() {
        return this.renderState != null ? this.renderState.field_53333 || this.renderState.field_53461 : this.avatar != null && this.avatar.method_5767();
    }

    public boolean hasElytraEquipped() {
        if (this.renderState != null) {
            return this.renderState.field_53411 || PlayerWrapper.isElytra(this.renderState.field_53418);
        }
        return false;
    }

    public boolean hasChestplateEquipped() {
        return this.renderState != null && this.renderState.field_53418 != null && !this.renderState.field_53418.method_7960() && !PlayerWrapper.isElytra(this.renderState.field_53418);
    }

    private static class_11890 findAvatar(class_10055 renderState) {
        class_11890 avatar;
        if (renderState == null || class_310.method_1551().field_1687 == null) {
            return null;
        }
        class_1297 entity = class_310.method_1551().field_1687.method_8469(renderState.field_53528);
        return entity instanceof class_11890 ? (avatar = (class_11890)entity) : null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean isElytra(class_1799 stack) {
        if (stack == null) return false;
        if (stack.method_7960()) {
            return false;
        }
        class_10192 equippable = (class_10192)stack.method_58694(class_9334.field_54196);
        if (equippable == null) return false;
        if (equippable.comp_3176().map(class_10191.field_54142::equals).orElse(false) == false) return false;
        return true;
    }
}

