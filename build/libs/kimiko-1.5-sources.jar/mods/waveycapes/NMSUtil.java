/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelTransform
 *  net.minecraft.client.model.Dilation
 *  net.minecraft.client.model.ModelPartBuilder
 *  net.minecraft.client.model.ModelData
 *  net.minecraft.client.model.ModelPartData
 *  net.minecraft.client.model.ModelPart
 */
package mods.waveycapes;

import java.util.function.IntUnaryOperator;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

public class NMSUtil {
    public static class_630[] buildCape(int texWidth, int texHight, IntUnaryOperator uvX, IntUnaryOperator uvY) {
        class_630[] customCape = new class_630[16];
        class_5609 meshDefinition = new class_5609();
        class_5610 partDefinition = meshDefinition.method_32111();
        for (int i = 0; i < 16; ++i) {
            partDefinition.method_32117("customCape_" + i, class_5606.method_32108().method_32101(uvX.applyAsInt(i), uvY.applyAsInt(i)).method_32099(-5.0f, (float)i, -1.0f, 10.0f, 1.0f, 1.0f, class_5605.field_27715, 1.0f, 0.5f), class_5603.method_32090((float)0.0f, (float)0.0f, (float)0.0f));
        }
        class_630 modelPart = partDefinition.method_32112(texWidth, texHight);
        for (int i = 0; i < 16; ++i) {
            customCape[i] = modelPart.method_32086("customCape_" + i);
        }
        return customCape;
    }
}

