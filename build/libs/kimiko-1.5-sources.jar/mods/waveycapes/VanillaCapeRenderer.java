/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.RenderLayers
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.model.ModelPart
 */
package mods.waveycapes;

import mods.waveycapes.CapeRenderer;
import mods.waveycapes.compat.PlayerWrapper;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import rtx.kimiko.utils.render.others.cape.CapeVertexColor;

public class VanillaCapeRenderer
implements CapeRenderer {
    @Override
    public void render(PlayerWrapper capeRenderInfo, int part, class_630 model, class_4587 poseStack, class_4588 vertexConsumer, int light, int overlay) {
        float y = ((float)part + 0.5f) / 16.0f;
        int color = capeRenderInfo.isLocalPlayer() ? CapeVertexColor.at(y, y, 1.0f) : -1;
        model.method_22699(poseStack, vertexConsumer, light, overlay, color);
    }

    @Override
    public class_1921 getRenderType(PlayerWrapper capeRenderInfo) {
        class_2960 cape = capeRenderInfo.getCapeTexture();
        if (cape != null) {
            return class_12249.method_76000((class_2960)cape);
        }
        return null;
    }

    @Override
    public boolean vanillaUvValues() {
        return true;
    }
}

