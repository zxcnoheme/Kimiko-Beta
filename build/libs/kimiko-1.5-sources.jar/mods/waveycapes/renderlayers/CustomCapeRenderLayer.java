/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.entity.Entity
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.render.entity.feature.FeatureRendererContext
 *  net.minecraft.client.render.entity.feature.FeatureRenderer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.entity.model.PlayerEntityModel
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 */
package mods.waveycapes.renderlayers;

import mods.waveycapes.WaveyCapesBase;
import mods.waveycapes.WaveyCapesMod;
import mods.waveycapes.compat.PlayerWrapper;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_742;
import rtx.kimiko.api.modules.impl.Visuals.Customization;

public class CustomCapeRenderLayer
extends class_3887<class_10055, class_591> {
    public CustomCapeRenderLayer(class_3883<class_10055, class_591> renderLayerParent) {
        super(renderLayerParent);
    }

    @Override
    public void render(class_4587 poseStack, class_11659 submitNodeCollector, int packedLight, class_10055 renderState, float f, float g) {
        class_1297 entity;
        PlayerWrapper capeRenderInfo = new PlayerWrapper(renderState);
        float delta = class_310.method_1551().method_61966().method_60637(false);
        if (capeRenderInfo.isPlayerInvisible()) {
            return;
        }
        if (capeRenderInfo.hasElytraEquipped()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 != null && (entity = mc.field_1687.method_8469(renderState.field_53528)) instanceof class_742) {
            class_742 player = (class_742)entity;
            Customization customization = Customization.getInstance();
            if (customization != null && customization.wingsEnabledFor(player)) {
                return;
            }
        }
        if (!capeRenderInfo.isCapeVisible()) {
            return;
        }
        poseStack.method_22903();
        ((class_591)this.method_17165()).method_63512().method_22703(poseStack);
        ((class_591)this.method_17165()).field_3391.method_22703(poseStack);
        if (capeRenderInfo.hasChestplateEquipped()) {
            poseStack.method_46416(0.0f, -0.053125f, 0.06875f);
        }
        if (WaveyCapesBase.INSTANCE == null) {
            WaveyCapesMod.INSTANCE.init();
        }
        if (WaveyCapesBase.INSTANCE != null) {
            WaveyCapesBase.INSTANCE.getRenderer().render(capeRenderInfo, poseStack, submitNodeCollector, packedLight, delta);
        }
        poseStack.method_22909();
    }
}

