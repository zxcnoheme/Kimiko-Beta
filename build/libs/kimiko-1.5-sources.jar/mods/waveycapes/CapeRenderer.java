/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.OverlayTexture
 *  net.minecraft.client.model.ModelPart
 */
package mods.waveycapes;

import mods.waveycapes.compat.PlayerWrapper;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_630;

public interface CapeRenderer {
    default public void render(PlayerWrapper capeRenderInfo, int part, class_630 model, class_4587 poseStack, class_4588 vertexConsumer, int light, int overlay) {
        model.method_22698(poseStack, vertexConsumer, light, class_4608.field_21444);
    }

    public class_1921 getRenderType(PlayerWrapper var1);

    default public boolean vanillaUvValues() {
        return true;
    }
}

