/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.util.math.MatrixStack.Entry
 */
package mods.waveycapes;

import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_10055;
import net.minecraft.class_4587;

public class CapeNodeCollector {
    private final List<CapeNode> capes = new ArrayList<CapeNode>();

    public void submitCape(class_10055 state, class_4587 stack, int packedLight) {
        this.capes.add(new CapeNode(state, stack.method_23760().method_56822(), packedLight));
    }

    public void clear() {
        this.capes.clear();
    }

    @Generated
    public List<CapeNode> getCapes() {
        return this.capes;
    }

    public record CapeNode(class_10055 state, class_4587.class_4665 pose, int packedLight) {
    }
}

