/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.packet.Packet
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package rtx.kimiko.api.events.impl.network;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_2596;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rtx.kimiko.api.events.CancellableEvent;

@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0013\u0012\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0002\u00a2\u0006\u0004\b\u0004\u0010\u0005J\u0011\u0010\u0006\u001a\u0006\u0012\u0002\b\u00030\u0002\u00a2\u0006\u0004\b\u0006\u0010\u0007J\u0019\u0010\t\u001a\u00020\b2\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0002\u00a2\u0006\u0004\b\t\u0010\u0005J+\u0010\r\u001a\u0004\u0018\u00018\u0000\"\f\b\u0000\u0010\n*\u0006\u0012\u0002\b\u00030\u00022\f\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000b\u00a2\u0006\u0004\b\r\u0010\u000eJ!\u0010\u0010\u001a\u00020\u000f2\u0012\u0010\f\u001a\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\u00020\u000b\u00a2\u0006\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u00028\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b\u0003\u0010\u0012\u00a8\u0006\u0013"}, d2={"Lrtx/kimiko/api/events/impl/network/PacketSendEvent;", "Lrtx/kimiko/api/events/CancellableEvent;", "Lnet/minecraft/Packet;", "packet", "<init>", "(Lnet/minecraft/Packet;)V", "getPacket", "()Lnet/minecraft/Packet;", "", "setPacket", "T", "Ljava/lang/Class;", "type", "getPacketAs", "(Ljava/lang/Class;)Lnet/minecraft/Packet;", "", "is", "(Ljava/lang/Class;)Z", "Lnet/minecraft/Packet;", "rtx.kimiko:kimiko"})
public final class PacketSendEvent
extends CancellableEvent {
    @NotNull
    private class_2596<?> packet;

    public PacketSendEvent(@NotNull class_2596<?> packet) {
        Intrinsics.checkNotNullParameter(packet, (String)"packet");
        this.packet = packet;
    }

    @NotNull
    public final class_2596<?> getPacket() {
        return this.packet;
    }

    public final void setPacket(@NotNull class_2596<?> packet) {
        Intrinsics.checkNotNullParameter(packet, (String)"packet");
        this.packet = packet;
    }

    @Nullable
    public final <T extends class_2596<?>> T getPacketAs(@NotNull Class<T> type) {
        class_2596<?> packet2;
        Intrinsics.checkNotNullParameter(type, (String)"type");
        if (type.isInstance(this.packet)) {
            class_2596<?> packet3 = this.packet;
            packet2 = packet3;
            Intrinsics.checkNotNull(packet3, (String)"null cannot be cast to non-null type T of rtx.kimiko.api.events.impl.network.PacketSendEvent.getPacketAs");
        } else {
            packet2 = null;
        }
        return (T)packet2;
    }

    public final boolean is(@NotNull Class<? extends class_2596<?>> type) {
        Intrinsics.checkNotNullParameter(type, (String)"type");
        return type.isInstance(this.packet);
    }
}

