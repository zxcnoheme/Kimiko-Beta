package rtx.kimiko.api.modules.impl.Utils;

import org.jetbrains.annotations.NotNull;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.game.TickEvent;
import rtx.kimiko.api.liteapi.Feature;
import rtx.kimiko.api.modules.Category;
import rtx.kimiko.api.modules.Module;
import mixin.accessor.LivingEntityAccessor;
import mixin.accessor.MinecraftAccessor;
import net.minecraft.class_1802;

@Feature(value={"fastexp"})
public final class FastExp
extends Module {
    public FastExp() {
        super("FastExp", "Убирает задержку при использовании бутылочек опыта.", Category.UTILS);
    }

    @EventHandler
    public void onTick(@NotNull TickEvent tickEvent) {
        boolean bl;
        if (!tickEvent.isPre() || this.mc.field_1724 == null) {
            return;
        }
        boolean bl2 = bl = this.mc.field_1724.method_6047().method_31574(class_1802.field_8287) || this.mc.field_1724.method_6079().method_31574(class_1802.field_8287);
        if (!bl) {
            return;
        }
        ((MinecraftAccessor)(Object)this.mc).kimiko$setRightClickDelay(0);
        ((LivingEntityAccessor)(Object)this.mc.field_1724).kimiko$setAttackAnim(0.0f);
    }
}