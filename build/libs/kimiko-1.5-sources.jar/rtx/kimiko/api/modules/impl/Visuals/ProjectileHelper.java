/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.NoWhenBranchMatchedException
 *  kotlin.enums.EnumEntries
 *  kotlin.enums.EnumEntriesKt
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.entity.projectile.PersistentProjectileEntity
 *  net.minecraft.entity.projectile.thrown.EnderPearlEntity
 *  net.minecraft.entity.projectile.TridentEntity
 *  net.minecraft.entity.projectile.thrown.PotionEntity
 *  net.minecraft.item.BowItem
 *  net.minecraft.item.CrossbowItem
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.item.TridentItem
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Direction
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.hit.HitResult.Type
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.registry.tag.FluidTags
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext.FluidHandling
 *  net.minecraft.world.RaycastContext.ShapeType
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.client.util.math.MatrixStack.Entry
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.VertexConsumerProvider.Immediate
 *  net.minecraft.client.world.ClientWorld
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.jetbrains.annotations.NotNull
 *  org.joml.Matrix4f
 *  org.joml.Vector4f
 *  org.lwjgl.opengl.GL11
 */
package rtx.kimiko.api.modules.impl.Visuals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.render.HudRenderEvent;
import rtx.kimiko.api.events.impl.render.WorldRenderEvent;
import rtx.kimiko.api.liteapi.Feature;
import rtx.kimiko.api.modules.Category;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.settings.Setting;
import rtx.kimiko.api.modules.settings.impl.BooleanSetting;
import rtx.kimiko.api.modules.settings.impl.MultiSelectSetting;
import rtx.kimiko.api.modules.settings.impl.SeparatorSetting;
import rtx.kimiko.api.modules.settings.impl.SliderSetting;
import rtx.kimiko.api.ui.theme.ClientAccent;
import rtx.kimiko.utils.color.ColorEngine;
import rtx.kimiko.utils.render.fonts.Fonts;
import rtx.kimiko.utils.render.others.pipeline.ClientPipelines;
import rtx.kimiko.utils.render.render2d.Render2D;
import sigil.protect.Level;
import sigil.protect.Protect;

@Feature(value={"projectilehelper"})
@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u00ec\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 x2\u00020\u0001:\u0007yz{|}~xB\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\t\u001a\u00020\u0004H\u0017b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078\b\u00a2\u0006\u0004\b\t\u0010\nJ\u000f\u0010\f\u001a\u00020\u000bH\u0014\u00a2\u0006\u0004\b\f\u0010\u0003J+\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\rH\u0003b\u0002\b\u000fb\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078\u0010\u00a2\u0006\u0004\b\u0011\u0010\u0012J\u001f\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0014\u001a\u00020\u0013H\u0002\u00a2\u0006\u0004\b\u0015\u0010\u0016J\u001b\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u0017H\u0003b\u0002\b\u000f\u00a2\u0006\u0004\b\u0018\u0010\u0019J\u0017\u0010\u001b\u001a\u00020\u000b2\u0006\u0010\u001a\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u001b\u0010\u001cJ7\u0010%\u001a\u00020\u000b2\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020\u00132\u0006\u0010 \u001a\u00020\u00132\u0006\u0010\"\u001a\u00020!2\u0006\u0010$\u001a\u00020#H\u0002\u00a2\u0006\u0004\b%\u0010&J7\u0010)\u001a\u00020\u00132\u0006\u0010'\u001a\u00020\u00132\u0006\u0010 \u001a\u00020\u00132\u0006\u0010$\u001a\u00020#H\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078(\u00a2\u0006\u0004\b)\u0010*J\u001f\u0010+\u001a\u00020\u000bH\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078(\u00a2\u0006\u0004\b+\u0010\u0003J9\u0010/\u001a\u0004\u0018\u00010.2\u0006\u0010,\u001a\u00020\u00132\u0006\u0010-\u001a\u00020\u00132\u0006\u0010\u001e\u001a\u00020\u001dH\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078(\u00a2\u0006\u0004\b/\u00100J7\u00109\u001a\u00020\u000b2\u0006\u00102\u001a\u0002012\u0006\u00104\u001a\u0002032\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u00106\u001a\u0002052\u0006\u00108\u001a\u000207H\u0002\u00a2\u0006\u0004\b9\u0010:J?\u0010=\u001a\u00020\u000b2\u0006\u00102\u001a\u0002012\u0006\u00104\u001a\u0002032\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010<\u001a\u00020;H\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078\u0010\u00a2\u0006\u0004\b=\u0010>JG\u0010?\u001a\u00020\u000b2\u0006\u00102\u001a\u0002012\u0006\u00104\u001a\u0002032\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010<\u001a\u00020;2\u0006\u00108\u001a\u000207H\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078\u0010\u00a2\u0006\u0004\b?\u0010@JG\u0010E\u001a\u00020\u000b2\u0006\u00102\u001a\u0002012\u0006\u00104\u001a\u0002032\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010A\u001a\u00020\u00132\u0006\u0010B\u001a\u00020\u00132\u0006\u0010D\u001a\u00020C2\u0006\u00108\u001a\u000207H\u0002\u00a2\u0006\u0004\bE\u0010FJ7\u0010I\u001a\u00020\u000b2\u0006\u00102\u001a\u0002012\u0006\u00104\u001a\u0002032\u0006\u0010G\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010H\u001a\u00020CH\u0002\u00a2\u0006\u0004\bI\u0010JJ\u001f\u0010M\u001a\u00020\u00132\u0006\u0010K\u001a\u00020\u00042\u0006\u0010L\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\bM\u0010NJ\u0019\u0010P\u001a\u0004\u0018\u00010#2\u0006\u0010O\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\bP\u0010QJ#\u0010W\u001a\u0004\u0018\u00010V2\u0006\u0010S\u001a\u00020R2\b\u0010U\u001a\u0004\u0018\u00010TH\u0002\u00a2\u0006\u0004\bW\u0010XJ/\u0010Y\u001a\u00020!2\u0006\u0010S\u001a\u00020R2\u0006\u0010U\u001a\u00020TH\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078(\u00a2\u0006\u0004\bY\u0010ZJA\u0010_\u001a\u0004\u0018\u00010^2\u0006\u0010\\\u001a\u00020[2\u0006\u0010]\u001a\u00020[2\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010G\u001a\u00020\u0013H\u0003b\u000e\b\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078(\u00a2\u0006\u0004\b_\u0010`R\u0014\u0010b\u001a\u00020a8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bb\u0010cR\u0014\u0010e\u001a\u00020d8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\be\u0010fR\u0014\u0010h\u001a\u00020g8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bh\u0010iR\u0014\u0010k\u001a\u00020j8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bk\u0010lR\u0014\u0010m\u001a\u00020j8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bm\u0010lR\u001a\u0010o\u001a\b\u0012\u0004\u0012\u0002050n8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bo\u0010pR\u001a\u0010q\u001a\b\u0012\u0004\u0012\u00020;0n8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bq\u0010pR\u001a\u0010s\u001a\b\u0012\u0004\u0012\u00020r0n8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bs\u0010pR\u001a\u0010u\u001a\b\u0012\u0004\u0012\u00020t0n8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bu\u0010pR\u0014\u0010v\u001a\u00020^8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bv\u0010w\u00ca\u0001\u0011\b\u007f\u0012\r\b\u0006\u0012\t\b\fJ\u0005\b\b(\u0080\u0001\u00a8\u0006\u0081\u0001"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper;", "Lrtx/kimiko/api/modules/Module;", "<init>", "()V", "", "Lsigil/protect/Protect;", "value", "Lsigil/protect/Level;", "CROWN", "fadeOutSeconds", "()F", "", "onDisable", "Lrtx/kimiko/api/events/impl/render/WorldRenderEvent;", "event", "Lrtx/kimiko/api/events/EventHandler;", "STD", "onWorldRender", "(Lrtx/kimiko/api/events/impl/render/WorldRenderEvent;)V", "Lnet/minecraft/Vec3d;", "cameraPos", "collectLabels", "(Lrtx/kimiko/api/events/impl/render/WorldRenderEvent;Lnet/minecraft/Vec3d;)V", "Lrtx/kimiko/api/events/impl/render/HudRenderEvent;", "onHud", "(Lrtx/kimiko/api/events/impl/render/HudRenderEvent;)V", "partial", "predictFromHand", "(F)V", "Lnet/minecraft/Entity;", "shooter", "start", "motion", "", "isEntityProjectile", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;", "profile", "predict", "(Lnet/minecraft/Entity;Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;ZLrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;)V", "prevPos", "MAX", "step", "(Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;)Lnet/minecraft/Vec3d;", "gatherLiving", "from", "to", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$EntityHit;", "firstEntityInPath", "(Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;Lnet/minecraft/Entity;)Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$EntityHit;", "Lnet/minecraft/VertexConsumer;", "consumer", "Lnet/minecraft/MatrixStack$Entry;", "pose", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LineData;", "line", "", "radius", "emitLineTube", "(Lnet/minecraft/VertexConsumer;Lnet/minecraft/MatrixStack$Entry;Lnet/minecraft/Vec3d;Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LineData;D)V", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LandingData;", "data", "renderDisc", "(Lnet/minecraft/VertexConsumer;Lnet/minecraft/MatrixStack$Entry;Lnet/minecraft/Vec3d;Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LandingData;)V", "emitCrossTube", "(Lnet/minecraft/VertexConsumer;Lnet/minecraft/MatrixStack$Entry;Lnet/minecraft/Vec3d;Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LandingData;D)V", "a", "b", "", "color", "straightTube", "(Lnet/minecraft/VertexConsumer;Lnet/minecraft/MatrixStack$Entry;Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;ID)V", "pos", "rawColor", "vertex", "(Lnet/minecraft/VertexConsumer;Lnet/minecraft/MatrixStack$Entry;Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;I)V", "pitch", "yaw", "directionFromRotation", "(FF)Lnet/minecraft/Vec3d;", "entity", "profileFor", "(Lnet/minecraft/Entity;)Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;", "Lnet/minecraft/PlayerEntity;", "player", "Lnet/minecraft/ItemStack;", "stack", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$HandShot;", "handShot", "(Lnet/minecraft/PlayerEntity;Lnet/minecraft/ItemStack;)Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$HandShot;", "isUsing", "(Lnet/minecraft/PlayerEntity;Lnet/minecraft/ItemStack;)Z", "Lorg/joml/Matrix4f;", "positionMatrix", "projectionMatrix", "Lorg/joml/Vector4f;", "project", "(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;)Lorg/joml/Vector4f;", "Lrtx/kimiko/api/modules/settings/impl/SeparatorSetting;", "visualSeparator", "Lrtx/kimiko/api/modules/settings/impl/SeparatorSetting;", "Lrtx/kimiko/api/modules/settings/impl/MultiSelectSetting;", "itemsToPredict", "Lrtx/kimiko/api/modules/settings/impl/MultiSelectSetting;", "Lrtx/kimiko/api/modules/settings/impl/BooleanSetting;", "fromHand", "Lrtx/kimiko/api/modules/settings/impl/BooleanSetting;", "Lrtx/kimiko/api/modules/settings/impl/SliderSetting;", "lineWidth", "Lrtx/kimiko/api/modules/settings/impl/SliderSetting;", "indicatorSize", "", "linesToRender", "Ljava/util/List;", "landingData", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Label;", "labels", "Lnet/minecraft/LivingEntity;", "livingScratch", "projectionScratch", "Lorg/joml/Vector4f;", "Companion", "Profile", "HandShot", "EntityHit", "LineData", "LandingData", "Label", "Lrtx/kimiko/api/liteapi/Feature;", "projectilehelper", "rtx.kimiko:kimiko"})
public final class ProjectileHelper
extends Module {
    @NotNull
    public static final Companion Companion = new Companion(null);
    @NotNull
    private final SeparatorSetting visualSeparator = (SeparatorSetting)this.register((Setting)new SeparatorSetting("Настройка визуала"));
    @NotNull
    private final MultiSelectSetting itemsToPredict;
    @NotNull
    private final BooleanSetting fromHand;
    @NotNull
    private final SliderSetting lineWidth;
    @NotNull
    private final SliderSetting indicatorSize;
    @NotNull
    private final List<LineData> linesToRender;
    @NotNull
    private final List<LandingData> landingData;
    @NotNull
    private final List<Label> labels;
    @NotNull
    private final List<class_1309> livingScratch;
    @NotNull
    private final Vector4f projectionScratch;
    private static final int MAX_STEPS = 200;
    private static final float FONT_SIZE = 6.5f;
    private static final int CROSS_SIDES = 10;
    private static final float FADE_STEPS = 40.0f;
    @NotNull
    private static final float[] CROSS_COS = new float[10];
    @NotNull
    private static final float[] CROSS_SIN = new float[10];
    @NotNull
    private static final String PEARL = "Жемчуг эндера";
    @NotNull
    private static final String ARROW = "Стрелы";
    @NotNull
    private static final String TRIDENT = "Трезубец";
    @NotNull
    private static final String POTION = "Зелья";
    @NotNull
    private static final String ITEM = "Предметы";

    public ProjectileHelper() {
        super("Projectile Helper", "Отрисовывает траекторию полёта снарядов.", Category.VISUALS);
        String[] stringArray = new String[]{PEARL, ARROW, TRIDENT, POTION, ITEM};
        MultiSelectSetting multiSelectSetting = new MultiSelectSetting("Предметы для предсказания", "Какие снаряды предсказывать.").value(stringArray);
        stringArray = new String[]{PEARL, ARROW, TRIDENT, POTION};
        this.itemsToPredict = (MultiSelectSetting)this.register((Setting)multiSelectSetting.selected(stringArray));
        this.fromHand = (BooleanSetting)this.register((Setting)new BooleanSetting("Предсказание из рук", "Предсказывать снаряд в руке.", false));
        this.lineWidth = (SliderSetting)this.register((Setting)new SliderSetting("Толщина линии", "Толщина траектории.").range(0.1f, 0.3f).increment(0.05f).setValue(0.2f));
        this.indicatorSize = (SliderSetting)this.register((Setting)new SliderSetting("Размер индикатора", "Радиус круга приземления.").range(0.3f, 0.5f).increment(0.05f).setValue(0.4f));
        this.linesToRender = new ArrayList();
        this.landingData = new ArrayList();
        this.labels = new ArrayList();
        this.livingScratch = new ArrayList();
        this.projectionScratch = new Vector4f();
    }

    @Override
    @Protect(value=Level.CROWN)
    public float fadeOutSeconds() {
        return 0.5f;
    }

    @Override
    protected void onDisable() {
        this.linesToRender.clear();
        this.landingData.clear();
        this.labels.clear();
        this.livingScratch.clear();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler
    @Protect(value=Level.STD)
    private final void onWorldRender(WorldRenderEvent event) {
        if (event.isPortalPass()) {
            return;
        }
        this.linesToRender.clear();
        this.landingData.clear();
        this.labels.clear();
        class_746 player = this.mc.field_1724;
        class_638 level = this.mc.field_1687;
        if (player == null || level == null) {
            return;
        }
        float partial = class_3532.method_15363((float)event.getPartialTicks(), (float)0.0f, (float)1.0f);
        this.gatherLiving();
        for (class_1297 entity : level.method_18112()) {
            Profile profile = this.profileFor(entity);
            if (profile == null || !this.itemsToPredict.isSelected(profile.getSetting())) continue;
            class_243 motion = entity.method_18798();
            if (motion == null || motion.method_1027() <= 1.0E-6) continue;
            class_243 vec3d2 = entity.method_30950(partial);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"getPosition(...)");
            this.predict(entity, vec3d2, motion, true, profile);
        }
        if (this.fromHand.getValue()) {
            this.predictFromHand(partial);
        }
        class_4184 camera = event.getCamera() == null ? this.mc.field_1773.method_19418() : event.getCamera();
        Intrinsics.checkNotNull((Object)camera);
        class_243 cameraPos = camera.method_71156();
        class_4597.class_4598 immediate2 = this.mc.method_22940().method_23000();
        Intrinsics.checkNotNullExpressionValue((Object)immediate2, (String)"bufferSource(...)");
        class_4597.class_4598 provider = immediate2;
        class_4587.class_4665 entry2 = event.getStack().method_23760();
        Intrinsics.checkNotNullExpressionValue((Object)entry2, (String)"last(...)");
        class_4587.class_4665 pose = entry2;
        double radius = (double)this.lineWidth.getFloat() * 0.05;
        class_4588 vertexConsumer2 = provider.method_73477(ClientPipelines.PROJECTILE_TRIS);
        Intrinsics.checkNotNullExpressionValue((Object)vertexConsumer2, (String)"getBuffer(...)");
        class_4588 tris = vertexConsumer2;
        for (LandingData data : this.landingData) {
            this.renderDisc(tris, pose, cameraPos, data);
        }
        class_4588 vertexConsumer3 = provider.method_73477(ClientPipelines.TARGET_CIRCLE_NODEPTH);
        Intrinsics.checkNotNullExpressionValue((Object)vertexConsumer3, (String)"getBuffer(...)");
        class_4588 tubes = vertexConsumer3;
        for (LineData line : this.linesToRender) {
            this.emitLineTube(tubes, pose, cameraPos, line, radius);
        }
        for (LandingData data : this.landingData) {
            this.emitCrossTube(tubes, pose, cameraPos, data, radius * 0.7);
        }
        GL11.glEnable((int)2881);
        GL11.glHint((int)3155, (int)4354);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        try {
            provider.method_22994(ClientPipelines.PROJECTILE_TRIS);
            provider.method_22994(ClientPipelines.TARGET_CIRCLE_NODEPTH);
        }
        finally {
            GL11.glDisable((int)2881);
            GL11.glDisable((int)2848);
        }
        this.collectLabels(event, cameraPos);
    }

    private final void collectLabels(WorldRenderEvent event, class_243 cameraPos) {
        Matrix4f positionMatrix = event.getPositionMatrix();
        Matrix4f projectionMatrix = event.getProjectionMatrix();
        float screenWidth = rtx.kimiko.api.drags.Position.Companion.screenWidth();
        float screenHeight = rtx.kimiko.api.drags.Position.Companion.screenHeight();
        for (LandingData data : this.landingData) {
            if (!data.isEntity()) continue;
            Vector4f projected = this.project(positionMatrix, projectionMatrix, cameraPos, data.getPos());
            if (projected == null) continue;
            float screenX = (projected.x / projected.w * 0.5f + 0.5f) * screenWidth;
            float screenY = (1.0f - (projected.y / projected.w * 0.5f + 0.5f)) * screenHeight;
            if (Float.isNaN(screenX) || Float.isNaN(screenY)) continue;
            this.labels.add(new Label(screenX, screenY, data.getTicks()));
        }
    }

    @EventHandler
    private final void onHud(HudRenderEvent event) {
        if (this.labels.isEmpty()) {
            return;
        }
        class_332 graphics = event.getGraphics();
        Render2D.beginFrame(graphics);
        for (Label label : this.labels) {
            double seconds = (double)(label.getTicks() * 50) / 1000.0;
            Locale locale = Locale.US;
            String string = "%.1f";
            Object[] objectArray = new Object[]{seconds};
            String string2 = String.format(locale, string, Arrays.copyOf(objectArray, objectArray.length));
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"format(...)");
            String text = string2 + "s";
            float textWidth = Fonts.SEMIBOLD.msdfWidth(text, 6.5f);
            float boxWidth = textWidth + 8.0f;
            float boxX = label.getX() - boxWidth / 2.0f;
            float boxY = label.getY() - 7.25f;
            Render2D.rect(boxX, boxY + 3.0f, boxWidth, 8.5f, ColorEngine.rgba(0, 0, 0, 128));
            Fonts.SEMIBOLD.msdf(text, boxX + (boxWidth - textWidth) / 2.0f, boxY + 4.0f, 6.5f, -1);
        }
        Render2D.flush();
    }

    private final void predictFromHand(float partial) {
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_1799 itemStack2 = player.method_6047();
        Intrinsics.checkNotNullExpressionValue((Object)itemStack2, (String)"getMainHandItem(...)");
        class_1799 stack = itemStack2;
        HandShot handShot = this.handShot((class_1657)player, stack);
        if (handShot == null) {
            return;
        }
        HandShot shot = handShot;
        class_243 look = this.directionFromRotation(player.method_36455(), player.method_36454());
        class_243 vec3d2 = player.method_5836(partial).method_1019(look.method_1021(0.2));
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"add(...)");
        class_243 start = vec3d2;
        class_243 vec3d3 = look.method_1021(shot.getSpeed()).method_1031(0.0, player.method_18798().field_1351 * 0.5, 0.0);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"add(...)");
        class_243 motion = vec3d3;
        this.predict((class_1297)player, start, motion, false, shot.getProfile());
    }

    private final void predict(class_1297 shooter, class_243 start, class_243 motion, boolean isEntityProjectile, Profile profile) {
        List points = new ArrayList();
        class_243 pos = start;
        class_243 vel = motion;
        int ticks = 0;
        class_243 finalPos = pos;
        class_243 normal = new class_243(0.0, 1.0, 0.0);
        boolean living = false;
        boolean stopped = false;
        for (int i = 0; i < 200; ++i) {
            class_3965 blockHit;
            class_638 level;
            points.add(pos);
            class_243 prev = pos;
            Intrinsics.checkNotNullExpressionValue((Object)pos.method_1019(vel), (String)"add(...)");
            ++ticks;
            EntityHit entityHit = this.firstEntityInPath(prev, pos, shooter);
            if (entityHit != null) {
                class_243 vec3d2;
                finalPos = entityHit.getPoint();
                living = true;
                if (vel.method_1027() > 1.0E-9) {
                    class_243 vec3d3 = vel.method_1029().method_1021(-1.0);
                    vec3d2 = vec3d3;
                    Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"scale(...)");
                } else {
                    vec3d2 = normal;
                }
                normal = vec3d2;
                stopped = true;
                break;
            }
            class_638 clientWorld3 = level = this.mc.field_1687;
            class_3965 blockHitResult2 = blockHit = clientWorld3 != null ? clientWorld3.method_17742(new class_3959(prev, pos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, shooter)) : null;
            if (blockHit != null && blockHit.method_17783() != class_239.class_240.field_1333) {
                class_243 vec3d4 = blockHit.method_17784();
                Intrinsics.checkNotNullExpressionValue((Object)vec3d4, (String)"getLocation(...)");
                finalPos = vec3d4;
                class_2350 direction2 = blockHit.method_17780();
                Intrinsics.checkNotNullExpressionValue((Object)direction2, (String)"getDirection(...)");
                normal = ProjectileHelper.Companion.faceToNormal(direction2);
                stopped = true;
                break;
            }
            if (pos.field_1351 < -128.0) {
                finalPos = pos;
                stopped = true;
                break;
            }
            vel = this.step(prev, vel, profile);
        }
        if (!stopped) {
            finalPos = pos;
        }
        this.linesToRender.add(new LineData(points, finalPos));
        this.landingData.add(new LandingData(finalPos, ticks, isEntityProjectile, normal, living));
    }

    @Protect(value=Level.MAX)
    private final class_243 step(class_243 prevPos, class_243 motion, Profile profile) {
        class_638 level = this.mc.field_1687;
        boolean water = level != null && level.method_8316(class_2338.method_49638((class_2374)((class_2374)prevPos))).method_15767(class_3486.field_15517);
        double drag = water ? profile.getWaterDrag() : profile.getDrag();
        class_243 vec3d2 = motion.method_1021(drag).method_1023(0.0, profile.getGravity(), 0.0);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"subtract(...)");
        return vec3d2;
    }

    @Protect(value=Level.MAX)
    private final void gatherLiving() {
        this.livingScratch.clear();
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return;
        }
        class_638 level = clientWorld3;
        for (Object t : level.method_18112()) {
            Intrinsics.checkNotNullExpressionValue(t, (String)"next(...)");
            class_1297 entity = (class_1297)t;
            if (!(entity instanceof class_1309) || !((class_1309)entity).method_5805()) continue;
            this.livingScratch.add((class_1309)entity);
        }
    }

    @Protect(value=Level.MAX)
    private final EntityHit firstEntityInPath(class_243 from, class_243 to, class_1297 shooter) {
        double best = Double.MAX_VALUE;
        class_1309 found = null;
        class_243 point = null;
        for (class_1309 living : this.livingScratch) {
            if (Intrinsics.areEqual((Object)living, (Object)shooter)) continue;
            Optional<class_243> hit = living.method_5829().method_1014(0.1).method_992(from, to);
            if (!hit.isPresent()) continue;
            class_243 hitPoint = hit.get();
            double dist = from.method_1025(hitPoint);
            if (dist < best) {
                best = dist;
                found = living;
                point = hitPoint;
            }
        }
        return found != null && point != null ? new EntityHit(found, point) : null;
    }

    private final void emitLineTube(class_4588 consumer, class_4587.class_4665 pose, class_243 cameraPos, LineData line, double radius) {
        List<class_243> src = line.getPoints();
        int base = src.size();
        if (base == 0) {
            return;
        }
        int m = base + 1;
        if (m < 2) {
            return;
        }
        class_243[] p = new class_243[m];
        for (int k = 0; k < base; ++k) {
            p[k] = src.get(k);
        }
        p[base] = line.getFinalPos();
        class_243[] tangent = new class_243[m];
        for (int k = 0; k < m; ++k) {
            class_243 a = (k > 0) ? p[k].method_1020(p[k - 1]) : p[1].method_1020(p[0]);
            class_243 b = (k < m - 1) ? p[k + 1].method_1020(p[k]) : p[k].method_1020(p[k - 1]);
            class_243 t = a.method_1019(b);
            tangent[k] = t.method_1027() > 1.0E-9 ? t.method_1029() : (b.method_1027() > 1.0E-9 ? b.method_1029() : new class_243(0.0, 0.0, 1.0));
        }
        class_243 frameNormal = ProjectileHelper.Companion.anyPerpendicular(tangent[0]).method_1029();
        class_243[] prevRing = null;
        int[] prevColor = null;
        for (int k = 0; k < m; ++k) {
            class_243 pk = p[k];
            class_243 tk = tangent[k];
            if (k > 0) {
                class_243 projected = frameNormal.method_1020(tk.method_1021(frameNormal.method_1026(tk)));
                frameNormal = (projected.method_1027() > 1.0E-9)
                    ? projected.method_1029()
                    : ProjectileHelper.Companion.anyPerpendicular(tk).method_1029();
            }
            class_243 binormal = tk.method_1036(frameNormal).method_1029();
            class_243 toCamera = cameraPos.method_1020(pk);
            double camLen = toCamera.method_1033();
            class_243 camDir = camLen > 1.0E-6 ? toCamera.method_1021(1.0 / camLen) : new class_243(0.0, 1.0, 0.0);
            float envAlpha = ProjectileHelper.Companion.relakeAlpha(k);
            float gradientPos = (float)k / (float)(m - 1);
            int rgb = ClientAccent.gradientColor(gradientPos, 255.0f) & 0xFFFFFF;
            class_243[] ring = new class_243[10];
            int[] ringColor = new int[10];
            for (int j = 0; j < 10; ++j) {
                class_243 offset = ProjectileHelper.Companion.ringOffset(frameNormal, binormal, j, radius);
                ring[j] = pk.method_1019(offset);
                double facing = radius > 1.0E-9 ? class_3532.method_15350((double)(offset.method_1026(camDir) / radius), (double)0.0, (double)1.0) : 0.0;
                float nearFactor = 1.0f - 0.5f * (float)facing;
                ringColor[j] = rgb | ProjectileHelper.Companion.alpha255(envAlpha * nearFactor) << 24;
            }
            if (prevRing != null && prevColor != null) {
                for (int j = 0; j < 10; ++j) {
                    int n = (j + 1) % 10;
                    class_243 vec3d20 = prevRing[j];
                    Intrinsics.checkNotNull((Object)vec3d20);
                    this.vertex(consumer, pose, vec3d20, cameraPos, prevColor[j]);
                    class_243 vec3d21 = prevRing[n];
                    Intrinsics.checkNotNull((Object)vec3d21);
                    this.vertex(consumer, pose, vec3d21, cameraPos, prevColor[n]);
                    class_243 vec3d22 = ring[n];
                    Intrinsics.checkNotNull((Object)vec3d22);
                    this.vertex(consumer, pose, vec3d22, cameraPos, ringColor[n]);
                    class_243 vec3d23 = ring[j];
                    Intrinsics.checkNotNull((Object)vec3d23);
                    this.vertex(consumer, pose, vec3d23, cameraPos, ringColor[j]);
                }
            }
            prevRing = ring;
            prevColor = ringColor;
        }
    }

    @Protect(value=Level.STD)
    private final void renderDisc(class_4588 consumer, class_4587.class_4665 pose, class_243 cameraPos, LandingData data) {
        class_243 center = data.getPos();
        class_243 normal = data.getNormal();
        double radius = this.indicatorSize.getFloat();
        float spin = (float)(System.currentTimeMillis() % 4000L) / 4000.0f;
        int centerColor = ColorEngine.multAlpha(ClientAccent.gradientColor(ProjectileHelper.Companion.pingPong(spin), 255.0f), 0.55f);
        class_243 vec3d2 = ProjectileHelper.Companion.anyPerpendicular(normal).method_1029();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"normalize(...)");
        class_243 axis1 = vec3d2;
        class_243 vec3d3 = normal.method_1036(axis1).method_1029();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"normalize(...)");
        class_243 axis2 = vec3d3;
        int segments = 48;
        for (int i = 0; i < segments; ++i) {
            double a1 = Math.PI * 2 * (double)i / (double)segments;
            double a2 = Math.PI * 2 * (double)(i + 1) / (double)segments;
            int c1 = ColorEngine.multAlpha(ClientAccent.gradientColor(ProjectileHelper.Companion.pingPong(spin + (float)i / (float)segments), 255.0f), 0.22f);
            int c2 = ColorEngine.multAlpha(ClientAccent.gradientColor(ProjectileHelper.Companion.pingPong(spin + (float)(i + 1) / (float)segments), 255.0f), 0.22f);
            class_243 p1 = center.method_1019(ProjectileHelper.Companion.ringOffset(axis1, axis2, a1, radius));
            class_243 p2 = center.method_1019(ProjectileHelper.Companion.ringOffset(axis1, axis2, a2, radius));
            this.vertex(consumer, pose, center, cameraPos, centerColor);
            this.vertex(consumer, pose, p1, cameraPos, c1);
            this.vertex(consumer, pose, p2, cameraPos, c2);
        }
    }

    @Protect(value=Level.STD)
    private final void emitCrossTube(class_4588 consumer, class_4587.class_4665 pose, class_243 cameraPos, LandingData data, double radius) {
        class_243 center = data.getPos();
        class_243 normal = data.getNormal();
        int color = ColorEngine.multAlpha(ClientAccent.accentOpaque(), 0.6f);
        class_243 vec3d2 = ProjectileHelper.Companion.anyPerpendicular(normal).method_1029().method_1021(0.15);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"scale(...)");
        class_243 axis1 = vec3d2;
        class_243 vec3d3 = normal.method_1036(axis1).method_1029().method_1021(0.15);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"scale(...)");
        class_243 axis2 = vec3d3;
        class_243 vec3d4 = center.method_1019(axis1);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d4, (String)"add(...)");
        class_243 vec3d5 = center.method_1020(axis1);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d5, (String)"subtract(...)");
        this.straightTube(consumer, pose, cameraPos, vec3d4, vec3d5, color, radius);
        class_243 vec3d6 = center.method_1019(axis2);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d6, (String)"add(...)");
        class_243 vec3d7 = center.method_1020(axis2);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d7, (String)"subtract(...)");
        this.straightTube(consumer, pose, cameraPos, vec3d6, vec3d7, color, radius);
    }

    private final void straightTube(class_4588 consumer, class_4587.class_4665 pose, class_243 cameraPos, class_243 a, class_243 b, int color, double radius) {
        class_243 vec3d2 = b.method_1020(a);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"subtract(...)");
        class_243 dir = vec3d2;
        if (dir.method_1027() < 1.0E-9) {
            return;
        }
        class_243 vec3d3 = dir.method_1029();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"normalize(...)");
        dir = vec3d3;
        class_243 vec3d4 = ProjectileHelper.Companion.anyPerpendicular(dir).method_1029();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d4, (String)"normalize(...)");
        class_243 frameNormal = vec3d4;
        class_243 vec3d5 = dir.method_1036(frameNormal).method_1029();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d5, (String)"normalize(...)");
        class_243 binormal = vec3d5;
        for (int j = 0; j < 10; ++j) {
            int n = (j + 1) % 10;
            class_243 oJ = ProjectileHelper.Companion.ringOffset(frameNormal, binormal, j, radius);
            class_243 oN = ProjectileHelper.Companion.ringOffset(frameNormal, binormal, n, radius);
            class_243 vec3d6 = a.method_1019(oJ);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d6, (String)"add(...)");
            this.vertex(consumer, pose, vec3d6, cameraPos, color);
            class_243 vec3d7 = a.method_1019(oN);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d7, (String)"add(...)");
            this.vertex(consumer, pose, vec3d7, cameraPos, color);
            class_243 vec3d8 = b.method_1019(oN);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d8, (String)"add(...)");
            this.vertex(consumer, pose, vec3d8, cameraPos, color);
            class_243 vec3d9 = b.method_1019(oJ);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d9, (String)"add(...)");
            this.vertex(consumer, pose, vec3d9, cameraPos, color);
        }
    }

    private final void vertex(class_4588 consumer, class_4587.class_4665 pose, class_243 pos, class_243 cameraPos, int rawColor) {
        int color = ColorEngine.multAlpha(rawColor, this.visualAlpha());
        consumer.method_56824(pose, (float)(pos.field_1352 - cameraPos.field_1352), (float)(pos.field_1351 - cameraPos.field_1351), (float)(pos.field_1350 - cameraPos.field_1350)).method_39415(color);
    }

    private final class_243 directionFromRotation(float pitch, float yaw) {
        float pitchRad = pitch * ((float)Math.PI / 180);
        float yawRad = -yaw * ((float)Math.PI / 180);
        double cosPitch = Math.cos(pitchRad);
        class_243 vec3d2 = new class_243(Math.sin(yawRad) * cosPitch, -Math.sin(pitchRad), Math.cos(yawRad) * cosPitch).method_1029();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"normalize(...)");
        return vec3d2;
    }

    private final Profile profileFor(class_1297 entity) {
        if (entity instanceof class_1684) {
            return Profile.PEARL;
        }
        if (entity instanceof class_1685) {
            return Profile.TRIDENT;
        }
        if (entity instanceof class_1665) {
            return Profile.ARROW;
        }
        if (entity instanceof class_1686) {
            return Profile.POTION;
        }
        if (entity instanceof class_1542) {
            return Profile.ITEM;
        }
        return null;
    }

    private final HandShot handShot(class_1657 player, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return null;
        }
        class_1792 item2 = stack.method_7909();
        Intrinsics.checkNotNullExpressionValue((Object)item2, (String)"getItem(...)");
        class_1792 item = item2;
        if (item == class_1802.field_8634) {
            return new HandShot(Profile.PEARL, 1.5);
        }
        if (item == class_1802.field_8436 || item == class_1802.field_8150) {
            return new HandShot(Profile.POTION, 0.5);
        }
        if (item instanceof class_1764) {
            return new HandShot(Profile.ARROW, 3.15);
        }
        if (item instanceof class_1753) {
            if (!this.isUsing(player, stack)) {
                return null;
            }
            float power = Math.max(0.05f, class_1753.method_7722((int)player.method_6048()));
            return new HandShot(Profile.ARROW, 3.0 * (double)power);
        }
        if (item instanceof class_1835) {
            if (!this.isUsing(player, stack)) {
                return null;
            }
            float force = class_3532.method_15363((float)((float)player.method_6048() / 10.0f), (float)0.1f, (float)1.0f);
            return new HandShot(Profile.TRIDENT, 2.5 * (double)force);
        }
        return null;
    }

    @Protect(value=Level.MAX)
    private final boolean isUsing(class_1657 player, class_1799 stack) {
        return player.method_6115() && !player.method_6030().method_7960() && player.method_6030().method_7909() == stack.method_7909();
    }

    @Protect(value=Level.MAX)
    private final Vector4f project(Matrix4f positionMatrix, Matrix4f projectionMatrix, class_243 cameraPos, class_243 pos) {
        Vector4f vec = this.projectionScratch.set((float)(pos.field_1352 - cameraPos.field_1352), (float)(pos.field_1351 - cameraPos.field_1351), (float)(pos.field_1350 - cameraPos.field_1350), 1.0f);
        positionMatrix.transform(vec);
        projectionMatrix.transform(vec);
        if (vec.w <= 1.0E-4f) {
            return null;
        }
        return vec;
    }

    static {
        for (int i = 0; i < 10; ++i) {
            double a = Math.PI * 2 * (double)i / (double)10;
            ProjectileHelper.CROSS_COS[i] = (float)Math.cos(a);
            ProjectileHelper.CROSS_SIN[i] = (float)Math.sin(a);
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0014\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0006\u0010\u0007J/\u0010\u000e\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bH\u0002\u00a2\u0006\u0004\b\u000e\u0010\u000fJ/\u0010\u000e\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000bH\u0002\u00a2\u0006\u0004\b\u000e\u0010\u0012J\u0017\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0010H\u0002\u00a2\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u0016\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u001a\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\bH\u0002\u00a2\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001e\u001a\u00020\b2\u0006\u0010\u001d\u001a\u00020\u001cH\u0002\u00a2\u0006\u0004\b\u001e\u0010\u001fR\u0014\u0010 \u001a\u00020\u00108\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b \u0010!R\u0014\u0010\"\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\"\u0010#R\u0014\u0010$\u001a\u00020\u00108\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b$\u0010!R\u0014\u0010%\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b%\u0010#R\u0014\u0010'\u001a\u00020&8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b'\u0010(R\u0014\u0010)\u001a\u00020&8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b)\u0010(R\u0014\u0010+\u001a\u00020*8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b+\u0010,R\u0014\u0010-\u001a\u00020*8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b-\u0010,R\u0014\u0010.\u001a\u00020*8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b.\u0010,R\u0014\u0010/\u001a\u00020*8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b/\u0010,R\u0014\u00100\u001a\u00020*8\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b0\u0010,\u00a8\u00061"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper.Companion;", "", "<init>", "()V", "", "x", "pingPong", "(F)F", "Lnet/minecraft/Vec3d;", "axis1", "axis2", "", "angle", "radius", "ringOffset", "(Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;DD)Lnet/minecraft/Vec3d;", "", "side", "(Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;ID)Lnet/minecraft/Vec3d;", "index", "relakeAlpha", "(I)F", "value", "alpha255", "(F)I", "normal", "anyPerpendicular", "(Lnet/minecraft/Vec3d;)Lnet/minecraft/Vec3d;", "Lnet/minecraft/Direction;", "face", "faceToNormal", "(Lnet/minecraft/Direction;)Lnet/minecraft/Vec3d;", "MAX_STEPS", "I", "FONT_SIZE", "F", "CROSS_SIDES", "FADE_STEPS", "", "CROSS_COS", "[F", "CROSS_SIN", "", "PEARL", "Ljava/lang/String;", "ARROW", "TRIDENT", "POTION", "ITEM", "rtx.kimiko:kimiko"})
    public static final class Companion {
        private Companion() {
        }

        private final float pingPong(float x) {
            float f = class_3532.method_22450((float)x);
            return f < 0.5f ? f * 2.0f : (1.0f - f) * 2.0f;
        }

        private final class_243 ringOffset(class_243 axis1, class_243 axis2, double angle, double radius) {
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            class_243 vec3d2 = axis1.method_1021(radius * cos).method_1019(axis2.method_1021(radius * sin));
            Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"add(...)");
            return vec3d2;
        }

        private final class_243 ringOffset(class_243 axis1, class_243 axis2, int side, double radius) {
            class_243 vec3d2 = axis1.method_1021((double)CROSS_COS[side] * radius).method_1019(axis2.method_1021((double)CROSS_SIN[side] * radius));
            Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"add(...)");
            return vec3d2;
        }

        private final float relakeAlpha(int index) {
            return class_3532.method_15363((float)((float)index / 40.0f), (float)0.0f, (float)1.0f);
        }

        private final int alpha255(float value) {
            return class_3532.method_15340((int)Math.round(value * 255.0f), (int)0, (int)255);
        }

        private final class_243 anyPerpendicular(class_243 normal) {
            class_243 reference = Math.abs(normal.field_1351) < 0.9 ? new class_243(0.0, 1.0, 0.0) : new class_243(1.0, 0.0, 0.0);
            class_243 vec3d2 = reference.method_1036(normal);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"cross(...)");
            return vec3d2;
        }

        private final class_243 faceToNormal(class_2350 face) {
            return switch (WhenMappings.$EnumSwitchMapping$0[face.ordinal()]) {
                case 1 -> new class_243(0.0, 1.0, 0.0);
                case 2 -> new class_243(0.0, -1.0, 0.0);
                case 3 -> new class_243(0.0, 0.0, -1.0);
                case 4 -> new class_243(0.0, 0.0, 1.0);
                case 5 -> new class_243(-1.0, 0.0, 0.0);
                case 6 -> new class_243(1.0, 0.0, 0.0);
                default -> throw new NoWhenBranchMatchedException();
            };
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }

        @Metadata(mv={2, 4, 0}, k=3, xi=48)
        public static final class WhenMappings {
            public static final /* synthetic */ int[] $EnumSwitchMapping$0;

            static {
                int[] nArray = new int[class_2350.values().length];
                try {
                    nArray[class_2350.field_11036.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                try {
                    nArray[class_2350.field_11033.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                try {
                    nArray[class_2350.field_11043.ordinal()] = 3;
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                try {
                    nArray[class_2350.field_11035.ordinal()] = 4;
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                try {
                    nArray[class_2350.field_11039.ordinal()] = 5;
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                try {
                    nArray[class_2350.field_11034.ordinal()] = 6;
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                $EnumSwitchMapping$0 = nArray;
            }
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\b\u0006\u0010\u0007R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0003\u0010\b\u001a\u0004\b\t\u0010\nR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\f\n\u0004\b\u0005\u0010\u000b\u001a\u0004\b\f\u0010\r\u00a8\u0006\u000e"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$EntityHit;", "", "Lnet/minecraft/LivingEntity;", "entity", "Lnet/minecraft/Vec3d;", "point", "<init>", "(Lnet/minecraft/LivingEntity;Lnet/minecraft/Vec3d;)V", "Lnet/minecraft/LivingEntity;", "getEntity", "()Lnet/minecraft/LivingEntity;", "Lnet/minecraft/Vec3d;", "getPoint", "()Lnet/minecraft/Vec3d;", "rtx.kimiko:kimiko"})
    private static final class EntityHit {
        @NotNull
        private final class_1309 entity;
        @NotNull
        private final class_243 point;

        public EntityHit(@NotNull class_1309 entity, @NotNull class_243 point) {
            Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
            Intrinsics.checkNotNullParameter((Object)point, (String)"point");
            this.entity = entity;
            this.point = point;
        }

        @NotNull
        public final class_1309 getEntity() {
            return this.entity;
        }

        @NotNull
        public final class_243 getPoint() {
            return this.point;
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\n\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\b\u0006\u0010\u0007R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0003\u0010\b\u001a\u0004\b\t\u0010\nR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\f\n\u0004\b\u0005\u0010\u000b\u001a\u0004\b\f\u0010\r\u00a8\u0006\u000e"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$HandShot;", "", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;", "profile", "", "speed", "<init>", "(Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;D)V", "Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;", "getProfile", "()Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;", "D", "getSpeed", "()D", "rtx.kimiko:kimiko"})
    private static final class HandShot {
        @NotNull
        private final Profile profile;
        private final double speed;

        public HandShot(@NotNull Profile profile, double speed) {
            Intrinsics.checkNotNullParameter((Object)((Object)profile), (String)"profile");
            this.profile = profile;
            this.speed = speed;
        }

        @NotNull
        public final Profile getProfile() {
            return this.profile;
        }

        public final double getSpeed() {
            return this.speed;
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000b\b\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\b\u0007\u0010\bR\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0003\u0010\t\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\u0004\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0004\u0010\t\u001a\u0004\b\f\u0010\u000bR\u0017\u0010\u0006\u001a\u00020\u00058\u0006\u00a2\u0006\f\n\u0004\b\u0006\u0010\r\u001a\u0004\b\u000e\u0010\u000f\u00a8\u0006\u0010"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Label;", "", "", "x", "y", "", "ticks", "<init>", "(FFI)V", "F", "getX", "()F", "getY", "I", "getTicks", "()I", "rtx.kimiko:kimiko"})
    private static final class Label {
        private final float x;
        private final float y;
        private final int ticks;

        public Label(float x, float y, int ticks) {
            this.x = x;
            this.y = y;
            this.ticks = ticks;
        }

        public final float getX() {
            return this.x;
        }

        public final float getY() {
            return this.y;
        }

        public final int getTicks() {
            return this.ticks;
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0010\b\u0002\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0006\u00a2\u0006\u0004\b\n\u0010\u000bR\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0003\u0010\f\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\f\n\u0004\b\u0005\u0010\u000f\u001a\u0004\b\u0010\u0010\u0011R\u0017\u0010\u0007\u001a\u00020\u00068\u0006\u00a2\u0006\f\n\u0004\b\u0007\u0010\u0012\u001a\u0004\b\u0007\u0010\u0013R\u0017\u0010\b\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\b\u0010\f\u001a\u0004\b\u0014\u0010\u000eR\u0017\u0010\t\u001a\u00020\u00068\u0006\u00a2\u0006\f\n\u0004\b\t\u0010\u0012\u001a\u0004\b\u0015\u0010\u0013\u00a8\u0006\u0016"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LandingData;", "", "Lnet/minecraft/Vec3d;", "pos", "", "ticks", "", "isEntity", "normal", "living", "<init>", "(Lnet/minecraft/Vec3d;IZLnet/minecraft/Vec3d;Z)V", "Lnet/minecraft/Vec3d;", "getPos", "()Lnet/minecraft/Vec3d;", "I", "getTicks", "()I", "Z", "()Z", "getNormal", "getLiving", "rtx.kimiko:kimiko"})
    private static final class LandingData {
        @NotNull
        private final class_243 pos;
        private final int ticks;
        private final boolean isEntity;
        @NotNull
        private final class_243 normal;
        private final boolean living;

        public LandingData(@NotNull class_243 pos, int ticks, boolean isEntity, @NotNull class_243 normal, boolean living) {
            Intrinsics.checkNotNullParameter((Object)pos, (String)"pos");
            Intrinsics.checkNotNullParameter((Object)normal, (String)"normal");
            this.pos = pos;
            this.ticks = ticks;
            this.isEntity = isEntity;
            this.normal = normal;
            this.living = living;
        }

        @NotNull
        public final class_243 getPos() {
            return this.pos;
        }

        public final int getTicks() {
            return this.ticks;
        }

        public final boolean isEntity() {
            return this.isEntity;
        }

        @NotNull
        public final class_243 getNormal() {
            return this.normal;
        }

        public final boolean getLiving() {
            return this.living;
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000b\b\u0002\u0018\u00002\u00020\u0001B\u001d\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0004\b\u0006\u0010\u0007R\u001d\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0004\u0010\b\u001a\u0004\b\t\u0010\nR\u0017\u0010\u0005\u001a\u00020\u00038\u0006\u00a2\u0006\f\n\u0004\b\u0005\u0010\u000b\u001a\u0004\b\f\u0010\r\u00a8\u0006\u000e"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$LineData;", "", "", "Lnet/minecraft/Vec3d;", "points", "finalPos", "<init>", "(Ljava/util/List;Lnet/minecraft/Vec3d;)V", "Ljava/util/List;", "getPoints", "()Ljava/util/List;", "Lnet/minecraft/Vec3d;", "getFinalPos", "()Lnet/minecraft/Vec3d;", "rtx.kimiko:kimiko"})
    private static final class LineData {
        @NotNull
        private final List<class_243> points;
        @NotNull
        private final class_243 finalPos;

        public LineData(@NotNull List<class_243> points, @NotNull class_243 finalPos) {
            Intrinsics.checkNotNullParameter(points, (String)"points");
            Intrinsics.checkNotNullParameter((Object)finalPos, (String)"finalPos");
            this.points = points;
            this.finalPos = finalPos;
        }

        @NotNull
        public final List<class_243> getPoints() {
            return this.points;
        }

        @NotNull
        public final class_243 getFinalPos() {
            return this.finalPos;
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0013\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B)\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\u0004\b\b\u0010\tR\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\f\n\u0004\b\u0003\u0010\n\u001a\u0004\b\u000b\u0010\fR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\f\n\u0004\b\u0005\u0010\r\u001a\u0004\b\u000e\u0010\u000fR\u0017\u0010\u0006\u001a\u00020\u00048\u0006\u00a2\u0006\f\n\u0004\b\u0006\u0010\r\u001a\u0004\b\u0010\u0010\u000fR\u0017\u0010\u0007\u001a\u00020\u00048\u0006\u00a2\u0006\f\n\u0004\b\u0007\u0010\r\u001a\u0004\b\u0011\u0010\u000fj\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016\u00a8\u0006\u0017"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/ProjectileHelper$Profile;", "", "", "setting", "", "drag", "gravity", "waterDrag", "<init>", "(Ljava/lang/String;ILjava/lang/String;DDD)V", "Ljava/lang/String;", "getSetting", "()Ljava/lang/String;", "D", "getDrag", "()D", "getGravity", "getWaterDrag", "PEARL", "ARROW", "TRIDENT", "POTION", "ITEM", "rtx.kimiko:kimiko"})
    private static enum Profile {
        PEARL("Жемчуг эндера", 0.99, 0.03, 0.8),
        ARROW("Стрелы", 0.99, 0.05, 0.6),
        TRIDENT("Трезубец", 0.99, 0.05, 0.99),
        POTION("Зелья", 0.99, 0.05, 0.8),
        ITEM("Предметы", 0.98, 0.04, 0.99);
@NotNull
        private final String setting;
        private final double drag;
        private final double gravity;
        private final double waterDrag;
        
        
        
        
        
        
        private Profile(String setting, double drag, double gravity, double waterDrag) {
            this.setting = setting;
            this.drag = drag;
            this.gravity = gravity;
            this.waterDrag = waterDrag;
        }

        @NotNull
        public final String getSetting() {
            return this.setting;
        }

        public final double getDrag() {
            return this.drag;
        }

        public final double getGravity() {
            return this.gravity;
        }

        public final double getWaterDrag() {
            return this.waterDrag;
        }

        

        

        @NotNull
        public static EnumEntries<Profile> getEntries() {
            return EnumEntriesKt.enumEntries(values());
        }

            
    }
}

