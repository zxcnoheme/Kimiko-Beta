/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.entity.Entity
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.render.entity.model.ModelWithHead
 *  net.minecraft.client.render.entity.feature.FeatureRendererContext
 *  net.minecraft.client.render.entity.feature.FeatureRenderer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.entity.model.BipedEntityModel
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.world.ClientWorld
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.util.math.RotationAxis
 *  org.jetbrains.annotations.NotNull
 *  org.joml.Quaternionfc
 */
package rtx.kimiko.api.modules.impl.Visuals.customization;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_3882;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionfc;
import rtx.kimiko.api.modules.impl.Visuals.Customization;
import rtx.kimiko.api.modules.impl.Visuals.customization.FlugerHatModel;

@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u0000*\b\b\u0000\u0010\u0002*\u00020\u0001*\u0012\b\u0001\u0010\u0005*\b\u0012\u0004\u0012\u00028\u00000\u0003*\u00020\u00042\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u0006B\u001b\u0012\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u0007\u00a2\u0006\u0004\b\t\u0010\nJ?\u0010\u0016\u001a\u00020\u00152\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00028\u00002\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0012H\u0016\u00a2\u0006\u0004\b\u0016\u0010\u0017\u00a8\u0006\u0018"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/customization/CustomizationLayer;", "Lnet/minecraft/PlayerEntityRenderState;", "S", "Lnet/minecraft/EntityModel;", "Lnet/minecraft/ModelWithHead;", "M", "Lnet/minecraft/FeatureRenderer;", "Lnet/minecraft/FeatureRendererContext;", "renderer", "<init>", "(Lnet/minecraft/FeatureRendererContext;)V", "Lnet/minecraft/MatrixStack;", "poseStack", "Lnet/minecraft/OrderedRenderCommandQueue;", "collector", "", "lightCoords", "state", "", "yRot", "xRot", "", "submit", "(Lnet/minecraft/MatrixStack;Lnet/minecraft/OrderedRenderCommandQueue;ILnet/minecraft/PlayerEntityRenderState;FF)V", "rtx.kimiko:kimiko"})
public final class CustomizationLayer<S extends class_10055, M extends class_583<S>>
extends class_3887<S, M> {
    public CustomizationLayer(@NotNull class_3883<S, M> renderer) {
        super(renderer);
    }

    @Override
    public void render(@NotNull class_4587 poseStack, @NotNull class_11659 collector, int lightCoords, @NotNull S state, float yRot, float xRot) {
        Intrinsics.checkNotNullParameter((Object)poseStack, (String)"poseStack");
        Intrinsics.checkNotNullParameter((Object)collector, (String)"collector");
        Intrinsics.checkNotNullParameter(state, (String)"state");
        Customization customization = Customization.Companion.getInstance();
        if (customization == null || !customization.isEnabled() || ((class_10055)state).field_53333 || ((class_10055)state).field_53457) {
            return;
        }
        class_310 minecraftClient2 = class_310.method_1551();
        Intrinsics.checkNotNullExpressionValue((Object)minecraftClient2, (String)"getInstance(...)");
        class_310 mc = minecraftClient2;
        class_638 clientWorld3 = mc.field_1687;
        if (clientWorld3 == null) {
            return;
        }
        class_638 level = clientWorld3;
        class_1297 entity = level.method_8469(((class_10055)state).field_53528);
        if (!(entity instanceof class_742)) {
            return;
        }
        int flags = customization.flagsFor((class_742)entity);
        if (flags == 0) {
            return;
        }
        boolean crown = (flags & 1) != 0;
        boolean hat = (flags & 2) != 0;
        boolean halo = (flags & 4) != 0;
        boolean wings = (flags & 8) != 0;
        boolean goat = (flags & 0x10) != 0;
        class_583 entityModel2 = this.method_17165();
        Intrinsics.checkNotNullExpressionValue((Object)entityModel2, (String)"getParentModel(...)");
        class_583 parentModel = entityModel2;
        if (crown || hat || halo) {
            poseStack.method_22903();
            parentModel.method_63512().method_22703(poseStack);
            ((class_3882)parentModel).method_74046(poseStack);
            if (hat) {
                FlugerHatModel.render(poseStack, collector, lightCoords);
            }
            if (halo) {
                customization.submitHalo((class_742)entity, poseStack, collector, lightCoords);
            }
            if (crown) {
                poseStack.method_22903();
                poseStack.method_22907((Quaternionfc)class_7833.field_40717.rotationDegrees(180.0f));
                poseStack.method_22907((Quaternionfc)class_7833.field_40715.rotationDegrees(90.0f));
                customization.submitCrown((class_742)entity, poseStack, collector, lightCoords);
                poseStack.method_22909();
            }
            poseStack.method_22909();
        }
        if ((wings || goat) && parentModel instanceof class_572) {
            poseStack.method_22903();
            ((class_572)parentModel).method_63512().method_22703(poseStack);
            ((class_572)parentModel).field_3391.method_22703(poseStack);
            if (wings) {
                customization.submitWings((class_742)entity, poseStack, collector, lightCoords, ((class_10055)state).field_53411, ((class_10055)state).field_53451, ((class_10055)state).field_63604);
            }
            if (goat) {
                customization.submitGoat((class_742)entity, poseStack, collector, lightCoords);
            }
            poseStack.method_22909();
        }
    }
}

