/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity.RemovalReason
 *  net.minecraft.entity.EquipmentSlot
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.item.ItemConvertible
 *  net.minecraft.world.World
 *  net.minecraft.particle.ParticleEffect
 *  net.minecraft.particle.ParticleTypes
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.sound.SoundEvents
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.client.world.ClientWorld
 *  net.minecraft.client.network.OtherClientPlayerEntity
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package rtx.kimiko.api.modules.impl.Visuals;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_5134;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rtx.kimiko.api.events.Event;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.game.TickEvent;
import rtx.kimiko.api.events.impl.player.AttackEntityEvent;
import rtx.kimiko.api.events.impl.player.TotemPopEvent;
import rtx.kimiko.api.lang.I18n;
import rtx.kimiko.api.liteapi.Feature;
import rtx.kimiko.api.modules.Category;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.settings.Setting;
import rtx.kimiko.api.modules.settings.impl.BooleanSetting;
import rtx.kimiko.utils.chat.ChatMessage;

@Feature(value={"fakeplayer"})
@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 *2\u00020\u0001:\u0002+*B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0014\u00a2\u0006\u0004\b\u0005\u0010\u0003J\u000f\u0010\u0006\u001a\u00020\u0004H\u0014\u00a2\u0006\u0004\b\u0006\u0010\u0003J\u001b\u0010\n\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0007H\u0003b\u0002\b\t\u00a2\u0006\u0004\b\n\u0010\u000bJ%\u0010\u000e\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\fH\u0003b\f\b\t\u0012\b\b\r\u0012\u0004\b\u0003\u0010\b\u00a2\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0010\u0010\u0003J\u000f\u0010\u0011\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0011\u0010\u0003J\u000f\u0010\u0012\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0012\u0010\u0003J\u000f\u0010\u0013\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0013\u0010\u0003J\u000f\u0010\u0014\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0014\u0010\u0003J\u000f\u0010\u0015\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0015\u0010\u0003J\u000f\u0010\u0016\u001a\u00020\u0004H\u0002\u00a2\u0006\u0004\b\u0016\u0010\u0003R\u0014\u0010\u0018\u001a\u00020\u00178\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001a\u001a\u00020\u00178\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u001a\u0010\u0019R\u0014\u0010\u001b\u001a\u00020\u00178\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u001b\u0010\u0019R\u0018\u0010\u001d\u001a\u0004\u0018\u00010\u001c8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b\u001d\u0010\u001eR\u0016\u0010 \u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b \u0010!R\u0016\u0010\"\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b\"\u0010!R\u0016\u0010$\u001a\u00020#8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b$\u0010%R\u0016\u0010&\u001a\u00020#8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b&\u0010%R\u0016\u0010(\u001a\u00020'8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b(\u0010)\u00ca\u0001\u0010\b,\u0012\f\b\r\u0012\b\b\fJ\u0004\b\b(-\u00a8\u0006."}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/FakePlayer;", "Lrtx/kimiko/api/modules/Module;", "<init>", "()V", "", "onEnable", "onDisable", "Lrtx/kimiko/api/events/impl/game/TickEvent;", "event", "Lrtx/kimiko/api/events/EventHandler;", "onTick", "(Lrtx/kimiko/api/events/impl/game/TickEvent;)V", "Lrtx/kimiko/api/events/impl/player/AttackEntityEvent;", "value", "onAttackEntity", "(Lrtx/kimiko/api/events/impl/player/AttackEntityEvent;)V", "spawnHitParticles", "spawn", "despawn", "move", "syncTotem", "triggerTotemPop", "popTotem", "Lrtx/kimiko/api/modules/settings/impl/BooleanSetting;", "walk", "Lrtx/kimiko/api/modules/settings/impl/BooleanSetting;", "rotate", "totem", "Lnet/minecraft/OtherClientPlayerEntity;", "fakePlayer", "Lnet/minecraft/OtherClientPlayerEntity;", "Lnet/minecraft/Vec3d;", "spawnPosition", "Lnet/minecraft/Vec3d;", "walkAxis", "", "spawnYaw", "F", "walkPhase", "", "hitsSinceTotem", "I", "Companion", "FakeRemotePlayer", "Lrtx/kimiko/api/liteapi/Feature;", "fakeplayer", "rtx.kimiko:kimiko"})
public final class FakePlayer
extends Module {
    @NotNull
    public static final Companion Companion = new Companion(null);
    @NotNull
    private final BooleanSetting walk = (BooleanSetting)this.register((Setting)new BooleanSetting("Ходьба", "Фейк-игрок ходит из стороны в сторону.", true));
    @NotNull
    private final BooleanSetting rotate = (BooleanSetting)this.register((Setting)new BooleanSetting("Поворот к игроку", "Фейк-игрок смотрит на тебя.", true));
    @NotNull
    private final BooleanSetting totem = (BooleanSetting)this.register((Setting)new BooleanSetting("Тотем", "Фейк-игрок держит тотем и ломает его каждые 3 удара.", false));
    @Nullable
    private class_745 fakePlayer;
    @NotNull
    private class_243 spawnPosition;
    @NotNull
    private class_243 walkAxis;
    private float spawnYaw;
    private float walkPhase;
    private int hitsSinceTotem;
    @NotNull
    private static final String[] NAMES;
    private static final float WALK_RADIUS = 2.0f;
    private static final float WALK_SPEED = 0.1f;
    private static final int ROTATION_LERP_TICKS = 3;

    public FakePlayer() {
        super("Fake Player", "Спавнит клиентского фейк-игрока для битья/теста. Только в одиночной игре.", Category.VISUALS);
        class_243 vec3d2 = class_243.field_1353;
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"ZERO");
        this.spawnPosition = vec3d2;
        class_243 vec3d3 = class_243.field_1353;
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"ZERO");
        this.walkAxis = vec3d3;
    }

    @Override
    protected void onEnable() {
        if (Companion.isLocalWorld()) {
            return;
        }
        ChatMessage.brandmessage(I18n.tr("FakePlayer работает только в одиночном мире."));
        this.mc.execute(() -> FakePlayer.onEnable$lambda$0(this));
    }

    @Override
    protected void onDisable() {
        this.despawn();
    }

    @EventHandler
    private final void onTick(TickEvent event) {
        if (!event.isPre()) {
            return;
        }
        if (!Companion.isLocalWorld()) {
            this.despawn();
            this.disable();
            return;
        }
        class_746 player = this.mc.field_1724;
        class_638 level = this.mc.field_1687;
        if (player == null || level == null) {
            this.fakePlayer = null;
            return;
        }
        class_745 currentFake = this.fakePlayer;
        if (currentFake == null || currentFake.method_31481() || !Intrinsics.areEqual((Object)currentFake.method_73183(), (Object)level)) {
            this.spawn();
        }
        this.syncTotem();
        this.move();
    }

    @EventHandler(value=4)
    private final void onAttackEntity(AttackEntityEvent event) {
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        if (!Intrinsics.areEqual((Object)event.getTarget(), (Object)currentFake)) {
            return;
        }
        event.cancel();
        class_746 player = this.mc.field_1724;
        if (player != null) {
            player.method_7324((class_1297)currentFake);
            this.spawnHitParticles();
            if (this.totem.getValue()) {
                ++this.hitsSinceTotem;
                if (this.hitsSinceTotem >= 3) {
                    this.triggerTotemPop();
                } else {
                    float health = currentFake.method_6063() * (float)(3 - this.hitsSinceTotem) / 3.0f;
                    currentFake.method_6033(Math.max(1.0f, health));
                }
            }
        }
    }

    private final void spawnHitParticles() {
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return;
        }
        class_638 level = clientWorld3;
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        double damage = player.method_45325(class_5134.field_23721);
        int count = Math.max(1, (int)(damage * 0.5));
        for (int i = 0; i < count; ++i) {
            level.method_8406((class_2394)class_2398.field_11209, currentFake.method_23317(), currentFake.method_23323(0.5), currentFake.method_23321(), level.field_9229.method_43059() * 0.1, 0.0, level.field_9229.method_43059() * 0.1);
        }
    }

    private final void spawn() {
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return;
        }
        class_638 level = clientWorld3;
        ThreadLocalRandom random = ThreadLocalRandom.current();
        String name = NAMES[random.nextInt(NAMES.length)] + random.nextInt(10, 100);
        FakeRemotePlayer entity = new FakeRemotePlayer(level, new GameProfile(UUID.randomUUID(), name));
        entity.method_5838(-random.nextInt(1000000, 2000000));
        class_243 vec3d2 = player.method_73189();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"position(...)");
        this.spawnPosition = vec3d2;
        this.spawnYaw = player.method_36454();
        float yawRadians = this.spawnYaw * ((float)Math.PI / 180);
        this.walkAxis = new class_243((double)(-class_3532.method_15362((double)yawRadians)), 0.0, (double)(-class_3532.method_15374((double)yawRadians)));
        this.walkPhase = 0.0f;
        entity.method_5808(this.spawnPosition.field_1352, this.spawnPosition.field_1351, this.spawnPosition.field_1350, this.spawnYaw, 0.0f);
        entity.field_6241 = this.spawnYaw;
        entity.method_5636(this.spawnYaw);
        level.method_53875((class_1297)entity);
        this.fakePlayer = entity;
        this.hitsSinceTotem = 0;
        this.syncTotem();
    }

    private final void despawn() {
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        class_1937 world2 = currentFake.method_73183();
        Intrinsics.checkNotNullExpressionValue((Object)world2, (String)"level(...)");
        class_1937 world = world2;
        if (world instanceof class_638) {
            ((class_638)world).method_2945(currentFake.method_5628(), class_1297.class_5529.field_26999);
        }
        this.fakePlayer = null;
    }

    private final void move() {
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        class_243 targetPosition = this.spawnPosition;
        float yaw = this.spawnYaw;
        float pitch = 0.0f;
        if (this.walk.getValue()) {
            this.walkPhase += 0.1f;
            class_243 vec3d2 = this.spawnPosition.method_1019(this.walkAxis.method_1021((double)(class_3532.method_15374((double)this.walkPhase) * 2.0f)));
            Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"add(...)");
            targetPosition = vec3d2;
            double sign = (double)class_3532.method_15362((double)this.walkPhase) >= 0.0 ? 1.0 : -1.0;
            class_243 vec3d3 = this.walkAxis.method_1021(sign);
            Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"scale(...)");
            class_243 direction = vec3d3;
            yaw = (float)Math.toDegrees(class_3532.method_15349((double)(-direction.field_1352), (double)direction.field_1350));
        }
        if (this.rotate.getValue()) {
            double deltaX = player.method_23317() - currentFake.method_23317();
            double deltaY = player.method_23320() - currentFake.method_23320();
            double deltaZ = player.method_23321() - currentFake.method_23321();
            yaw = (float)Math.toDegrees(class_3532.method_15349((double)deltaZ, (double)deltaX)) - 90.0f;
            pitch = (float)(-Math.toDegrees(class_3532.method_15349((double)deltaY, (double)Math.hypot(deltaX, deltaZ))));
        }
        currentFake.method_66233().method_66267(targetPosition, yaw, pitch);
        currentFake.method_5683(yaw, 3);
    }

    private final void syncTotem() {
        class_1799 itemStack2;
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        if (this.totem.getValue()) {
            itemStack2 = new class_1799((class_1935)class_1802.field_8288);
        } else {
            class_1799 itemStack3 = class_1799.field_8037;
            itemStack2 = itemStack3;
            Intrinsics.checkNotNullExpressionValue((Object)itemStack3, (String)"EMPTY");
        }
        currentFake.method_5673(class_1304.field_6171, itemStack2);
        if (!this.totem.getValue()) {
            this.hitsSinceTotem = 0;
            currentFake.method_6033(currentFake.method_6063());
        }
    }

    private final void triggerTotemPop() {
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        this.hitsSinceTotem = 0;
        currentFake.method_6033(1.0f);
        this.popTotem();
        currentFake.method_6033(currentFake.method_6063());
    }

    private final void popTotem() {
        class_745 otherClientPlayerEntity2 = this.fakePlayer;
        if (otherClientPlayerEntity2 == null) {
            return;
        }
        class_745 currentFake = otherClientPlayerEntity2;
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return;
        }
        class_638 level = clientWorld3;
        class_1799 stack = new class_1799((class_1935)class_1802.field_8288);
        currentFake.method_5673(class_1304.field_6171, stack);
        this.mc.field_1713.method_3051((class_1297)currentFake, (class_2394)class_2398.field_11220, 30);
        level.method_8486(currentFake.method_23317(), currentFake.method_23318(), currentFake.method_23321(), class_3417.field_14931, currentFake.method_5634(), 1.0f, 1.0f, false);
        EventBus.Companion.get().post((Event)new TotemPopEvent((class_1309)currentFake, false));
    }

    private static final void onEnable$lambda$0(FakePlayer this$0) {
        this$0.disable();
    }

    @JvmStatic
    public static final boolean isLocalWorld() {
        return Companion.isLocalWorld();
    }

    @JvmStatic
    public static final boolean isFakePlayer(@NotNull class_1297 entity) {
        return Companion.isFakePlayer(entity);
    }

    static {
        String[] stringArray = new String[]{"Steve", "Alex", "Herobrine", "Nagibator", "Vitalik", "Sanya", "Dimon", "Leha", "KolyaPRO", "Artem", "Nikita", "Timoha", "Zhenya", "MaksFX", "Vladik"};
        NAMES = stringArray;
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0006\u001a\u00020\u0004H\u0007b\u0002\b\u0005\u00a2\u0006\u0004\b\u0006\u0010\u0007J\u001b\u0010\n\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\bH\u0007b\u0002\b\u0005\u00a2\u0006\u0004\b\n\u0010\u000bR\u001a\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\f8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0011\u001a\u00020\u00108\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0013\u001a\u00020\u00108\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0013\u0010\u0012R\u0014\u0010\u0015\u001a\u00020\u00148\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0015\u0010\u0016\u00a8\u0006\u0017"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/FakePlayer.Companion;", "", "<init>", "()V", "", "Lkotlin/jvm/JvmStatic;", "isLocalWorld", "()Z", "Lnet/minecraft/Entity;", "entity", "isFakePlayer", "(Lnet/minecraft/Entity;)Z", "", "", "NAMES", "[Ljava/lang/String;", "", "WALK_RADIUS", "F", "WALK_SPEED", "", "ROTATION_LERP_TICKS", "I", "rtx.kimiko:kimiko"})
    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final boolean isLocalWorld() {
            class_310 minecraftClient2 = class_310.method_1551();
            Intrinsics.checkNotNullExpressionValue((Object)minecraftClient2, (String)"getInstance(...)");
            class_310 minecraft = minecraftClient2;
            return minecraft.field_1687 != null && minecraft.method_1496();
        }

        @JvmStatic
        public final boolean isFakePlayer(@NotNull class_1297 entity) {
            Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
            return entity instanceof FakeRemotePlayer;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0016\u00a2\u0006\u0004\b\u000b\u0010\f\u00a8\u0006\r"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/FakePlayer$FakeRemotePlayer;", "Lnet/minecraft/OtherClientPlayerEntity;", "Lnet/minecraft/ClientWorld;", "level", "Lcom/mojang/authlib/GameProfile;", "profile", "<init>", "(Lnet/minecraft/ClientWorld;Lcom/mojang/authlib/GameProfile;)V", "Lnet/minecraft/DamageSource;", "source", "", "hurtClient", "(Lnet/minecraft/DamageSource;)Z", "rtx.kimiko:kimiko"})
    private static final class FakeRemotePlayer
    extends class_745 {
        public FakeRemotePlayer(@NotNull class_638 level, @NotNull GameProfile profile) {
            super(level, profile);
        }

        public boolean method_5643(@NotNull class_1282 source) {
            Intrinsics.checkNotNullParameter((Object)source, (String)"source");
            this.method_48922(source);
            return true;
        }
    }
}

