package rtx.kimiko.api.modules.impl.Visuals.customization;

import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_742;

public class FeatheredWingsRenderer {
    public static void render(class_742 player, class_4587 stack, class_11659 collector, int packedLight, boolean flying, float walkSpeed, float attackTime) {
    }

    public static void reset() {
    }

    public static void preload() {
    }
}
