/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.util.Window
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.screen.slot.Slot
 *  net.minecraft.item.Item
 *  net.minecraft.util.collection.DefaultedList
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.client.util.InputUtil.Key
 *  net.minecraft.client.util.InputUtil.Type
 *  net.minecraft.client.network.ClientPlayerInteractionManager
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.jetbrains.annotations.NotNull
 *  org.lwjgl.glfw.GLFW
 */
package rtx.kimiko.api.modules.impl.Utils;

import java.util.Collection;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_1041;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_2371;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.inventory.ClickSlotEvent;
import rtx.kimiko.api.events.impl.inventory.HandledScreenEvent;
import rtx.kimiko.api.liteapi.Feature;
import rtx.kimiko.api.modules.Category;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.settings.Setting;
import rtx.kimiko.api.modules.settings.impl.SliderSetting;
import rtx.kimiko.utils.time.StopWatch;

@Feature(value={"itemscroller"})
@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u001b\u0010\b\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007b\u0002\b\u0007\u00a2\u0006\u0004\b\b\u0010\tJ\u001b\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\nH\u0007b\u0002\b\u0007\u00a2\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\rH\u0002\u00a2\u0006\u0004\b\u0010\u0010\u0011J\u0019\u0010\u0015\u001a\u00020\u00142\b\u0010\u0013\u001a\u0004\u0018\u00010\u0012H\u0002\u00a2\u0006\u0004\b\u0015\u0010\u0016R\u0014\u0010\u0018\u001a\u00020\u00178\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001b\u001a\u00020\u001a8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u001b\u0010\u001c\u00ca\u0001\u0010\b\u001d\u0012\f\b\u001e\u0012\b\b\fJ\u0004\b\b(\u001f\u00a8\u0006 "}, d2={"Lrtx/kimiko/api/modules/impl/Utils/ItemScroller;", "Lrtx/kimiko/api/modules/Module;", "<init>", "()V", "Lrtx/kimiko/api/events/impl/inventory/HandledScreenEvent;", "event", "", "Lrtx/kimiko/api/events/EventHandler;", "onHandledScreen", "(Lrtx/kimiko/api/events/impl/inventory/HandledScreenEvent;)V", "Lrtx/kimiko/api/events/impl/inventory/ClickSlotEvent;", "onClickSlot", "(Lrtx/kimiko/api/events/impl/inventory/ClickSlotEvent;)V", "Lnet/minecraft/KeyBinding;", "key", "", "isKeyDown", "(Lnet/minecraft/KeyBinding;)Z", "Lnet/minecraft/Slot;", "slot", "", "menuSlotId", "(Lnet/minecraft/Slot;)I", "Lrtx/kimiko/utils/time/StopWatch;", "stopWatch", "Lrtx/kimiko/utils/time/StopWatch;", "Lrtx/kimiko/api/modules/settings/impl/SliderSetting;", "scrollDelay", "Lrtx/kimiko/api/modules/settings/impl/SliderSetting;", "Lrtx/kimiko/api/liteapi/Feature;", "value", "itemscroller", "rtx.kimiko:kimiko"})
public final class ItemScroller
extends Module {
    @NotNull
    private final StopWatch stopWatch = new StopWatch();
    @NotNull
    private final SliderSetting scrollDelay = (SliderSetting)this.register((Setting)new SliderSetting("Задержка прокрутки", "Задержка между кликами прокрутки предметов.").range(0, 200).increment(1).setValue(50.0f));

    public ItemScroller() {
        super("Item Scroller", "Прокручивает подходящие предметы в инвентаре с клавишами-модификаторами.", Category.UTILS);
    }

    @EventHandler
    public final void onHandledScreen(@NotNull HandledScreenEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, "event");
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_636 clientPlayerInteractionManager2 = this.mc.field_1761;
        if (clientPlayerInteractionManager2 == null) {
            return;
        }
        class_636 gameMode = clientPlayerInteractionManager2;
        class_1735 hoverSlot = event.getSlotHover();
        class_304 keyBinding2 = this.mc.field_1690.field_1869;
        Intrinsics.checkNotNullExpressionValue((Object)keyBinding2, "keyDrop");
        class_1713 actionType;
        if (this.isKeyDown(keyBinding2)) {
            actionType = class_1713.field_7795;
        } else {
            class_304 keyBinding3 = this.mc.field_1690.field_1886;
            Intrinsics.checkNotNullExpressionValue((Object)keyBinding3, "keyAttack");
            actionType = this.isKeyDown(keyBinding3) ? class_1713.field_7794 : null;
        }
        class_304 keyBinding4 = this.mc.field_1690.field_1832;
        Intrinsics.checkNotNullExpressionValue((Object)keyBinding4, (String)"keyShift");
        if (this.isKeyDown(keyBinding4)) {
            int slotId;
            class_304 keyBinding5 = this.mc.field_1690.field_1867;
            Intrinsics.checkNotNullExpressionValue((Object)keyBinding5, (String)"keySprint");
            if (!this.isKeyDown(keyBinding5) && hoverSlot != null && hoverSlot.method_7681() && actionType != null && this.stopWatch.every(this.scrollDelay.getValue()) && (slotId = this.menuSlotId(hoverSlot)) != -1) {
                gameMode.method_2906(player.field_7512.field_7763, slotId, actionType == class_1713.field_7795 ? 1 : 0, actionType, (class_1657)player);
            }
        }
    }

    @EventHandler
    public final void onClickSlot(@NotNull ClickSlotEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_636 clientPlayerInteractionManager2 = this.mc.field_1761;
        if (clientPlayerInteractionManager2 == null) {
            return;
        }
        class_636 gameMode = clientPlayerInteractionManager2;
        int slotId = event.getSlotId();
        if (slotId < 0 || slotId >= player.field_7512.field_7761.size()) {
            return;
        }
        class_1735 slot2 = player.field_7512.method_7611(slotId);
        Intrinsics.checkNotNullExpressionValue((Object)slot2, (String)"getSlot(...)");
        class_1735 slot = slot2;
        if (!slot.method_7681()) {
            return;
        }
        class_1792 item2 = slot.method_7677().method_7909();
        Intrinsics.checkNotNullExpressionValue((Object)item2, (String)"getItem(...)");
        class_1792 item = item2;
        class_304 keyBinding2 = this.mc.field_1690.field_1832;
        Intrinsics.checkNotNullExpressionValue((Object)keyBinding2, (String)"keyShift");
        if (this.isKeyDown(keyBinding2)) {
            class_304 keyBinding3 = this.mc.field_1690.field_1867;
            Intrinsics.checkNotNullExpressionValue((Object)keyBinding3, "keySprint");
            if (this.isKeyDown(keyBinding3) && this.stopWatch.every(50.0)) {
                for (class_1735 s : player.field_7512.field_7761) {
                    if (s.method_7681() && s.method_7677().method_7909() == item && s.field_7871 == slot.field_7871) {
                        int scrolledSlotId = this.menuSlotId(s);
                        if (scrolledSlotId != -1) {
                            gameMode.method_2906(player.field_7512.field_7763, scrolledSlotId, 1, event.getActionType(), (class_1657)player);
                        }
                    }
                }
            }
        }
    }

    private final boolean isKeyDown(class_304 key) {
        class_1041 window2 = this.mc.method_22683();
        if (window2 == null) {
            return false;
        }
        class_1041 window = window2;
        class_3675.class_306 key2 = key.method_1429();
        Intrinsics.checkNotNullExpressionValue((Object)key2, (String)"getDefaultKey(...)");
        class_3675.class_306 bound = key2;
        int code = bound.method_1444();
        if (code == -1) {
            return false;
        }
        return switch (WhenMappings.$EnumSwitchMapping$0[bound.method_1442().ordinal()]) {
            case 1 -> {
                if (GLFW.glfwGetKey((long)window.method_4490(), (int)code) == 1) {
                    yield true;
                }
                yield false;
            }
            case 2 -> {
                if (GLFW.glfwGetMouseButton((long)window.method_4490(), (int)code) == 1) {
                    yield true;
                }
                yield false;
            }
            default -> false;
        };
    }

    private final int menuSlotId(class_1735 slot) {
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return -1;
        }
        class_746 player = clientPlayerEntity2;
        if (slot == null || player.field_7512 == null) {
            return -1;
        }
        class_2371 defaultedList2 = player.field_7512.field_7761;
        Intrinsics.checkNotNullExpressionValue((Object)defaultedList2, (String)"slots");
        class_2371 slots = defaultedList2;
        int n = ((Collection)slots).size();
        for (int i = 0; i < n; ++i) {
            if (!Intrinsics.areEqual((Object)slots.get(i), (Object)slot)) continue;
            return i;
        }
        return slot.field_7874;
    }

    private static final boolean onClickSlot$lambda$0(class_1792 $item, class_1735 $slot, class_1735 scrolledSlot) {
        return scrolledSlot.method_7681() && Intrinsics.areEqual((Object)scrolledSlot.method_7677().method_7909(), (Object)$item) && Intrinsics.areEqual((Object)scrolledSlot.field_7871, (Object)$slot.field_7871);
    }

    private static final boolean onClickSlot$lambda$1(Function1 $tmp0, Object p0) {
        return (Boolean)$tmp0.invoke(p0);
    }

    private static final Unit onClickSlot$lambda$2(ItemScroller this$0, class_636 $gameMode, class_746 $player, ClickSlotEvent $event, class_1735 scrolledSlot) {
        int scrolledSlotId = this$0.menuSlotId(scrolledSlot);
        if (scrolledSlotId != -1) {
            $gameMode.method_2906($player.field_7512.field_7763, scrolledSlotId, 1, $event.getActionType(), (class_1657)$player);
        }
        return Unit.INSTANCE;
    }

    private static final void onClickSlot$lambda$3(Function1 $tmp0, Object p0) {
        $tmp0.invoke(p0);
    }

    @Metadata(mv={2, 4, 0}, k=3, xi=48)
    public static final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[class_3675.class_307.values().length];
            try {
                nArray[class_3675.class_307.field_1668.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            try {
                nArray[class_3675.class_307.field_1672.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

