/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity.RemovalReason
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.world.BlockView
 *  net.minecraft.world.World
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.BlockPos.Mutable
 *  net.minecraft.util.math.Direction.Axis
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.shape.VoxelShape
 *  net.minecraft.block.BlockState
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.random.Random
 *  net.minecraft.client.world.ClientWorld
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package rtx.kimiko.api.modules.impl.Visuals.custompet.control;

import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rtx.kimiko.api.modules.impl.Visuals.custompet.CustomPetVariant;
import rtx.kimiko.api.modules.impl.Visuals.custompet.entity.CustomPetEntity;

@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000l\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0006\n\u0002\b+\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 {2\u00020\u0001:\u0001{B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0004\b\u0005\u0010\u0006JI\u0010\u0012\u001a\u00020\u00112\b\u0010\b\u001a\u0004\u0018\u00010\u00072\b\u0010\n\u001a\u0004\u0018\u00010\t2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u000b\u00a2\u0006\u0004\b\u0012\u0010\u0013J\r\u0010\u0014\u001a\u00020\u0011\u00a2\u0006\u0004\b\u0014\u0010\u0003JI\u0010\u0015\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00072\b\u0010\n\u001a\u0004\u0018\u00010\t2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u000bH\u0002\u00a2\u0006\u0004\b\u0015\u0010\u0013J\u0019\u0010\u0017\u001a\u0004\u0018\u00010\u00162\u0006\u0010\b\u001a\u00020\u0007H\u0002\u00a2\u0006\u0004\b\u0017\u0010\u0018J!\u0010\u0019\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00072\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0002\u00a2\u0006\u0004\b\u0019\u0010\u001aJ7\u0010 \u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b \u0010!J7\u0010\"\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b\"\u0010!J'\u0010%\u001a\u00020\u001d2\u0006\u0010#\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020\u001d2\u0006\u0010\b\u001a\u00020\u0007H\u0002\u00a2\u0006\u0004\b%\u0010&J\u0017\u0010'\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u0007H\u0002\u00a2\u0006\u0004\b'\u0010\u0018J/\u0010*\u001a\u00020\u001d2\u0006\u0010#\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b*\u0010+J\u001f\u0010,\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b,\u0010-J\u001f\u0010/\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010.\u001a\u00020\u0016H\u0002\u00a2\u0006\u0004\b/\u00100J\u0017\u00101\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u0007H\u0002\u00a2\u0006\u0004\b1\u0010\u0018J'\u00102\u001a\u00020\u001d2\u0006\u0010#\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b2\u00103J\u001f\u00104\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u0016H\u0002\u00a2\u0006\u0004\b4\u00105J\u0017\u00107\u001a\u00020\u000b2\u0006\u00106\u001a\u00020\u0016H\u0002\u00a2\u0006\u0004\b7\u00108J\u001f\u0010:\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u000bH\u0002\u00a2\u0006\u0004\b:\u0010;J'\u0010:\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010<\u001a\u00020\u001d2\u0006\u0010=\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b:\u0010>J'\u0010?\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\b?\u0010>J\u001f\u0010A\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010@\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\bA\u0010-J\u001f\u0010C\u001a\u00020\u00162\u0006\u0010B\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u0007H\u0002\u00a2\u0006\u0004\bC\u0010DJ'\u0010E\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\bE\u0010>J\u0017\u0010F\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u0007H\u0002\u00a2\u0006\u0004\bF\u0010\u0018J\u001f\u0010G\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u0016H\u0002\u00a2\u0006\u0004\bG\u0010HJ\u001f\u0010L\u001a\u00020I2\u0006\u0010J\u001a\u00020I2\u0006\u0010K\u001a\u00020IH\u0002\u00a2\u0006\u0004\bL\u0010MJ\u001f\u0010O\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u00162\u0006\u0010N\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\bO\u0010PJ'\u0010Q\u001a\u00020\u001d2\u0006\u0010#\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020\u001d2\u0006\u0010N\u001a\u00020\u001dH\u0002\u00a2\u0006\u0004\bQ\u00103R\u0014\u0010S\u001a\u00020R8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bS\u0010TR\u0014\u0010V\u001a\u00020U8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\bV\u0010WR\u0018\u0010X\u001a\u0004\u0018\u00010\u00048\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bX\u0010YR\u0016\u0010Z\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bZ\u0010[R\u0016\u0010\\\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b\\\u0010[R\u0016\u0010]\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b]\u0010^R\u0016\u0010_\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b_\u0010^R\u0016\u0010`\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\b`\u0010^R\u0016\u0010a\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\ba\u0010^R\u0016\u0010b\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bb\u0010[R\u0018\u0010c\u001a\u0004\u0018\u00010\u00168\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bc\u0010dR\u0018\u0010e\u001a\u0004\u0018\u00010\u00168\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\be\u0010dR\u0018\u0010f\u001a\u0004\u0018\u00010\u00168\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bf\u0010dR\u0018\u0010g\u001a\u0004\u0018\u00010\u00168\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bg\u0010dR\u0018\u0010h\u001a\u0004\u0018\u00010\u00168\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bh\u0010dR\u0016\u0010i\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bi\u0010[R\u0016\u0010j\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bj\u0010^R\u0016\u0010k\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bk\u0010^R\u0016\u0010l\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bl\u0010^R\u0016\u0010m\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bm\u0010^R\u0016\u0010n\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bn\u0010^R\u0016\u0010o\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bo\u0010^R\u0016\u0010p\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bp\u0010^R\u0016\u0010q\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bq\u0010^R\u0016\u0010r\u001a\u00020I8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\br\u0010^R\u0018\u0010s\u001a\u0004\u0018\u00010\u00168\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bs\u0010dR\u0016\u0010u\u001a\u00020t8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\bu\u0010vR\u001e\u0010y\u001a\n\u0012\u0004\u0012\u00020x\u0018\u00010w8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\by\u0010z\u00a8\u0006|"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/custompet/control/CustomPetFollowerController;", "", "<init>", "()V", "Lrtx/kimiko/api/modules/impl/Visuals/custompet/entity/CustomPetEntity;", "getPet", "()Lrtx/kimiko/api/modules/impl/Visuals/custompet/entity/CustomPetEntity;", "Lnet/minecraft/PlayerEntity;", "player", "Lrtx/kimiko/api/modules/impl/Visuals/custompet/CustomPetVariant;", "variant", "", "owl", "chekushka", "goat", "nightmareBb", "ufo", "", "tick", "(Lnet/minecraft/PlayerEntity;Lrtx/kimiko/api/modules/impl/Visuals/custompet/CustomPetVariant;ZZZZZ)V", "reset", "ensurePet", "Lnet/minecraft/Vec3d;", "consumeSavedSpawn", "(Lnet/minecraft/PlayerEntity;)Lnet/minecraft/Vec3d;", "tickPet", "(Lnet/minecraft/PlayerEntity;Lrtx/kimiko/api/modules/impl/Visuals/custompet/CustomPetVariant;)V", "current", "playerPos", "", "playerDistance", "playerHorizontalSpeed", "tickRobotFlight", "(Lnet/minecraft/PlayerEntity;Lnet/minecraft/Vec3d;Lnet/minecraft/Vec3d;DD)V", "tickUfoFlight", "x", "z", "ufoHoverY", "(DDLnet/minecraft/PlayerEntity;)D", "pickUfoRoamTarget", "groundY", "preferredY", "ufoCeilingLimit", "(DDDD)D", "pickUfoAnchor", "(Lnet/minecraft/PlayerEntity;D)Lnet/minecraft/Vec3d;", "robotPos", "tickGazeReaction", "(Lnet/minecraft/PlayerEntity;Lnet/minecraft/Vec3d;)V", "pickRobotRoamTarget", "ceilingClearance", "(DDD)D", "shouldPickNewTarget", "(Lnet/minecraft/PlayerEntity;Lnet/minecraft/Vec3d;)Z", "pos", "isRainingAbove", "(Lnet/minecraft/Vec3d;)Z", "closeRange", "pickRoamTarget", "(Lnet/minecraft/PlayerEntity;Z)Lnet/minecraft/Vec3d;", "minRadius", "maxRadius", "(Lnet/minecraft/PlayerEntity;DD)Lnet/minecraft/Vec3d;", "computeFollowTarget", "smoothing", "resolveHeading", "point", "enforcePersonalSpace", "(Lnet/minecraft/Vec3d;Lnet/minecraft/PlayerEntity;)Lnet/minecraft/Vec3d;", "computeAirFollowTarget", "computeAirIdleTarget", "pickAirHoverOffset", "(Lnet/minecraft/PlayerEntity;Lnet/minecraft/Vec3d;)Lnet/minecraft/Vec3d;", "", "min", "max", "randomBetween", "(II)I", "fallbackY", "snapCurrentToGround", "(Lnet/minecraft/Vec3d;D)Lnet/minecraft/Vec3d;", "findGroundY", "Lnet/minecraft/MinecraftClient;", "mc", "Lnet/minecraft/MinecraftClient;", "Lnet/minecraft/Random;", "random", "Lnet/minecraft/Random;", "pet", "Lrtx/kimiko/api/modules/impl/Visuals/custompet/entity/CustomPetEntity;", "petIsOwl", "Z", "petIsUfo", "ufoIdleTicks", "I", "ufoRoamPauseTicks", "ufoGroundedTicks", "ufoRestDuration", "ufoChasing", "roamTarget", "Lnet/minecraft/Vec3d;", "playerHeading", "airHoverOffset", "airSmoothedTarget", "airFlightDirection", "airChasing", "idleTicks", "followRefreshTicks", "followSide", "ticks", "flightTicksRemaining", "nextFlightAtTick", "gazeBuildTicks", "gazeLookActiveTicks", "gazeCooldownTicks", "savedPosition", "", "savedYaw", "F", "Ljava/lang/ref/WeakReference;", "Lnet/minecraft/World;", "savedLevel", "Ljava/lang/ref/WeakReference;", "Companion", "rtx.kimiko:kimiko"})
public final class CustomPetFollowerController {
    @NotNull
    public static final Companion Companion = new Companion(null);
    @NotNull
    private final class_310 mc;
    @NotNull
    private final class_5819 random;
    @Nullable
    private CustomPetEntity pet;
    private boolean petIsOwl;
    private boolean petIsUfo;
    private int ufoIdleTicks;
    private int ufoRoamPauseTicks;
    private int ufoGroundedTicks;
    private int ufoRestDuration;
    private boolean ufoChasing;
    @Nullable
    private class_243 roamTarget;
    @Nullable
    private class_243 playerHeading;
    @Nullable
    private class_243 airHoverOffset;
    @Nullable
    private class_243 airSmoothedTarget;
    @Nullable
    private class_243 airFlightDirection;
    private boolean airChasing;
    private int idleTicks;
    private int followRefreshTicks;
    private int followSide;
    private int ticks;
    private int flightTicksRemaining;
    private int nextFlightAtTick;
    private int gazeBuildTicks;
    private int gazeLookActiveTicks;
    private int gazeCooldownTicks;
    @Nullable
    private class_243 savedPosition;
    private float savedYaw;
    @Nullable
    private WeakReference<class_1937> savedLevel;
    private static final double MAX_WANDER_DISTANCE = 15.0;
    private static final double SNAP_BACK_DISTANCE = 18.0;
    private static final double FOLLOW_BREAK_DISTANCE = 13.0;
    private static final double FOLLOW_NEAR_DISTANCE = 6.0;
    private static final double TARGET_REACHED_DISTANCE = 0.45;
    private static final double STROLL_RADIUS_MIN = 2.0;
    private static final double STROLL_RADIUS_MAX = 6.0;
    private static final double PLAYER_PERSONAL_SPACE = 0.65;
    private static final double HEADING_MOTION_THRESHOLD_SQR = 9.0E-4;
    private static final double OWL_HOVER_RADIUS_MIN = 1.6;
    private static final double OWL_HOVER_RADIUS_MAX = 2.8;
    private static final double OWL_HOVER_HEIGHT_MIN = 1.6;
    private static final double OWL_HOVER_HEIGHT_MAX = 3.2;
    private static final int OWL_FLIGHT_COOLDOWN_MIN = 300;
    private static final int OWL_FLIGHT_COOLDOWN_MAX = 640;
    private static final int OWL_FLIGHT_DURATION_MIN = 90;
    private static final int OWL_FLIGHT_DURATION_MAX = 190;
    private static final double UFO_HOVER_HEIGHT = 1.95;
    private static final double UFO_PLAYER_LIFT = 1.65;
    private static final double UFO_FOLLOW_START = 8.0;
    private static final double UFO_FOLLOW_STOP = 3.0;
    private static final double UFO_ROAM_MIN = 2.2;
    private static final double UFO_ROAM_MAX = 7.5;
    private static final int UFO_LAND_DELAY = 460;
    private static final int UFO_REST_MIN = 200;
    private static final int UFO_REST_MAX = 400;
    private static final int UFO_TAKEOFF_LIFT_TICKS = 18;
    private static final double UFO_TRICK_CHANCE = 0.0022;

    public CustomPetFollowerController() {
        class_310 minecraftClient2 = class_310.method_1551();
        Intrinsics.checkNotNullExpressionValue((Object)minecraftClient2, (String)"getInstance(...)");
        this.mc = minecraftClient2;
        class_5819 random2 = class_5819.method_43047();
        Intrinsics.checkNotNullExpressionValue((Object)random2, (String)"create(...)");
        this.random = random2;
        this.ufoRestDuration = 200;
        this.followSide = 1;
    }

    @Nullable
    public final CustomPetEntity getPet() {
        return this.pet;
    }

    public final void tick(@Nullable class_1657 player, @Nullable CustomPetVariant variant, boolean owl, boolean chekushka, boolean goat, boolean nightmareBb, boolean ufo) {
        if (player == null || player.method_73183() == null || this.mc.field_1687 == null) {
            this.reset();
            return;
        }
        this.ensurePet(player, variant, owl, chekushka, goat, nightmareBb, ufo);
        this.tickPet(player, variant);
    }

    public final void reset() {
        CustomPetEntity currentPet = this.pet;
        if (currentPet != null && !currentPet.method_31481()) {
            this.savedPosition = currentPet.method_73189();
            this.savedYaw = currentPet.method_36454();
            this.savedLevel = new WeakReference<class_1937>(currentPet.method_73183());
            class_638 level = this.mc.field_1687;
            if (level != null) {
                level.method_2945(currentPet.method_5628(), class_1297.class_5529.field_26999);
            }
            currentPet.method_31472();
        }
        this.pet = null;
        this.roamTarget = null;
        this.playerHeading = null;
        this.airHoverOffset = null;
        this.airSmoothedTarget = null;
        this.airFlightDirection = null;
        this.airChasing = false;
        this.idleTicks = 0;
        this.followRefreshTicks = 0;
        this.followSide = 1;
        this.flightTicksRemaining = 0;
        this.ufoIdleTicks = 0;
        this.ufoRoamPauseTicks = 0;
        this.ufoGroundedTicks = 0;
        this.ufoRestDuration = this.randomBetween(200, 400);
        this.ufoChasing = false;
    }

    private final void ensurePet(class_1657 player, CustomPetVariant variant, boolean owl, boolean chekushka, boolean goat, boolean nightmareBb, boolean ufo) {
        CustomPetEntity newPet;
        CustomPetEntity currentPet = this.pet;
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return;
        }
        class_638 level = clientWorld3;
        CustomPetVariant activeVariant = variant != null ? variant : CustomPetVariant.NITWIT;
        if (currentPet != null && Intrinsics.areEqual((Object)currentPet.method_73183(), (Object)level) && !currentPet.method_31481() && currentPet.isChekushka() == chekushka && currentPet.isGoat() == goat && currentPet.isNightmareBb() == nightmareBb && currentPet.isUfo() == ufo) {
            currentPet.setPetVariant(activeVariant);
            currentPet.setOwl(owl);
            this.petIsOwl = owl;
            this.petIsUfo = ufo;
            return;
        }
        this.reset();
        this.petIsOwl = owl;
        this.petIsUfo = ufo;
        this.ufoIdleTicks = 0;
        this.pet = newPet = new CustomPetEntity((class_1937)level);
        newPet.setPetVariant(activeVariant);
        newPet.setOwl(owl);
        newPet.setChekushka(chekushka);
        newPet.setGoat(goat);
        newPet.setNightmareBb(nightmareBb);
        newPet.setUfo(ufo);
        this.nextFlightAtTick = this.ticks + this.randomBetween(300, 640);
        this.airHoverOffset = null;
        this.airSmoothedTarget = null;
        this.airFlightDirection = null;
        this.airChasing = false;
        this.idleTicks = this.randomBetween(18, 34);
        this.followRefreshTicks = 0;
        this.followSide = this.random.method_43056() ? 1 : -1;
        class_243 restored = this.consumeSavedSpawn(player);
        if (restored != null) {
            this.roamTarget = null;
            newPet.snapTo(restored, this.savedYaw);
        } else {
            class_243 target;
            this.roamTarget = target = this.pickRoamTarget(player, true);
            newPet.snapTo(target, this.random.method_43057() * 360.0f);
        }
        level.method_53875((class_1297)newPet);
    }

    private final class_243 consumeSavedSpawn(class_1657 player) {
        class_243 saved = this.savedPosition;
        WeakReference<class_1937> weakReference = this.savedLevel;
        class_1937 level = weakReference != null ? (class_1937)weakReference.get() : null;
        this.savedPosition = null;
        this.savedLevel = null;
        if (saved == null || level == null || !Intrinsics.areEqual((Object)level, (Object)this.mc.field_1687)) {
            return null;
        }
        if (saved.method_1025(player.method_73189()) > 324.0) {
            return null;
        }
        return saved;
    }

    private final void tickPet(class_1657 player, CustomPetVariant variant) {
        class_1293 speedEffect;
        boolean robotMode;
        CustomPetEntity customPetEntity = this.pet;
        if (customPetEntity == null) {
            return;
        }
        CustomPetEntity activePet = customPetEntity;
        CustomPetVariant customPetVariant = variant;
        if (customPetVariant == null) {
            customPetVariant = CustomPetVariant.NITWIT;
        }
        activePet.setPetVariant(customPetVariant);
        class_243 vec3d2 = activePet.method_73189();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"position(...)");
        class_243 current = vec3d2;
        class_243 groundedCurrent = this.snapCurrentToGround(current, player.method_23318());
        class_243 vec3d3 = player.method_73189();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"position(...)");
        class_243 playerPos = vec3d3;
        double playerDistanceSqr = current.method_1025(playerPos);
        double playerDistance = Math.sqrt(playerDistanceSqr);
        double playerHorizontalSpeed = player.method_18798().method_37267();
        if (this.petIsUfo) {
            this.tickUfoFlight(player, current, playerPos, playerDistance, playerHorizontalSpeed);
            return;
        }
        boolean bl = robotMode = variant != null && variant.isRobot();
        if (robotMode) {
            this.tickRobotFlight(player, current, playerPos, playerDistance, playerHorizontalSpeed);
            return;
        }
        int n = this.ticks;
        this.ticks = n + 1;
        boolean playerIdle = playerHorizontalSpeed < 0.02;
        boolean airbornePlayer = player.method_6128() || player.method_31549().field_7479;
        boolean owlFlight = false;
        if (this.petIsOwl) {
            if (this.flightTicksRemaining > 0) {
                int n2 = this.flightTicksRemaining;
                this.flightTicksRemaining = n2 + -1;
                owlFlight = true;
                if (this.flightTicksRemaining == 0) {
                    this.nextFlightAtTick = this.ticks + this.randomBetween(300, 640);
                }
            } else if (!airbornePlayer && this.ticks >= this.nextFlightAtTick && playerHorizontalSpeed < 0.12 && playerDistance < 8.0) {
                this.flightTicksRemaining = this.randomBetween(90, 190);
                this.nextFlightAtTick = this.ticks + this.flightTicksRemaining + this.randomBetween(300, 640);
                owlFlight = true;
            }
        }
        boolean airborne = airbornePlayer || owlFlight;
        boolean playerMoving = playerHorizontalSpeed > 0.025 || Math.abs(player.method_18798().field_1351) > 0.05;
        boolean playerMovingFast = playerHorizontalSpeed > 0.17 || Math.abs(player.method_18798().field_1351) > 0.08;
        boolean shouldFollowPlayer = playerDistanceSqr > 169.0 || playerMoving && playerDistanceSqr > 36.0;
        boolean rainy = this.isRainingAbove(current);
        if (playerDistanceSqr > 324.0) {
            class_243 target;
            this.roamTarget = target = this.pickRoamTarget(player, true);
            this.airFlightDirection = null;
            this.airChasing = false;
            this.flightTicksRemaining = 0;
            this.idleTicks = this.randomBetween(12, 22);
            this.followRefreshTicks = 0;
            activePet.snapTo(target, activePet.method_36454());
            activePet.setBehavior(target, 0.0, false, rainy, false, 1.0);
            return;
        }
        if (activePet.isMovementBlocked() && playerDistanceSqr <= 169.0) {
            this.roamTarget = null;
            this.airFlightDirection = null;
            this.airChasing = false;
            this.followRefreshTicks = 0;
            if (this.idleTicks <= 0) {
                this.idleTicks = this.randomBetween(18, 38);
            }
            int target = this.idleTicks;
            this.idleTicks = target + -1;
            activePet.setBehavior(groundedCurrent, 0.0, false, rainy, false, 1.0);
            return;
        }
        if (airborne) {
            this.idleTicks = 0;
            boolean airborneMoving = playerHorizontalSpeed > 0.08 || Math.abs(player.method_18798().field_1351) > 0.08;
            class_243 desiredAirTarget = null;
            if (airborneMoving) {
                this.followRefreshTicks = 0;
                this.airHoverOffset = null;
                desiredAirTarget = this.computeAirFollowTarget(player, playerDistance, playerHorizontalSpeed);
            } else {
                if (this.airHoverOffset == null || this.followRefreshTicks <= 0) {
                    this.airHoverOffset = this.pickAirHoverOffset(player, current);
                    this.followRefreshTicks = this.randomBetween(20, 42);
// v5 = Unit.INSTANCE;
                } else {
                    this.followRefreshTicks--;
                }
                desiredAirTarget = this.computeAirIdleTarget(player);
            }
            if (this.airSmoothedTarget == null) {
                this.airSmoothedTarget = current;
            }
            double smoothing = Math.clamp(0.07 + player.method_18798().method_1033() * (player.method_6128() ? 0.025 : 0.05) + Math.max(0.0, playerDistance - 1.5) * 0.012, 0.07, player.method_6128() ? 0.2 : 0.28);
            class_243 vec3d4 = this.airSmoothedTarget;
            Intrinsics.checkNotNull((Object)vec3d4);
            this.roamTarget = this.airSmoothedTarget = vec3d4.method_35590(desiredAirTarget, smoothing);
// v7 = Unit.INSTANCE;
        } else if (shouldFollowPlayer) {
            this.airHoverOffset = null;
            this.airSmoothedTarget = null;
            this.airFlightDirection = null;
            this.airChasing = false;
            this.idleTicks = 0;
            if (this.followRefreshTicks <= 0 || this.roamTarget == null) {
                class_243 vec3d5;
                if (playerDistance < 4.5 && this.random.method_43057() < 0.08f) {
                    this.followSide *= -1;
                }
                class_243 targetFollow = this.computeFollowTarget(player, playerDistance, playerHorizontalSpeed);
                float followSmoothing = (float)Math.clamp(0.22 + Math.max(0.0, playerDistance - 2.0) * 0.05 + playerHorizontalSpeed * 0.35, 0.22, 0.62);
                if (this.roamTarget == null) {
                    vec3d5 = targetFollow;
                } else {
                    class_243 vec3d6 = this.roamTarget;
                    Intrinsics.checkNotNull((Object)vec3d6);
                    vec3d5 = vec3d6.method_35590(targetFollow, (double)followSmoothing);
                }
                this.roamTarget = vec3d5;
                this.followRefreshTicks = playerDistance > 7.0 ? 1 : 2;
// v7 = Unit.INSTANCE;
            } else {
                this.followRefreshTicks--;
            }
        } else {
            this.airHoverOffset = null;
            this.airSmoothedTarget = null;
            this.airFlightDirection = null;
            this.airChasing = false;
            this.followRefreshTicks = 0;
            if (this.idleTicks > 0) {
                int targetFollow = this.idleTicks;
                this.idleTicks = targetFollow + -1;
                activePet.setBehavior(groundedCurrent, 0.0, false, rainy, false, 1.0);
                return;
            }
            if (this.roamTarget == null || this.shouldPickNewTarget(player, current)) {
                float idleChance;
                float f = idleChance = playerIdle ? 0.42f : 0.24f;
                if (this.random.method_43057() < idleChance) {
                    this.roamTarget = null;
                    this.idleTicks = playerIdle ? this.randomBetween(50, 140) : this.randomBetween(18, 42);
                    activePet.setBehavior(groundedCurrent, 0.0, false, rainy, false, 1.0);
                    return;
                }
                int n4 = this.followSide = this.random.method_43056() ? 1 : -1;
                if (playerIdle) {
                    this.roamTarget = this.pickRoamTarget(player, 2.0, 6.0);
                } else {
                    boolean closeRange = current.method_1025(playerPos) > 16.0 || player.method_18798().method_37268() > 0.04;
                    this.roamTarget = this.pickRoamTarget(player, closeRange);
                }
            }
// v7 = Unit.INSTANCE;
        }
        class_243 target = this.roamTarget;
        if (target == null) {
            this.idleTicks = this.randomBetween(18, 36);
            activePet.setBehavior(groundedCurrent, 0.0, false, rainy, false, 1.0);
            return;
        }
        class_243 vec3d7 = target.method_1020(current);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d7, (String)"subtract(...)");
        class_243 toDesired = vec3d7;
        double horizontalDistance = Math.hypot(toDesired.field_1352, toDesired.field_1350);
        double totalDistance = toDesired.method_1033();
        if (airborne) {
            boolean forceCatchup;
            class_1293 speedEffect2;
            class_1293 statusEffectInstance2 = speedEffect2 = player.method_6112(class_1294.field_5904);
            int speedLevel = statusEffectInstance2 != null ? statusEffectInstance2.method_5578() + 1 : 0;
            double playerSpeed = player.method_18798().method_1033();
            double stopDistance = player.method_6128() ? 0.82 : 0.48;
            double startDistance = player.method_6128() ? 1.28 : 0.78;
            boolean bl2 = forceCatchup = playerDistance > 4.0 || playerSpeed > 1.2 || playerHorizontalSpeed > 0.55;
            if (forceCatchup || totalDistance >= startDistance) {
                this.airChasing = true;
            } else if (totalDistance <= stopDistance) {
                this.airChasing = false;
            }
            double speed = Math.clamp(0.22 + playerSpeed * (player.method_6128() ? 2.45 : 1.65) + Math.max(0.0, playerDistance - 1.0) * (player.method_6128() ? 0.24 : 0.18) + (double)speedLevel * 0.07 + (player.method_5624() ? 0.08 : 0.0), 0.16, player.method_6128() ? (playerDistance > 18.0 ? 6.8 : (playerDistance > 12.0 ? 5.0 : (playerDistance > 7.0 ? 3.6 : 1.9))) : (playerDistance > 16.0 ? 3.2 : (playerDistance > 10.0 ? 2.4 : (playerDistance > 6.0 ? 1.55 : 0.95))));
            double animationSpeed = Math.clamp(1.15 + Math.max(0.0, playerDistance - 1.2) * 0.22 + playerSpeed * (player.method_6128() ? 1.8 : 1.35) + (double)speedLevel * 0.16, 1.0, player.method_6128() ? 3.1 : 2.4);
            activePet.setBehavior(target, speed, this.airChasing, false, true, animationSpeed);
            return;
        }
        if (horizontalDistance <= 0.45 && Math.abs(toDesired.field_1351) <= 0.45 && !shouldFollowPlayer) {
            this.roamTarget = null;
            this.idleTicks = playerIdle ? this.randomBetween(50, 140) : this.randomBetween(18, 42);
            activePet.setBehavior(groundedCurrent, 0.0, false, rainy, false, 1.0);
            return;
        }
        class_1293 statusEffectInstance3 = speedEffect = player.method_6112(class_1294.field_5904);
        int speedLevel = statusEffectInstance3 != null ? statusEffectInstance3.method_5578() + 1 : 0;
        double approachFactor = shouldFollowPlayer ? Math.clamp((horizontalDistance - 0.4) / 1.8, 0.12, 1.0) : 1.0;
        double speed = Math.clamp(0.055 + playerHorizontalSpeed * 0.31 + Math.max(0.0, playerDistance - 1.8) * 0.072 + (double)speedLevel * 0.028 + (player.method_5624() ? 0.028 : 0.0), 0.045, playerDistance > 8.5 ? 0.52 : (playerDistance > 6.0 ? 0.42 : (playerDistance > 4.0 ? 0.31 : 0.22))) * approachFactor;
        double animationSpeed = Math.clamp(1.0 + Math.max(0.0, playerDistance - 1.4) * 0.14 + playerHorizontalSpeed * 0.88 + (double)speedLevel * 0.12 + (player.method_5624() ? 0.06 : 0.0), 0.95, 1.85) * (shouldFollowPlayer ? Math.clamp(approachFactor + 0.3, 0.4, 1.0) : 1.0);
        activePet.setBehavior(target, speed, speed > 0.02, rainy, false, animationSpeed);
    }

    private final void tickRobotFlight(class_1657 player, class_243 current, class_243 playerPos, double playerDistance, double playerHorizontalSpeed) {
        boolean shouldFollow;
        CustomPetEntity customPetEntity = this.pet;
        if (customPetEntity == null) {
            return;
        }
        CustomPetEntity activePet = customPetEntity;
        if (playerDistance > 18.0) {
            class_243 snap;
            this.airSmoothedTarget = snap = this.pickRobotRoamTarget(player);
            this.roamTarget = snap;
            this.airFlightDirection = null;
            this.followRefreshTicks = 0;
            this.idleTicks = this.randomBetween(30, 60);
            activePet.snapTo(snap, activePet.method_36454());
            activePet.setBehavior(snap, 0.0, false, false, true, 1.0);
            return;
        }
        this.airFlightDirection = this.resolveHeading(player, 0.18);
        boolean playerMoving = playerHorizontalSpeed > 0.08;
        boolean bl = shouldFollow = playerMoving && playerDistance > 4.0 || playerDistance > 15.0;
        if (shouldFollow) {
            this.roamTarget = null;
            this.idleTicks = 0;
        }
        class_243 rawTarget = null;
        boolean wantsToMove = false;
        if (shouldFollow) {
            class_243 vec3d2 = this.airFlightDirection;
            Intrinsics.checkNotNull((Object)vec3d2);
            class_243 dir = vec3d2;
            class_243 side = new class_243(-dir.field_1350, 0.0, dir.field_1352);
            double backOffset = playerDistance > 5.0 ? 0.5 : 1.2;
            double sideOffset = 1.3 * (double)this.followSide;
            double leadDist = Math.clamp(playerHorizontalSpeed * 4.5, 0.0, 2.2);
            class_243 vec3d3 = playerPos.method_1019(dir.method_1021(leadDist - backOffset)).method_1019(side.method_1021(sideOffset));
            Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"add(...)");
            class_243 followAnchor = vec3d3;
            double hoverY = player.method_23318() + 1.5;
            double clearance = this.ceilingClearance(followAnchor.field_1352, followAnchor.field_1350, hoverY);
            rawTarget = this.enforcePersonalSpace(new class_243(followAnchor.field_1352, Math.max(hoverY, clearance), followAnchor.field_1350), player);
            wantsToMove = true;
        } else if (this.idleTicks > 0) {
            class_243 vec3d4;
            int dir = this.idleTicks;
            this.idleTicks = dir + -1;
            if (this.idleTicks <= 0) {
                this.roamTarget = null;
            }
            if ((vec3d4 = this.roamTarget) == null) {
                vec3d4 = current;
            }
            rawTarget = vec3d4;
            wantsToMove = false;
        } else if (this.roamTarget != null) {
            class_243 vec3d5 = this.roamTarget;
            Intrinsics.checkNotNull((Object)vec3d5);
            double distToRoam = current.method_1022(vec3d5);
            if (distToRoam < 1.5) {
                this.roamTarget = current;
                this.idleTicks = this.randomBetween(60, 140);
                rawTarget = current;
                wantsToMove = false;
            } else {
                class_243 vec3d6 = this.roamTarget;
                Intrinsics.checkNotNull((Object)vec3d6);
                rawTarget = vec3d6;
                wantsToMove = true;
            }
        } else {
            class_243 target;
            this.roamTarget = target = this.pickRobotRoamTarget(player);
            rawTarget = target;
            wantsToMove = true;
        }
        double bobPrimary = Math.sin((double)player.field_6012 * 0.075 + (double)this.followSide * 1.7) * 0.55;
        double bobSecondary = Math.sin((double)player.field_6012 * 0.125 + (double)this.followSide * 0.4) * 0.2;
        double verticalBob = bobPrimary + bobSecondary;
        double lateralSway = wantsToMove ? 0.0 : Math.sin((double)player.field_6012 * 0.018 + (double)this.followSide * 0.9) * 0.1;
        class_243 vec3d7 = this.airFlightDirection;
        Intrinsics.checkNotNull((Object)vec3d7);
        class_243 heading = vec3d7;
        class_243 swayDir = new class_243(-heading.field_1350, 0.0, heading.field_1352);
        class_243 desiredTarget = new class_243(rawTarget.field_1352 + swayDir.field_1352 * lateralSway, rawTarget.field_1351 + verticalBob, rawTarget.field_1350 + swayDir.field_1350 * lateralSway);
        if (this.airSmoothedTarget == null) {
            this.airSmoothedTarget = current;
        }
        double smoothing = wantsToMove ? Math.clamp(0.1 + playerHorizontalSpeed * 0.08 + Math.max(0.0, playerDistance - 1.5) * 0.018, 0.1, 0.34) : 0.07;
        class_243 vec3d8 = this.airSmoothedTarget;
        Intrinsics.checkNotNull((Object)vec3d8);
        class_243 vec3d9 = this.airSmoothedTarget = vec3d8.method_35590(desiredTarget, smoothing);
        Intrinsics.checkNotNull((Object)vec3d9);
        class_243 vec3d10 = vec3d9.method_1020(playerPos);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d10, (String)"subtract(...)");
        class_243 fromPlayer = vec3d10;
        if (fromPlayer.method_1033() > 17.5) {
            this.airSmoothedTarget = playerPos.method_1019(fromPlayer.method_1029().method_1021(17.5));
        }
        class_243 vec3d11 = this.airSmoothedTarget;
        Intrinsics.checkNotNull((Object)vec3d11);
        double targetDist = current.method_1022(vec3d11);
        double speed = wantsToMove ? Math.clamp(0.08 + targetDist * 0.06 + playerHorizontalSpeed * 0.8 + (player.method_5624() ? 0.06 : 0.0), 0.06, shouldFollow ? 1.2 : 0.25) : 0.04;
        double animSpeed = Math.clamp(1.0 + targetDist * 0.08 + playerHorizontalSpeed * 0.6, 1.0, 1.8);
        this.tickGazeReaction(player, current);
        class_243 vec3d12 = this.airSmoothedTarget;
        Intrinsics.checkNotNull((Object)vec3d12);
        activePet.setBehavior(vec3d12, speed, wantsToMove || targetDist > 0.3, false, true, animSpeed);
    }

    private final void tickUfoFlight(class_1657 player, class_243 current, class_243 playerPos, double playerDistance, double playerHorizontalSpeed) {
        boolean disturbed;
        boolean playerMoving;
        CustomPetEntity customPetEntity = this.pet;
        if (customPetEntity == null) {
            return;
        }
        CustomPetEntity activePet = customPetEntity;
        int n = this.ticks;
        this.ticks = n + 1;
        class_243 vec3d2 = player.method_18798();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"getDeltaMovement(...)");
        class_243 motion = vec3d2;
        boolean playerFlying = player.method_6128() || player.method_31549().field_7479;
        boolean bl = playerMoving = playerHorizontalSpeed > 0.04 || Math.abs(motion.field_1351) > 0.09;
        if (playerDistance > 18.0) {
            class_243 snapTarget;
            class_243 snap = this.pickUfoAnchor(player, playerHorizontalSpeed);
            double snapY = Math.max(this.findGroundY(snap.field_1352, snap.field_1350, player.method_23318()) + 1.95, player.method_23318() + 1.65);
            this.airSmoothedTarget = snapTarget = new class_243(snap.field_1352, snapY, snap.field_1350);
            this.roamTarget = null;
            this.airFlightDirection = null;
            this.ufoIdleTicks = 0;
            this.ufoRoamPauseTicks = 0;
            this.ufoChasing = false;
            activePet.setUfoGrounded(false);
            activePet.setUfoBoost(false);
            activePet.snapTo(snapTarget, activePet.method_36454());
            activePet.setBehavior(snapTarget, 0.0, false, false, true, 1.0);
            return;
        }
        this.airFlightDirection = this.resolveHeading(player, 0.16);
        boolean grounded = activePet.isUfoGrounded();
        if (grounded) {
            boolean calledAway;
            boolean bl2 = calledAway = playerDistance > 8.0 || playerFlying;
            if (!calledAway && this.ufoGroundedTicks < this.ufoRestDuration) {
                class_243 rest;
                int n2 = this.ufoGroundedTicks;
                this.ufoGroundedTicks = n2 + 1;
                double restY = this.findGroundY(current.field_1352, current.field_1350, player.method_23318());
                this.airSmoothedTarget = rest = new class_243(current.field_1352, restY, current.field_1350);
                this.roamTarget = null;
                this.ufoRoamPauseTicks = 0;
                activePet.setUfoBoost(false);
                activePet.setBehavior(rest, 0.0, false, false, false, 1.0);
                return;
            }
            activePet.setUfoGrounded(false);
            this.ufoChasing = calledAway;
            this.ufoIdleTicks = 0;
            this.ufoGroundedTicks = 0;
            this.roamTarget = null;
            this.ufoRoamPauseTicks = 0;
            grounded = false;
        }
        if (activePet.isUfoTakingOff()) {
            int remaining = activePet.getUfoTakeoffTicks();
            double padY = this.findGroundY(current.field_1352, current.field_1350, player.method_23318());
            double hoverY = this.ufoHoverY(current.field_1352, current.field_1350, player);
            double raw = Math.clamp((double)(18 - remaining) / 18.0, 0.0, 1.0);
            double lift = raw * raw * (3.0 - 2.0 * raw);
            class_243 liftTarget = new class_243(current.field_1352, class_3532.method_16436((double)lift, (double)padY, (double)hoverY), current.field_1350);
            if (this.airSmoothedTarget == null) {
                this.airSmoothedTarget = current;
            }
            class_243 vec3d3 = this.airSmoothedTarget;
            Intrinsics.checkNotNull((Object)vec3d3);
            this.airSmoothedTarget = vec3d3.method_35590(liftTarget, 0.35);
            activePet.setUfoBoost(false);
            this.tickGazeReaction(player, current);
            class_243 vec3d4 = this.airSmoothedTarget;
            Intrinsics.checkNotNull((Object)vec3d4);
            activePet.setBehavior(vec3d4, lift > 0.001 ? 0.35 : 0.0, lift > 0.001, false, true, 1.0);
            return;
        }
        if (playerDistance > 8.0 || playerFlying) {
            this.ufoChasing = true;
        } else if (playerDistance < 3.0) {
            this.ufoChasing = false;
        }
        boolean bl3 = disturbed = playerMoving || playerFlying || this.ufoChasing;
        if (disturbed) {
            this.ufoIdleTicks = 0;
        } else if (this.ufoIdleTicks <= 460) {
            int padY = this.ufoIdleTicks;
            this.ufoIdleTicks = padY + 1;
        }
        boolean wantsLanding = this.ufoIdleTicks >= 460;
        double landingGroundY = this.findGroundY(current.field_1352, current.field_1350, player.method_23318());
        if (wantsLanding && current.field_1351 - landingGroundY <= 0.12) {
            activePet.setUfoGrounded(true);
            activePet.setUfoBoost(false);
            this.ufoGroundedTicks = 0;
            this.ufoRestDuration = this.randomBetween(200, 400);
            class_243 vec3d5 = this.airSmoothedTarget = new class_243(current.field_1352, landingGroundY, current.field_1350);
            Intrinsics.checkNotNull((Object)vec3d5);
            activePet.setBehavior(vec3d5, 0.0, false, false, false, 1.0);
            return;
        }
        class_243 rawTarget = null;
        boolean wantsToMove = false;
        if (wantsLanding) {
            this.roamTarget = null;
            this.ufoRoamPauseTicks = 0;
            rawTarget = new class_243(current.field_1352, landingGroundY, current.field_1350);
            wantsToMove = true;
        } else if (this.ufoChasing) {
            this.roamTarget = null;
            this.ufoRoamPauseTicks = 0;
            class_243 anchor = this.pickUfoAnchor(player, playerHorizontalSpeed);
            rawTarget = new class_243(anchor.field_1352, this.ufoHoverY(anchor.field_1352, anchor.field_1350, player), anchor.field_1350);
            wantsToMove = true;
        } else {
            class_243 target = this.roamTarget;
            if (target == null || target.method_1025(playerPos) > 56.25) {
                class_243 newTarget;
                this.roamTarget = newTarget = this.pickUfoRoamTarget(player);
                this.ufoRoamPauseTicks = 0;
            }
            class_243 vec3d6 = this.roamTarget;
            Intrinsics.checkNotNull((Object)vec3d6);
            class_243 validTarget = vec3d6;
            if (this.ufoRoamPauseTicks <= 0 && current.method_1025(validTarget) < 0.5625) {
                this.ufoRoamPauseTicks = this.randomBetween(40, 150);
            }
            if (this.ufoRoamPauseTicks > 0) {
                int n3 = this.ufoRoamPauseTicks;
                this.ufoRoamPauseTicks = n3 + -1;
                if (this.ufoRoamPauseTicks == 0) {
                    this.roamTarget = this.pickUfoRoamTarget(player);
                }
                rawTarget = new class_243(current.field_1352, this.ufoHoverY(current.field_1352, current.field_1350, player), current.field_1350);
                wantsToMove = false;
            } else {
                rawTarget = validTarget;
                wantsToMove = true;
            }
        }
        if (!wantsLanding) {
            double bob = Math.sin((double)(this.ticks + this.followSide * 11) * 0.055) * 0.085;
            double sway = Math.sin((double)(this.ticks + this.followSide * 5) * 0.021) * 0.09;
            class_243 vec3d7 = this.airFlightDirection;
            Intrinsics.checkNotNull((Object)vec3d7);
            class_243 heading = vec3d7;
            class_243 swayDir = new class_243(-heading.field_1350, 0.0, heading.field_1352);
            rawTarget = new class_243(rawTarget.field_1352 + swayDir.field_1352 * sway, rawTarget.field_1351 + bob, rawTarget.field_1350 + swayDir.field_1350 * sway);
        }
        if (this.airSmoothedTarget == null) {
            this.airSmoothedTarget = current;
        }
        double smoothing = this.ufoChasing ? Math.clamp(0.09 + playerHorizontalSpeed * 0.1 + Math.max(0.0, playerDistance - 1.5) * 0.02, 0.09, 0.32) : 0.07;
        class_243 vec3d8 = this.airSmoothedTarget;
        Intrinsics.checkNotNull((Object)vec3d8);
        class_243 vec3d9 = this.airSmoothedTarget = vec3d8.method_35590(rawTarget, smoothing);
        Intrinsics.checkNotNull((Object)vec3d9);
        double targetDistance = current.method_1022(vec3d9);
        double speed = 0.0;
        speed = !wantsToMove ? 0.03 : (this.ufoChasing ? Math.clamp(0.1 + targetDistance * 0.07 + playerHorizontalSpeed * (playerFlying ? 1.6 : 0.95) + (player.method_5624() ? 0.05 : 0.0), 0.05, playerDistance > 9.0 ? 2.2 : (playerDistance > 5.0 ? 1.3 : 0.7)) : Math.clamp(0.045 + targetDistance * 0.02, 0.04, 0.16));
        double animationSpeed = Math.clamp(1.0 + targetDistance * 0.09 + playerHorizontalSpeed * 0.8, 1.0, 2.1);
        boolean boosting = this.ufoChasing && !wantsLanding && (playerDistance > 9.0 || playerHorizontalSpeed > 0.3 || playerFlying && targetDistance > 2.0);
        activePet.setUfoBoost(boosting);
        if (!wantsLanding && !boosting && !this.ufoChasing && this.random.method_43058() < 0.0022) {
            activePet.triggerUfoSpin();
        }
        this.tickGazeReaction(player, current);
        class_243 vec3d10 = this.airSmoothedTarget;
        Intrinsics.checkNotNull((Object)vec3d10);
        activePet.setBehavior(vec3d10, speed, wantsToMove && targetDistance > 0.05, false, true, animationSpeed);
    }

    private final double ufoHoverY(double x, double z, class_1657 player) {
        double groundY = this.findGroundY(x, z, player.method_23318());
        double hoverY = Math.max(groundY + 1.95, player.method_23318() + 1.65);
        return Math.min(hoverY, this.ufoCeilingLimit(x, z, groundY, hoverY));
    }

    private final class_243 pickUfoRoamTarget(class_1657 player) {
        double angle = this.random.method_43058() * (double)((float)Math.PI * 2);
        double radius = class_3532.method_16436((double)this.random.method_43058(), (double)2.2, (double)7.0);
        double x = player.method_23317() + Math.cos(angle) * radius;
        double z = player.method_23321() + Math.sin(angle) * radius;
        return this.enforcePersonalSpace(new class_243(x, this.ufoHoverY(x, z, player), z), player);
    }

    private final double ufoCeilingLimit(double x, double z, double groundY, double preferredY) {
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return preferredY;
        }
        class_638 level = clientWorld3;
        int blockX = class_3532.method_15357((double)x);
        int blockZ = class_3532.method_15357((double)z);
        int from = class_3532.method_15357((double)(groundY + 0.6));
        int to = class_3532.method_15384((double)(preferredY + 1.6));
        class_2338.class_2339 mutablePos = new class_2338.class_2339(blockX, from, blockZ);
        int y = from;
        if (y <= to) {
            while (true) {
                mutablePos.method_33098(y);
                class_2680 state = level.method_8320((class_2338)mutablePos);
                class_265 shape = state.method_26220((class_1922)level, (class_2338)mutablePos);
                if (!shape.method_1110()) {
                    return Math.max(groundY + 0.55, (double)y + shape.method_1091(class_2350.class_2351.field_11052) - 0.8);
                }
                if (y == to) break;
                ++y;
            }
        }
        return preferredY;
    }

    private final class_243 pickUfoAnchor(class_1657 player, double playerHorizontalSpeed) {
        class_243 vec3d2 = this.airFlightDirection;
        if (vec3d2 == null) {
            vec3d2 = this.resolveHeading(player, 1.0);
        }
        class_243 direction = vec3d2;
        class_243 side = new class_243(-direction.field_1350, 0.0, direction.field_1352);
        double lead = Math.clamp(playerHorizontalSpeed * 4.2, 0.0, 2.0);
        double back = playerHorizontalSpeed > 0.08 ? 1.0 : 1.6;
        double sideOffset = 1.25 * (double)this.followSide;
        class_243 vec3d3 = player.method_73189().method_1019(direction.method_1021(lead - back)).method_1019(side.method_1021(sideOffset));
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"add(...)");
        class_243 anchor = vec3d3;
        return this.enforcePersonalSpace(anchor, player);
    }

    private final void tickGazeReaction(class_1657 player, class_243 robotPos) {
        CustomPetEntity customPetEntity = this.pet;
        if (customPetEntity == null) {
            return;
        }
        CustomPetEntity activePet = customPetEntity;
        class_243 vec3d2 = player.method_5720();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"getLookAngle(...)");
        class_243 playerLook = vec3d2;
        class_243 vec3d3 = robotPos.method_1020(player.method_73189());
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"subtract(...)");
        class_243 toRobot = vec3d3;
        double horizontalDistance = Math.hypot(toRobot.field_1352, toRobot.field_1350);
        boolean playerLookingAtRobot = false;
        if (horizontalDistance > 0.05 && horizontalDistance < 3.5) {
            class_243 lookH = new class_243(playerLook.field_1352, 0.0, playerLook.field_1350);
            class_243 toH = new class_243(toRobot.field_1352, 0.0, toRobot.field_1350);
            if (lookH.method_1027() > 1.0E-4 && toH.method_1027() > 1.0E-4) {
                class_243 vec3d4 = lookH.method_1029();
                Intrinsics.checkNotNullExpressionValue((Object)vec3d4, (String)"normalize(...)");
                lookH = vec3d4;
                class_243 vec3d5 = toH.method_1029();
                Intrinsics.checkNotNullExpressionValue((Object)vec3d5, (String)"normalize(...)");
                toH = vec3d5;
                double dot = lookH.field_1352 * toH.field_1352 + lookH.field_1350 * toH.field_1350;
                boolean bl = playerLookingAtRobot = dot > 0.88;
            }
        }
        if (this.gazeCooldownTicks > 0) {
            int lookH = this.gazeCooldownTicks;
            this.gazeCooldownTicks = lookH + -1;
        }
        if (this.gazeLookActiveTicks > 0) {
            int lookH = this.gazeLookActiveTicks;
            this.gazeLookActiveTicks = lookH + -1;
            float yaw = (float)Math.toDegrees(class_3532.method_15349((double)(player.method_23321() - robotPos.field_1350), (double)(player.method_23317() - robotPos.field_1352))) - 90.0f;
            activePet.overrideLookYaw(yaw, 1.0f);
            if (this.gazeLookActiveTicks == 0) {
                this.gazeCooldownTicks = this.randomBetween(80, 160);
            }
            return;
        }
        activePet.overrideLookYaw(0.0f, 0.0f);
        if (!playerLookingAtRobot || this.gazeCooldownTicks > 0) {
            if (!playerLookingAtRobot) {
                this.gazeBuildTicks = 0;
            }
            return;
        }
        int n = this.gazeBuildTicks;
        this.gazeBuildTicks = n + 1;
        if (this.gazeBuildTicks >= 25) {
            this.gazeBuildTicks = 0;
            if (this.random.method_43057() < 0.65f) {
                this.gazeLookActiveTicks = this.randomBetween(40, 70);
            } else {
                this.gazeCooldownTicks = this.randomBetween(40, 90);
            }
        }
    }

    private final class_243 pickRobotRoamTarget(class_1657 player) {
        double angle = this.random.method_43058() * (double)((float)Math.PI * 2);
        double radius = 3.0 + this.random.method_43058() * 12.0;
        double x = player.method_23317() + Math.cos(angle) * radius;
        double z = player.method_23321() + Math.sin(angle) * radius;
        double baseY = player.method_23318() + 1.0 + this.random.method_43058() * 3.0;
        double clearance = this.ceilingClearance(x, z, baseY);
        return this.enforcePersonalSpace(new class_243(x, Math.max(baseY, clearance), z), player);
    }

    private final double ceilingClearance(double x, double z, double preferredY) {
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return preferredY;
        }
        class_638 level = clientWorld3;
        int blockX = class_3532.method_15357((double)x);
        int blockZ = class_3532.method_15357((double)z);
        int baseY = class_3532.method_15357((double)preferredY);
        class_2338.class_2339 mutablePos = new class_2338.class_2339(blockX, baseY, blockZ);
        int y = baseY;
        int n = baseY + 3;
        if (y <= n) {
            while (true) {
                mutablePos.method_33098(y);
                class_2680 state = level.method_8320((class_2338)mutablePos);
                class_265 shape = state.method_26220((class_1922)level, (class_2338)mutablePos);
                if (!shape.method_1110()) {
                    return (double)y + shape.method_1105(class_2350.class_2351.field_11052) + 0.6;
                }
                if (y == n) break;
                ++y;
            }
        }
        return preferredY;
    }

    private final boolean shouldPickNewTarget(class_1657 player, class_243 current) {
        class_243 vec3d2 = this.roamTarget;
        if (vec3d2 == null) {
            return true;
        }
        class_243 target = vec3d2;
        if (target.method_1025(player.method_73189()) > 225.0) {
            return true;
        }
        return current.method_1025(player.method_73189()) > 169.0 && current.method_1025(target) > 25.0;
    }

    private final boolean isRainingAbove(class_243 pos) {
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return false;
        }
        class_638 level = clientWorld3;
        return level.method_8520(class_2338.method_49637((double)pos.field_1352, (double)(pos.field_1351 + 1.1), (double)pos.field_1350));
    }

    private final class_243 pickRoamTarget(class_1657 player, boolean closeRange) {
        return closeRange ? this.pickRoamTarget(player, 1.6, 3.0) : this.pickRoamTarget(player, 2.5, 14.75);
    }

    private final class_243 pickRoamTarget(class_1657 player, double minRadius, double maxRadius) {
        class_243 vec3d2 = player.method_18798();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"getDeltaMovement(...)");
        class_243 motion = vec3d2;
        double baseAngle = motion.method_37268() > 0.0025 ? Math.atan2(motion.field_1350, motion.field_1352) : this.random.method_43058() * (double)((float)Math.PI * 2);
        double angle = baseAngle + class_3532.method_16436((double)this.random.method_43058(), (double)-1.65, (double)1.65);
        double radius = class_3532.method_16436((double)this.random.method_43058(), (double)minRadius, (double)maxRadius);
        double x = player.method_23317() + Math.cos(angle) * radius;
        double z = player.method_23321() + Math.sin(angle) * radius;
        double y = this.findGroundY(x, z, player.method_23318());
        return this.enforcePersonalSpace(new class_243(x, y, z), player);
    }

    private final class_243 computeFollowTarget(class_1657 player, double playerDistance, double playerHorizontalSpeed) {
        class_243 direction = this.resolveHeading(player, 0.35);
        double leadDistance = Math.clamp(0.6 + playerHorizontalSpeed * 7.0 + Math.max(0.0, playerDistance - 3.0) * 0.35, 0.6, 3.0);
        class_243 vec3d2 = player.method_73189().method_1019(player.method_18798().method_1021(leadDistance));
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"add(...)");
        class_243 predictedPlayerPos = vec3d2;
        double backOffset = playerDistance > 5.5 ? 0.65 : 1.45;
        double sideOffset = playerDistance > 5.5 ? 0.0 : 0.55 * (double)this.followSide;
        class_243 side = new class_243(-direction.field_1350, 0.0, direction.field_1352);
        class_243 vec3d3 = predictedPlayerPos.method_1020(direction.method_1021(backOffset)).method_1019(side.method_1021(sideOffset));
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"add(...)");
        class_243 followPos = vec3d3;
        double y = this.findGroundY(followPos.field_1352, followPos.field_1350, player.method_23318());
        return this.enforcePersonalSpace(new class_243(followPos.field_1352, y, followPos.field_1350), player);
    }

    private final class_243 resolveHeading(class_1657 player, double smoothing) {
        class_243 vec3d2 = player.method_18798();
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"getDeltaMovement(...)");
        class_243 motion = vec3d2;
        class_243 horizontal = new class_243(motion.field_1352, 0.0, motion.field_1350);
        if (horizontal.method_1027() > 9.0E-4) {
            class_243 vec3d3 = horizontal.method_1029();
            Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"normalize(...)");
            class_243 direction = vec3d3;
            class_243 currentHeading = this.playerHeading;
            if (currentHeading == null) {
                this.playerHeading = direction;
            } else {
                class_243 vec3d4 = currentHeading.method_35590(direction, smoothing);
                Intrinsics.checkNotNullExpressionValue((Object)vec3d4, (String)"lerp(...)");
                class_243 blended = vec3d4;
                this.playerHeading = blended.method_1027() < 1.0E-6 ? direction : blended.method_1029();
            }
        } else if (this.playerHeading == null) {
            float yaw = player.method_36454() * ((float)Math.PI / 180);
            this.playerHeading = new class_243((double)(-class_3532.method_15374((double)yaw)), 0.0, (double)class_3532.method_15362((double)yaw));
        }
        class_243 vec3d5 = this.playerHeading;
        Intrinsics.checkNotNull((Object)vec3d5);
        return vec3d5;
    }

    private final class_243 enforcePersonalSpace(class_243 point, class_1657 player) {
        double dz;
        double dx = point.field_1352 - player.method_23317();
        double distSqr = dx * dx + (dz = point.field_1350 - player.method_23321()) * dz;
        if (distSqr >= 0.42250000000000004) {
            return point;
        }
        double dist = Math.sqrt(distSqr);
        if (dist < 1.0E-4) {
            float yaw = player.method_36454() * ((float)Math.PI / 180);
            dx = -class_3532.method_15374((double)yaw);
            dz = class_3532.method_15362((double)yaw);
            dist = 1.0;
        }
        double scale = 0.65 / dist;
        return new class_243(player.method_23317() + dx * scale, point.field_1351, player.method_23321() + dz * scale);
    }

    private final class_243 computeAirFollowTarget(class_1657 player, double playerDistance, double playerHorizontalSpeed) {
        double playerSpeed = player.method_18798().method_1033();
        class_243 vec3d2 = this.airFlightDirection = this.resolveHeading(player, player.method_6128() ? 0.14 : 0.26);
        Intrinsics.checkNotNull((Object)vec3d2);
        class_243 direction = vec3d2;
        class_243 side = new class_243(-direction.field_1350, 0.0, direction.field_1352);
        boolean firstPerson = this.mc.field_1690.method_31044().method_31034();
        double sideOffset = (player.method_6128() ? 0.82 : 0.65) * (double)this.followSide;
        double backOffset = (player.method_6128() ? 1.45 : 1.05) + Math.min(playerDistance * 0.08, player.method_6128() ? 0.55 : 0.35);
        if (player.method_6128() && firstPerson) {
            sideOffset *= 1.18;
            backOffset += 0.42;
        }
        double liftOffset = player.method_6128() ? 0.2 : 0.45;
        double leadDistance = Math.clamp(0.45 + playerHorizontalSpeed * (player.method_6128() ? 5.8 : 4.8) + Math.max(0.0, playerSpeed - 0.8) * (player.method_6128() ? 0.45 : 0.35), 0.45, player.method_6128() ? 2.8 : 1.6);
        class_243 vec3d3 = player.method_73189().method_1019(direction.method_1021(leadDistance));
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"add(...)");
        class_243 predictedPlayerPos = vec3d3;
        double bob = Math.sin((double)(player.field_6012 + this.followSide * 7) * 0.1) * 0.028;
        class_243 vec3d4 = predictedPlayerPos.method_1020(direction.method_1021(backOffset)).method_1019(side.method_1021(sideOffset)).method_1031(0.0, player.method_23318() - predictedPlayerPos.field_1351 + liftOffset + bob, 0.0);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d4, (String)"add(...)");
        return vec3d4;
    }

    private final class_243 computeAirIdleTarget(class_1657 player) {
        class_243 fallback = this.petIsOwl ? new class_243(1.9 * (double)this.followSide, 1.6, 0.0) : new class_243(1.6 * (double)this.followSide, 0.35, 0.0);
        class_243 vec3d2 = this.airHoverOffset;
        if (vec3d2 == null) {
            vec3d2 = fallback;
        }
        class_243 offset = vec3d2;
        double bobScale = this.petIsOwl ? 0.25 : 0.09;
        double bob = Math.sin((double)(player.field_6012 + this.followSide * 7) * 0.085) * bobScale;
        class_243 vec3d3 = player.method_73189().method_1031(offset.field_1352, offset.field_1351 + bob, offset.field_1350);
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"add(...)");
        return vec3d3;
    }

    private final class_243 pickAirHoverOffset(class_1657 player, class_243 current) {
        if (this.petIsOwl) {
            double angle = this.random.method_43058() * (double)((float)Math.PI * 2);
            double radius = class_3532.method_16436((double)this.random.method_43058(), (double)1.6, (double)2.8);
            double height = class_3532.method_16436((double)this.random.method_43058(), (double)1.6, (double)3.2);
            return new class_243(Math.cos(angle) * radius, height, Math.sin(angle) * radius);
        }
        class_243 vec3d2 = current.method_1020(player.method_73189());
        Intrinsics.checkNotNullExpressionValue((Object)vec3d2, (String)"subtract(...)");
        class_243 offset = vec3d2;
        class_243 horizontal = new class_243(offset.field_1352, 0.0, offset.field_1350);
        double horizontalLength = horizontal.method_1033();
        if (horizontalLength < 0.9 || horizontalLength > 2.5) {
            double angle = this.random.method_43058() * (double)((float)Math.PI * 2);
            double radius = class_3532.method_16436((double)this.random.method_43058(), (double)1.35, (double)1.95);
            return new class_243(Math.cos(angle) * radius, class_3532.method_16436((double)this.random.method_43058(), (double)0.28, (double)0.44), Math.sin(angle) * radius);
        }
        class_243 vec3d3 = horizontal.method_1029().method_1021(Math.clamp(horizontalLength, 1.25, 1.95));
        Intrinsics.checkNotNullExpressionValue((Object)vec3d3, (String)"scale(...)");
        class_243 normalized = vec3d3;
        double y = Math.clamp(offset.field_1351, 0.24, 0.46);
        return new class_243(normalized.field_1352, y, normalized.field_1350);
    }

    private final int randomBetween(int min, int max) {
        return min + this.random.method_43048(max - min + 1);
    }

    private final class_243 snapCurrentToGround(class_243 current, double fallbackY) {
        double groundY = this.findGroundY(current.field_1352, current.field_1350, Math.max(current.field_1351, fallbackY));
        return new class_243(current.field_1352, groundY, current.field_1350);
    }

    private final double findGroundY(double x, double z, double fallbackY) {
        class_638 clientWorld3 = this.mc.field_1687;
        if (clientWorld3 == null) {
            return fallbackY;
        }
        class_638 level = clientWorld3;
        int blockX = class_3532.method_15357((double)x);
        int blockZ = class_3532.method_15357((double)z);
        int baseY = class_3532.method_15357((double)fallbackY);
        class_2338.class_2339 mutablePos = new class_2338.class_2339(blockX, baseY + 2, blockZ);
        int n = baseY - 6;
        int y = baseY + 2;
        if (n <= y) {
            while (true) {
                mutablePos.method_33098(y);
                class_2680 state = level.method_8320((class_2338)mutablePos);
                class_265 shape = state.method_26220((class_1922)level, (class_2338)mutablePos);
                if (!shape.method_1110()) {
                    return (double)y + shape.method_1105(class_2350.class_2351.field_11052);
                }
                if (y == n) break;
                --y;
            }
        }
        return fallbackY;
    }

    @Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0011\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002\u00a2\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u0014\u0010\u0007\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0007\u0010\u0006R\u0014\u0010\b\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\b\u0010\u0006R\u0014\u0010\t\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\t\u0010\u0006R\u0014\u0010\n\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\n\u0010\u0006R\u0014\u0010\u000b\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u000b\u0010\u0006R\u0014\u0010\f\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\f\u0010\u0006R\u0014\u0010\r\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\r\u0010\u0006R\u0014\u0010\u000e\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u000e\u0010\u0006R\u0014\u0010\u000f\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u000f\u0010\u0006R\u0014\u0010\u0010\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0010\u0010\u0006R\u0014\u0010\u0011\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0011\u0010\u0006R\u0014\u0010\u0012\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0012\u0010\u0006R\u0014\u0010\u0014\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0016\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0016\u0010\u0015R\u0014\u0010\u0017\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0017\u0010\u0015R\u0014\u0010\u0018\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0018\u0010\u0015R\u0014\u0010\u0019\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u0019\u0010\u0006R\u0014\u0010\u001a\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u001a\u0010\u0006R\u0014\u0010\u001b\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u001b\u0010\u0006R\u0014\u0010\u001c\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u001c\u0010\u0006R\u0014\u0010\u001d\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u001d\u0010\u0006R\u0014\u0010\u001e\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u001e\u0010\u0006R\u0014\u0010\u001f\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\u001f\u0010\u0015R\u0014\u0010 \u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b \u0010\u0015R\u0014\u0010!\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b!\u0010\u0015R\u0014\u0010\"\u001a\u00020\u00138\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b\"\u0010\u0015R\u0014\u0010#\u001a\u00020\u00048\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\b#\u0010\u0006\u00a8\u0006$"}, d2={"Lrtx/kimiko/api/modules/impl/Visuals/custompet/control/CustomPetFollowerController.Companion;", "", "<init>", "()V", "", "MAX_WANDER_DISTANCE", "D", "SNAP_BACK_DISTANCE", "FOLLOW_BREAK_DISTANCE", "FOLLOW_NEAR_DISTANCE", "TARGET_REACHED_DISTANCE", "STROLL_RADIUS_MIN", "STROLL_RADIUS_MAX", "PLAYER_PERSONAL_SPACE", "HEADING_MOTION_THRESHOLD_SQR", "OWL_HOVER_RADIUS_MIN", "OWL_HOVER_RADIUS_MAX", "OWL_HOVER_HEIGHT_MIN", "OWL_HOVER_HEIGHT_MAX", "", "OWL_FLIGHT_COOLDOWN_MIN", "I", "OWL_FLIGHT_COOLDOWN_MAX", "OWL_FLIGHT_DURATION_MIN", "OWL_FLIGHT_DURATION_MAX", "UFO_HOVER_HEIGHT", "UFO_PLAYER_LIFT", "UFO_FOLLOW_START", "UFO_FOLLOW_STOP", "UFO_ROAM_MIN", "UFO_ROAM_MAX", "UFO_LAND_DELAY", "UFO_REST_MIN", "UFO_REST_MAX", "UFO_TAKEOFF_LIFT_TICKS", "UFO_TRICK_CHANCE", "rtx.kimiko:kimiko"})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

