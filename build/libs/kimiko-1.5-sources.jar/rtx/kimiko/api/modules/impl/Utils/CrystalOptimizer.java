/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.Hand
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.hit.HitResult
 *  net.minecraft.util.hit.EntityHitResult
 *  net.minecraft.client.network.ClientPlayerInteractionManager
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.jetbrains.annotations.NotNull
 */
package rtx.kimiko.api.modules.impl.Utils;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;
import rtx.kimiko.api.events.EventHandler;
import rtx.kimiko.api.events.impl.game.TickEvent;
import rtx.kimiko.api.liteapi.Feature;
import rtx.kimiko.api.modules.Category;
import rtx.kimiko.api.modules.Module;
import rtx.kimiko.api.modules.restrict.Server;
import rtx.kimiko.api.modules.restrict.ServerRule;

@ServerRule(mode=ServerRule.Mode.ONLY, servers={Server.RW, Server.SATURN})
@Feature(value={"crystaloptimizer"})
@Metadata(mv={2, 4, 0}, k=1, xi=48, d1={"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\u001b\u0010\b\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007b\u0002\b\u0007\u00a2\u0006\u0004\b\b\u0010\t\u00ca\u0001&\b\n\u0012\n\b\u000b\u0012\u0006\b\n0\f8\r\u0012\u0016\b\u000e\u0012\u0012\b\fJ\u0006\b\n0\u000f8\u0010J\u0006\b\n0\u000f8\u0011\u00ca\u0001\u0010\b\u0012\u0012\f\b\u0013\u0012\b\b\fJ\u0004\b\b(\u0014\u00a8\u0006\u0015"}, d2={"Lrtx/kimiko/api/modules/impl/Utils/CrystalOptimizer;", "Lrtx/kimiko/api/modules/Module;", "<init>", "()V", "Lrtx/kimiko/api/events/impl/game/TickEvent;", "event", "", "Lrtx/kimiko/api/events/EventHandler;", "onTick", "(Lrtx/kimiko/api/events/impl/game/TickEvent;)V", "Lrtx/kimiko/api/modules/restrict/ServerRule;", "mode", "Lrtx/kimiko/api/modules/restrict/ServerRule$Mode;", "ONLY", "servers", "Lrtx/kimiko/api/modules/restrict/Server;", "RW", "SATURN", "Lrtx/kimiko/api/liteapi/Feature;", "value", "crystaloptimizer", "rtx.kimiko:kimiko"})
public final class CrystalOptimizer
extends Module {
    public CrystalOptimizer() {
        super("Crystal Optimizer", "Убирает задержку разбивания энд-кристаллов при удержании атаки.", Category.UTILS);
    }

    @EventHandler
    public final void onTick(@NotNull TickEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!event.isPre()) {
            return;
        }
        class_746 clientPlayerEntity2 = this.mc.field_1724;
        if (clientPlayerEntity2 == null) {
            return;
        }
        class_746 player = clientPlayerEntity2;
        class_636 clientPlayerInteractionManager2 = this.mc.field_1761;
        if (clientPlayerInteractionManager2 == null) {
            return;
        }
        class_636 gameMode = clientPlayerInteractionManager2;
        if (this.mc.field_1687 == null || this.mc.field_1755 != null) {
            return;
        }
        if (!this.mc.field_1690.field_1886.method_1434()) {
            return;
        }
        class_239 hit = this.mc.field_1765;
        if (!(hit instanceof class_3966)) {
            return;
        }
        class_1297 entity2 = ((class_3966)hit).method_17782();
        class_1511 endCrystalEntity2 = entity2 instanceof class_1511 ? (class_1511)entity2 : null;
        if (endCrystalEntity2 == null) {
            return;
        }
        class_1511 crystal = endCrystalEntity2;
        player.method_7350();
        gameMode.method_2918((class_1657)player, (class_1297)crystal);
        player.method_6104(class_1268.field_5808);
    }
}

