/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.render.GuiRenderer
 *  net.minecraft.client.gui.render.SpecialGuiElementRenderer
 *  net.minecraft.client.gui.render.state.GuiRenderState
 *  net.minecraft.client.gui.render.state.special.SpecialGuiElementRenderState
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.command.RenderDispatcher
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Mutable
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin.emotions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_11228;
import net.minecraft.class_11239;
import net.minecraft.class_11246;
import net.minecraft.class_11256;
import net.minecraft.class_11659;
import net.minecraft.class_11684;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.emotions.EmotionPreviewRenderer;
import rtx.kimiko.api.modules.impl.Visuals.emotions.EmotionPreviewState;
import rtx.kimiko.utils.render.others.hud.HotbarItemPipRenderer;
import rtx.kimiko.utils.render.others.hud.HotbarItemPipState;

@Mixin(value={class_11228.class})
public abstract class GuiRendererEmotionPipMixin {
    @Shadow
    @Final
    @Mutable
    private Map<Class<? extends class_11256>, class_11239<?>> specialElementRenderers;

    @Inject(method={"<init>"}, at={@At(value="RETURN")}, require=0)
    private void kimiko$registerEmotionPreview(class_11246 renderState, class_4597.class_4598 bufferSource, class_11659 collector, class_11684 features, List<class_11239<?>> renderers, CallbackInfo ci) {
        HashMap extended = new HashMap(this.specialElementRenderers);
        extended.put(EmotionPreviewState.class, new EmotionPreviewRenderer(bufferSource));
        extended.put(HotbarItemPipState.class, new HotbarItemPipRenderer(bufferSource));
        this.specialElementRenderers = extended;
    }
}

