/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.EntityRenderState
 *  net.minecraft.client.render.entity.state.ItemEntityRenderState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.client.render.Frustum
 *  net.minecraft.client.render.entity.EntityRenderer
 *  net.minecraft.client.render.entity.ItemEntityRenderer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import net.minecraft.class_10017;
import net.minecraft.class_10039;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.modules.impl.Utils.Optimization;
import rtx.kimiko.api.modules.impl.Visuals.ItemPhysics;
import rtx.kimiko.api.modules.impl.Visuals.ModelCollapse;
import rtx.kimiko.api.modules.impl.Visuals.NameTags;
import rtx.kimiko.api.modules.impl.Visuals.NoRender;

@Mixin(value={class_897.class})
public abstract class EntityRendererMixin {
    @Inject(method={"shouldRender"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$skipHiddenEntities(class_1297 entity, class_4604 frustum, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
        class_1309 living;
        if (entity instanceof class_1309 && ModelCollapse.shouldHideEntity(living = (class_1309)entity)) {
            cir.setReturnValue(false);
            return;
        }
        if (!(entity instanceof class_1657) && NameTags.hidesNameTagFor(entity)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"updateRenderState"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$noEntityEffects(class_1297 entity, class_10017 state, float partialTick, CallbackInfo ci) {
        if (NoRender.isActive("Огонь на сущностях")) {
            state.field_53335 = false;
        }
        if (NoRender.isActive("Свечение")) {
            state.field_61821 = 0;
        }
    }

    @Inject(method={"updateShadow(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;)V"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$scaleItemShadow(class_1297 entity, class_10017 state, CallbackInfo ci) {
        if (!((Object)this instanceof class_916)) {
            return;
        }
        ItemPhysics physics = ItemPhysics.getInstance();
        if (physics == null || !physics.isEnabled() || !physics.isNormalMode()) {
            return;
        }
        if (!(entity instanceof class_1542) || !(state instanceof class_10039)) {
            return;
        }
        float scale = physics.groundItemScale();
        if (Math.abs(scale - 1.0f) > 0.001f) {
            state.field_61822 *= scale;
        }
    }

    @Inject(method={"updateShadow(Lnet/minecraft/client/render/entity/state/EntityRenderState;Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/world/World;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$skipShadow(CallbackInfo ci) {
        if (Optimization.hideEntityShadows()) {
            ci.cancel();
        }
    }
}

