/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Hand
 *  net.minecraft.util.ActionResult
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.screen.slot.SlotActionType
 *  net.minecraft.util.hit.EntityHitResult
 *  net.minecraft.client.network.ClientPlayerInteractionManager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.inventory.ClickSlotEvent;
import rtx.kimiko.api.events.impl.player.AttackEntityEvent;
import rtx.kimiko.api.events.impl.player.InteractEntityEvent;
import rtx.kimiko.api.modules.impl.Visuals.custompet.entity.CustomPetEntity;

@Mixin(value={class_636.class})
public abstract class MultiPlayerGameModeMixin {
    @Inject(method={"clickSlot"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$clickSlotHook(int containerId, int slotId, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        ClickSlotEvent event = EventBus.get().post(new ClickSlotEvent(containerId, slotId, button, actionType));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"attackEntity"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$onAttack(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (target instanceof CustomPetEntity) {
            ci.cancel();
            return;
        }
        AttackEntityEvent attackEvent = EventBus.get().post(new AttackEntityEvent(target));
        InteractEntityEvent interactEvent = EventBus.get().post(new InteractEntityEvent(target));
        if (attackEvent.isCancelled() || interactEvent.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"interactEntity"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$cancelInteract(class_1657 player, class_1297 target, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        this.kimiko$cancelEntityInteraction(target, cir);
    }

    @Inject(method={"interactEntityAtLocation"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$cancelInteractAt(class_1657 player, class_1297 target, class_3966 hitResult, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        this.kimiko$cancelEntityInteraction(target, cir);
    }

    private void kimiko$cancelEntityInteraction(class_1297 target, CallbackInfoReturnable<class_1269> cir) {
        if (target instanceof CustomPetEntity) {
            cir.setReturnValue(class_1269.field_5811);
            return;
        }
        InteractEntityEvent event = EventBus.get().post(new InteractEntityEvent(target));
        if (event.isCancelled()) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }
}

