/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  com.mojang.blaze3d.systems.RenderPass
 *  net.minecraft.client.render.BlockRenderLayerGroup
 *  net.minecraft.client.render.SectionRenderState
 *  net.minecraft.client.gl.GpuSampler
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.MinecraftClient
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import net.minecraft.class_11531;
import net.minecraft.class_11532;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.FogBlur;
import rtx.kimiko.utils.render.modules.post.customsky.CustomSkyRenderer;
import rtx.kimiko.utils.render.modules.post.fogblur.FogBlurRenderer;
import rtx.kimiko.utils.render.modules.targetesp.wave.WindWaveRenderer;

@Mixin(value={class_11532.class})
public class ChunkSectionsToRenderMixin {
    @Inject(method={"renderSection"}, at={@At(value="RETURN")}, require=0)
    private void kimiko$applySkyAfterOpaque(class_11531 group, class_12137 sampler, CallbackInfo ci) {
        try {
            if (group != class_11531.field_61022) {
                return;
            }
            CustomSkyRenderer.applyPending(class_310.method_1551().method_1522());
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Inject(method={"renderSection"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$captureOpaqueDepth(class_11531 group, class_12137 sampler, CallbackInfo ci) {
        try {
            if (group != class_11531.field_61023) {
                return;
            }
            class_276 main = class_310.method_1551().method_1522();
            FogBlur fogBlur = FogBlur.getInstance();
            if (fogBlur != null && fogBlur.isEnabled() && !FogBlurRenderer.isDisabledAfterError()) {
                FogBlurRenderer.captureOpaqueDepth(main);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Redirect(method={"renderSection"}, at=@At(value="INVOKE", target="Lcom/mojang/blaze3d/systems/RenderPass;setPipeline(Lcom/mojang/blaze3d/pipeline/RenderPipeline;)V"), require=0)
    private void kimiko$swapWavePipeline(RenderPass pass, RenderPipeline pipeline) {
        try {
            RenderPipeline target = WindWaveRenderer.substitute(pipeline);
            if (target != pipeline) {
                pass.setPipeline(target);
                WindWaveRenderer.bindParams(pass);
                return;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        pass.setPipeline(pipeline);
    }
}

