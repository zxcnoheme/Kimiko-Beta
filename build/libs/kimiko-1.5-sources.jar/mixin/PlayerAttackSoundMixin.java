/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.sound.SoundEvent
 *  net.minecraft.sound.SoundEvents
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.FakePlayer;

@Mixin(value={class_1657.class})
public abstract class PlayerAttackSoundMixin {
    @Unique
    private boolean kimiko$attackingFakePlayer;
    @Unique
    private boolean kimiko$criticalFakePlayerAttack;
    @Unique
    private boolean kimiko$vanillaCriticalSound;

    @Inject(method={"attack"}, at={@At(value="HEAD")})
    private void kimiko$beginFakePlayerAttack(class_1297 target, CallbackInfo ci) {
        this.kimiko$attackingFakePlayer = FakePlayer.isFakePlayer(target);
        class_1657 player = (class_1657)(Object)this;
        boolean airborne = !player.method_24828() || player.field_6017 > 0.0 || player.method_18798().field_1351 > 0.05;
        this.kimiko$criticalFakePlayerAttack = this.kimiko$attackingFakePlayer && airborne && player.method_7261(0.5f) > 0.9f && !player.method_6101() && !player.method_5799() && !player.method_74025() && !player.method_5765() && !player.method_5624();
        this.kimiko$vanillaCriticalSound = false;
    }

    @Inject(method={"attack"}, at={@At(value="RETURN")})
    private void kimiko$endFakePlayerAttack(class_1297 target, CallbackInfo ci) {
        if (this.kimiko$criticalFakePlayerAttack && !this.kimiko$vanillaCriticalSound) {
            ((class_1657)(Object)this).method_7277(target);
        }
        this.kimiko$attackingFakePlayer = false;
        this.kimiko$criticalFakePlayerAttack = false;
    }

    @Inject(method={"playAttackSound"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$playFakePlayerAttackSound(class_3414 sound, CallbackInfo ci) {
        if (!this.kimiko$attackingFakePlayer) {
            return;
        }
        class_1657 player = (class_1657)(Object)this;
        this.kimiko$vanillaCriticalSound = sound == class_3417.field_15016;
        class_3414 localSound = this.kimiko$criticalFakePlayerAttack ? class_3417.field_15016 : sound;
        player.method_73183().method_8486(player.method_23317(), player.method_23318(), player.method_23321(), localSound, player.method_5634(), 1.0f, 1.0f, false);
        ci.cancel();
    }

    @Inject(method={"knockbackTarget"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$cancelFakePlayerAttackPhysics(class_1297 target, float knockback, class_243 movement, CallbackInfo ci) {
        if (this.kimiko$attackingFakePlayer) {
            ci.cancel();
        }
    }
}

