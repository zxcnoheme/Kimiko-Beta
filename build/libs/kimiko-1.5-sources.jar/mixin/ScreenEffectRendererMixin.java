/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.Sprite
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.gui.hud.InGameOverlayRenderer
 *  net.minecraft.util.math.random.Random
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.NoRender;
import rtx.kimiko.api.modules.impl.Visuals.WastedDeath;

@Mixin(value={class_4603.class})
public abstract class ScreenEffectRendererMixin {
    @Inject(method={"renderFireOverlay"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private static void kimiko$noRenderFire(class_4587 matrices, class_4597 vertexConsumers, class_1058 sprite, CallbackInfo ci) {
        if (NoRender.isActive("Огонь")) {
            ci.cancel();
        }
    }

    @Inject(method={"setFloatingItem"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$noTotemPopAnimation(class_1799 stack, class_5819 random, CallbackInfo ci) {
        if (stack.method_31574(class_1802.field_8288) && NoRender.isActive("Тотем")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderOverlays"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$wastedHideOverlay(boolean sleeping, float partialTick, class_11659 collector, CallbackInfo ci) {
        if (WastedDeath.isRunning()) {
            ci.cancel();
        }
    }
}

