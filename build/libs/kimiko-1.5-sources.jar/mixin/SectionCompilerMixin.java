/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.client.render.model.BlockModelPart
 *  net.minecraft.world.BlockRenderView
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.block.BlockState
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.block.BlockRenderManager
 *  net.minecraft.client.render.chunk.SectionBuilder
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_776;
import net.minecraft.class_9810;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import rtx.kimiko.utils.render.modules.targetesp.wave.WindWaveTagger;

@Mixin(value={class_9810.class})
public class SectionCompilerMixin {
    @WrapOperation(method={"build"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/block/BlockRenderManager;renderBlock(Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZLjava/util/List;)V")}, require=0)
    private void kimiko$tagWavingVertices(class_776 dispatcher, class_2680 state, class_2338 pos, class_1920 level, class_4587 poseStack, class_4588 consumer, boolean checkSides, List<class_10889> parts, Operation<Void> original) {
        class_4588 target = consumer;
        try {
            target = WindWaveTagger.wrap(consumer, state, pos, level);
        }
        catch (Throwable ignored) {
            target = consumer;
        }
        original.call(new Object[]{dispatcher, state, pos, level, poseStack, target, checkSides, parts});
    }
}

