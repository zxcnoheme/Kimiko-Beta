/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.text.Text
 *  net.minecraft.scoreboard.ScoreboardObjective
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.hud.InGameHud
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.hud.PlayerListHud
 *  net.minecraft.scoreboard.ScoreboardDisplaySlot
 *  net.minecraft.client.render.RenderTickCounter
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_8646;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.drags.components.ScoreboardComp;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.render.DrawEvent;
import rtx.kimiko.api.events.impl.render.HudRenderEvent;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.CustomHotbar;
import rtx.kimiko.api.modules.impl.Interface.PotionsModule;
import rtx.kimiko.api.modules.impl.Utils.StreamerMode;
import rtx.kimiko.api.modules.impl.Utils.guishare.RemoteGuiWorld;
import rtx.kimiko.api.modules.impl.Visuals.BetterMinecraft;
import rtx.kimiko.api.modules.impl.Visuals.Crosshair;
import rtx.kimiko.api.modules.impl.Visuals.ItemHighlight;
import rtx.kimiko.api.modules.impl.Visuals.NoRender;
import rtx.kimiko.api.modules.impl.Visuals.emotions.EmotionWheelOverlay;
import rtx.kimiko.api.ui.BaseScreen;
import rtx.kimiko.api.ui.UI;
import rtx.kimiko.api.ui.logo.LogoToy;
import rtx.kimiko.utils.animations.TabListAnimationAccess;
import rtx.kimiko.utils.render.others.LoadingVisualGuard;
import rtx.kimiko.utils.render.others.hud.HotbarItemAnimator;
import rtx.kimiko.utils.render.others.hud.VanillaHudTransform;
import rtx.kimiko.utils.render.render2d.Render2D;
import rtx.kimiko.utils.render.render2d.Render2DCoordinateSpace;
import rtx.kimiko.utils.render.util.warmup.Render2DWarmup;

@Mixin(value={class_329.class})
public abstract class GuiMixin {
    @Shadow
    @Final
    private class_310 client;
    @Shadow
    @Final
    private class_355 playerListHud;
    @Shadow
    @Final
    private static class_2960 HOTBAR_TEXTURE;
    @Shadow
    @Final
    private static class_2960 HOTBAR_SELECTION_TEXTURE;
    @Shadow
    @Final
    private static class_2960 HOTBAR_OFFHAND_LEFT_TEXTURE;
    @Shadow
    @Final
    private static class_2960 HOTBAR_OFFHAND_RIGHT_TEXTURE;
    @Unique
    private boolean kimiko$debugEarly;
    @Unique
    private boolean kimiko$scoreboardPushed;
    @Unique
    private float kimiko$left;
    @Unique
    private float kimiko$top;
    @Unique
    private float kimiko$right;
    @Unique
    private float kimiko$bottom;
    @Unique
    private boolean kimiko$boxStarted;

    @Shadow
    public abstract void renderDebugHud(class_332 var1);

    @Inject(method={"render"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/hud/InGameHud;renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", shift=At.Shift.BEFORE)})
    private void kimiko$renderHudUnderVanilla(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (LoadingVisualGuard.shouldSuppressHud(this.client)) {
            return;
        }
        EventBus.get().post(new HudRenderEvent(graphics, deltaTracker));
        graphics.method_71048();
    }

    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void kimiko$renderRemoteGuiPanels(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (LoadingVisualGuard.shouldSuppressHud(this.client)) {
            return;
        }
        RemoteGuiWorld.renderPanels(graphics);
    }

    @Inject(method={"render"}, at={@At(value="RETURN")})
    private void kimiko$renderTopLayer(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (LoadingVisualGuard.shouldSuppressHud(this.client)) {
            Render2DWarmup.runWarmupFrame(graphics);
            return;
        }
        EventBus.get().post(new DrawEvent(graphics, deltaTracker));
        UI.renderClosingPanelOverHud(graphics);
        BaseScreen.renderClosingOverlay(graphics);
        LogoToy.renderOverlay(graphics);
        EmotionWheelOverlay.render(graphics);
        if (UI.isOpen() && this.client.method_53526() != null && this.client.method_53526().method_53536()) {
            this.kimiko$debugEarly = true;
            this.renderDebugHud(graphics);
            this.kimiko$debugEarly = false;
        }
    }

    @Inject(method={"renderDebugHud"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$moveDebugUnderClickGui(class_332 graphics, CallbackInfo ci) {
        if (!this.kimiko$debugEarly && UI.isOpen()) {
            ci.cancel();
        }
    }

    @Inject(method={"renderStatusEffectOverlay"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$hideVanillaEffects(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        PotionsModule potions = ModuleManager.get().get(PotionsModule.class);
        if (potions != null && potions.isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method={"renderFood"}, at={@At(value="RETURN")}, require=0)
    private void kimiko$renderSaturation(class_332 graphics, class_1657 player, int top, int right, CallbackInfo ci) {
        BetterMinecraft.renderSaturation(graphics, player, top, right);
    }

    @Inject(method={"renderHotbar"}, at={@At(value="HEAD")}, require=1)
    private void kimiko$renderCustomHotbar(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        CustomHotbar module = CustomHotbar.getInstance();
        if (module != null && module.isEnabled()) {
            module.render(graphics);
        }
    }

    @Redirect(method={"renderHotbar"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIII)V"), require=1)
    private void kimiko$replaceHotbarSprites(class_332 graphics, RenderPipeline pipeline, class_2960 sprite, int x, int y, int width, int height) {
        if (CustomHotbar.isActive() && GuiMixin.isHotbarFrame(sprite)) {
            return;
        }
        graphics.method_52706(pipeline, sprite, x, y, width, height);
    }

    private static boolean isHotbarFrame(class_2960 sprite) {
        return HOTBAR_TEXTURE.equals((Object)sprite) || HOTBAR_SELECTION_TEXTURE.equals((Object)sprite) || HOTBAR_OFFHAND_LEFT_TEXTURE.equals((Object)sprite) || HOTBAR_OFFHAND_RIGHT_TEXTURE.equals((Object)sprite);
    }

    @Inject(method={"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$hideScoreboard(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (NoRender.isActive("Таблица счёта")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderBossBarHud"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$hideBossBar(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (NoRender.isActive("Полоса босса")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderCrosshair"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$hideVanillaCrosshair(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        Crosshair crosshair = ModuleManager.get().get(Crosshair.class);
        if (crosshair != null && crosshair.isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method={"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$beginScoreboard(class_332 graphics, class_266 objective, CallbackInfo ci) {
        this.kimiko$boxStarted = false;
        this.kimiko$scoreboardPushed = false;
        ScoreboardComp comp = ScoreboardComp.get();
        if (comp == null || !comp.hasLayout()) {
            return;
        }
        this.kimiko$scoreboardPushed = VanillaHudTransform.push(graphics, comp, comp.vanillaLeft(), comp.vanillaTop(), comp.scale());
    }

    @WrapOperation(method={"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V")}, require=0)
    private void kimiko$measureScoreboard(class_332 instance, int x1, int y1, int x2, int y2, int color, Operation<Void> original) {
        if (!this.kimiko$boxStarted) {
            this.kimiko$boxStarted = true;
            this.kimiko$left = x1;
            this.kimiko$top = y1;
            this.kimiko$right = x2;
            this.kimiko$bottom = y2;
        } else {
            this.kimiko$left = Math.min(this.kimiko$left, (float)x1);
            this.kimiko$top = Math.min(this.kimiko$top, (float)y1);
            this.kimiko$right = Math.max(this.kimiko$right, (float)x2);
            this.kimiko$bottom = Math.max(this.kimiko$bottom, (float)y2);
        }
        original.call(new Object[]{instance, x1, y1, x2, y2, color});
    }

    @Inject(method={"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"}, at={@At(value="RETURN")}, require=0)
    private void kimiko$endScoreboard(class_332 graphics, class_266 objective, CallbackInfo ci) {
        ScoreboardComp comp;
        if (this.kimiko$scoreboardPushed) {
            VanillaHudTransform.pop(graphics);
            this.kimiko$scoreboardPushed = false;
        }
        if ((comp = ScoreboardComp.get()) != null && this.kimiko$boxStarted) {
            comp.measured(this.kimiko$left, this.kimiko$top, this.kimiko$right - this.kimiko$left, this.kimiko$bottom - this.kimiko$top);
        }
    }

    @Inject(method={"renderPlayerList"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$renderClosingTabList(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        TabListAnimationAccess animation;
        class_355 playerListHud2 = this.playerListHud;
        if (!(playerListHud2 instanceof TabListAnimationAccess) || !(animation = (TabListAnimationAccess)playerListHud2).kimiko$shouldRenderClosingTab()) {
            return;
        }
        if (this.client.field_1687 == null || this.client.field_1690.field_1907.method_1434()) {
            return;
        }
        class_269 scoreboard = this.client.field_1687.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45156);
        this.playerListHud.method_1919(graphics, graphics.method_51421(), scoreboard, objective);
    }

    @ModifyArg(method={"renderHotbar"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIII)V", ordinal=1), index=2, require=1)
    private int kimiko$animateHotbarSelection(int targetX) {
        return BetterMinecraft.animateHotbarSelectionX(targetX);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @WrapMethod(method={"renderMainHud"})
    private void kimiko$liftHotbarWithChat(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
        float offset = BetterMinecraft.chatHotbarLiftOffset();
        if (offset <= 0.01f) {
            original.call(new Object[]{guiGraphics, deltaTracker});
            HotbarItemAnimator.renderOverlay(guiGraphics);
            return;
        }
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(0.0f, -offset);
        try {
            original.call(new Object[]{guiGraphics, deltaTracker});
            HotbarItemAnimator.renderOverlay(guiGraphics);
        }
        finally {
            guiGraphics.method_51448().popMatrix();
        }
    }

    @WrapOperation(method={"renderHotbarItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;III)V")})
    private void kimiko$animateHotbarItem(class_332 graphics, class_1309 entity, class_1799 stack, int x, int y, int seed, Operation<Void> original) {
        if (CustomHotbar.isActive() && HotbarItemAnimator.captureItem(graphics, entity, stack, x, y, seed)) {
            return;
        }
        original.call(new Object[]{graphics, entity, stack, x, y, seed});
    }

    @WrapOperation(method={"renderHotbarItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;II)V")})
    private void kimiko$moveHotbarItemDecorations(class_332 graphics, class_327 font, class_1799 stack, int x, int y, Operation<Void> original) {
        if (CustomHotbar.isActive() && HotbarItemAnimator.captureDecorations(graphics, stack, x, y)) {
            return;
        }
        original.call(new Object[]{graphics, font, stack, x, y});
    }

    @Inject(method={"renderHotbarItem"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$hotbarHighlightBackground(class_332 graphics, int x, int y, class_9779 deltaTracker, class_1657 player, class_1799 stack, int seed, CallbackInfo ci) {
        if (graphics == null || stack == null || stack.method_7960()) {
            return;
        }
        ItemHighlight module = ItemHighlight.getInstance();
        if (module == null) {
            return;
        }
        int argb = module.backgroundFor(stack, true);
        if (argb != 0) {
            if (CustomHotbar.isActive()) {
                float nativeScale = (float)Render2DCoordinateSpace.guiScale() / Render2DCoordinateSpace.designGuiScale();
                graphics.method_51448().pushMatrix();
                graphics.method_51448().scale(nativeScale);
                Render2D.beginFrame(graphics);
                float[] frame = HotbarItemAnimator.highlightFrame(graphics, x, y, CustomHotbar.cellCornerRadius());
                if (frame != null) {
                    module.drawRoundedSlotBackground(frame[0], frame[1], frame[2], frame[3], frame[4], argb, 1.0f);
                } else {
                    module.drawRoundedSlotBackground(x, y, 16.0f, argb, 1.0f);
                }
                Render2D.flush();
                graphics.method_51448().popMatrix();
            } else {
                module.drawSlotBackground(graphics, x, y, argb);
            }
        }
    }

    @WrapOperation(method={"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)V")}, require=0)
    private void kimiko$scoreboardRank(class_332 graphics, class_327 font, class_2561 text, int x, int y, int color, boolean shadow, Operation<Void> original) {
        original.call(new Object[]{graphics, font, StreamerMode.applySelfRank(text), x, y, color, shadow});
    }
}

