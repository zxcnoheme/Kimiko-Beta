/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.llamalad7.mixinextras.sugar.Local
 *  com.llamalad7.mixinextras.sugar.impl.SugarWrapper
 *  net.minecraft.client.render.item.ItemRenderState
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.command.RenderDispatcher
 *  net.minecraft.util.Hand
 *  net.minecraft.util.Arm
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.consume.UseAction
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.render.item.HeldItemRenderer
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.item.ItemDisplayContext
 *  org.joml.Quaternionfc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_11684;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.ShaderHands;
import rtx.kimiko.api.modules.impl.Visuals.SwingAnimation;
import rtx.kimiko.api.modules.impl.Visuals.ViewModel;
import rtx.kimiko.utils.render.modules.post.handsflame.HandsItemHitboxTracker;
import rtx.kimiko.utils.render.modules.post.itemoutline.ItemOutlineRenderer;
import rtx.kimiko.utils.render.modules.post.shaderhands.ShaderHandsRenderer;

@Mixin(value={class_759.class})
public abstract class ItemInHandRendererMixin {
    @Unique
    private class_4587 kimiko$customSwingMatrices;
    @Unique
    private class_1268 kimiko$customSwingHand;
    @Unique
    private float kimiko$customSwingProgress;
    @Unique
    private class_1268 kimiko$outlineHand;
    @Unique
    private float kimiko$mainCx;
    @Unique
    private float kimiko$mainCy;
    @Unique
    private float kimiko$mainCz;
    @Unique
    private float kimiko$offCx;
    @Unique
    private float kimiko$offCy;
    @Unique
    private float kimiko$offCz;
    @Unique
    private boolean kimiko$mainCenterSet;
    @Unique
    private boolean kimiko$offCenterSet;
    @Unique
    private static final float kimiko$EAT_DRIFT_X = 0.2f;
    @Unique
    private static final float kimiko$EAT_DRIFT_Y = -0.05f;

    @WrapOperation(method={"renderFirstPersonItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V")}, require=0)
    private void kimiko$baseSwingAnimation(class_759 instance, class_4587 matrices, class_1306 arm, float equipProgress, Operation<Void> original, @Local(argsOnly=true) class_742 player, @Local(argsOnly=true) class_1268 hand, @Local(argsOnly=true, ordinal=2) float swingProgress) {
        ViewModel.apply(matrices, hand);
        if (player.method_6115() && player.method_6058() == hand) {
            float eq = ViewModel.suppressEatAnimation() ? 0.0f : equipProgress;
            original.call(new Object[]{instance, matrices, arm, Float.valueOf(eq)});
            ViewModel.applyScale(matrices, hand);
            this.kimiko$applyInPlaceEat(matrices, hand, arm, player);
            return;
        }
        if (SwingAnimation.applyAnimation(matrices, hand, swingProgress)) {
            ViewModel.applyScale(matrices, hand);
            this.kimiko$markCustomSwing(matrices, hand, swingProgress);
            return;
        }
        original.call(new Object[]{instance, matrices, arm, Float.valueOf(equipProgress)});
        ViewModel.applyScale(matrices, hand);
    }

    @WrapOperation(method={"renderFirstPersonItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/item/HeldItemRenderer;applyEatOrDrinkTransformation(Lnet/minecraft/client/util/math/MatrixStack;FLnet/minecraft/util/Arm;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/PlayerEntity;)V")}, require=0)
    private void kimiko$suppressEatTransform(class_759 instance, class_4587 poseStack, float tickDelta, class_1306 arm, class_1799 stack, class_1657 player, Operation<Void> original) {
        if (ViewModel.suppressEatAnimation()) {
            return;
        }
        original.call(new Object[]{instance, poseStack, Float.valueOf(tickDelta), arm, stack, player});
    }

    @Unique
    private void kimiko$applyInPlaceEat(class_4587 matrices, class_1268 hand, class_1306 arm, class_742 player) {
        float cz;
        float cy;
        float cx;
        boolean main;
        if (!ViewModel.suppressEatAnimation()) {
            return;
        }
        class_1799 stack = player.method_5998(hand);
        class_1839 anim = stack.method_7976();
        if (anim != class_1839.field_8950 && anim != class_1839.field_8946) {
            return;
        }
        boolean bl = main = hand == class_1268.field_5808;
        if (main && this.kimiko$mainCenterSet) {
            cx = this.kimiko$mainCx;
            cy = this.kimiko$mainCy;
            cz = this.kimiko$mainCz;
        } else if (!main && this.kimiko$offCenterSet) {
            cx = this.kimiko$offCx;
            cy = this.kimiko$offCy;
            cz = this.kimiko$offCz;
        } else {
            int s = arm == class_1306.field_6183 ? 1 : -1;
            cx = 0.070625f * (float)s;
            cy = 0.2f;
            cz = 0.070625f;
        }
        float ft = class_310.method_1551().method_61966().method_60637(false);
        float g = (float)player.method_6014() - ft + 1.0f;
        float h = g / (float)stack.method_7935((class_1309)player);
        if (h < 0.8f) {
            float bob = class_3532.method_15379((float)(class_3532.method_15362((double)(g / 4.0f * (float)Math.PI)) * 0.1f));
            matrices.method_46416(0.0f, bob, 0.0f);
        }
        float i = 1.0f - (float)Math.pow(h, 27.0);
        int j = arm == class_1306.field_6183 ? 1 : -1;
        matrices.method_46416((float)(-j) * i * 0.2f, i * -0.05f, 0.0f);
        matrices.method_46416(cx, cy, cz);
        matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)j * i * 90.0f));
        matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(i * 10.0f));
        matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)j * i * 30.0f));
        matrices.method_46416(-cx, -cy, -cz);
    }

    @WrapOperation(method={"renderFirstPersonItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V")}, require=0)
    private void kimiko$swingAnimation(class_759 instance, float swingProgress, class_4587 matrices, int armX, class_1306 arm, Operation<Void> original, @Local(argsOnly=true) class_742 player, @Local(argsOnly=true) class_1268 hand) {
        if (player.method_6115() && player.method_6058() == hand) {
            original.call(new Object[]{instance, Float.valueOf(swingProgress), matrices, armX, arm});
            return;
        }
        if (this.kimiko$consumeCustomSwing(matrices, hand, swingProgress)) {
            return;
        }
        if (!SwingAnimation.applyAnimation(matrices, hand, swingProgress)) {
            original.call(new Object[]{instance, Float.valueOf(swingProgress), matrices, armX, arm});
        }
    }

    @Inject(method={"renderFirstPersonItem"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$clearSwingAnimation(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 stack, float equipProgress, class_4587 matrices, class_11659 nodeCollector, int light, CallbackInfo ci) {
        this.kimiko$clearCustomSwing();
        this.kimiko$outlineHand = null;
    }

    @Inject(method={"renderFirstPersonItem"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$captureOutlineHand(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 stack, float equipProgress, class_4587 matrices, class_11659 nodeCollector, int light, CallbackInfo ci) {
        this.kimiko$outlineHand = hand;
    }

    @Inject(method={"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$captureShaderHandsScene(float tickProgress, class_4587 matrices, class_11659 collector, class_746 player, int light, CallbackInfo ci) {
        ViewModel.beginHandFrame();
        if (ShaderHands.isCaptureModeActive() || ViewModel.wantsHandMask()) {
            ShaderHandsRenderer.captureScene(ShaderHands.wantsSceneBlur());
        }
    }

    @WrapOperation(method={"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/command/RenderDispatcher;render()V")}, require=0)
    private void kimiko$beginShaderHandsCapture(class_11684 instance, Operation<Void> original) {
        if ((ShaderHands.isCaptureModeActive() || ViewModel.wantsHandMask()) && ShaderHandsRenderer.beginHandCapture()) {
            try {
                original.call(new Object[]{instance});
            }
            catch (Throwable t) {
                ShaderHandsRenderer.endHandCapture();
                throw t;
            }
        } else {
            original.call(new Object[]{instance});
        }
    }

    @WrapOperation(method={"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;draw()V")}, require=0)
    private void kimiko$captureShaderHands(class_4597.class_4598 instance, Operation<Void> original) {
        original.call(new Object[]{instance});
        if (ShaderHandsRenderer.isCapturing()) {
            ShaderHandsRenderer.endHandCapture();
        }
    }

    @Inject(method={"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$drawItemOutline(float tickProgress, class_4587 matrices, class_11659 collector, class_746 player, int light, CallbackInfo ci) {
        if (ShaderHands.isCaptureModeActive()) {
            ShaderHands.composite();
        } else if (ViewModel.wantsHandMask()) {
            ShaderHandsRenderer.compositePlain();
        }
        if (ViewModel.wantsHandMask() || ShaderHands.isCaptureModeActive()) {
            ShaderHandsRenderer.updateHandMask();
        }
        ItemOutlineRenderer.run();
    }

    @WrapOperation(method={"renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/item/ItemRenderState;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;III)V")}, require=0)
    private void kimiko$stampOutline(class_10444 state, class_4587 pose, class_11659 collector, int light, int overlay, int outlineColor, Operation<Void> original) {
        class_746 player;
        int color = outlineColor;
        if (this.kimiko$outlineHand != null && ViewModel.outlineAlpha(this.kimiko$outlineHand) > 0.001f) {
            color = ItemOutlineRenderer.outlineColor();
        }
        if (this.kimiko$outlineHand != null && ViewModel.suppressEatAnimation()) {
            class_243 c = state.method_72173().method_1005();
            if (this.kimiko$outlineHand == class_1268.field_5808) {
                this.kimiko$mainCx = (float)c.field_1352;
                this.kimiko$mainCy = (float)c.field_1351;
                this.kimiko$mainCz = (float)c.field_1350;
                this.kimiko$mainCenterSet = true;
            } else {
                this.kimiko$offCx = (float)c.field_1352;
                this.kimiko$offCy = (float)c.field_1351;
                this.kimiko$offCz = (float)c.field_1350;
                this.kimiko$offCenterSet = true;
            }
        }
        if (ShaderHands.isNewModeActive() && this.kimiko$outlineHand != null && (player = class_310.method_1551().field_1724) != null) {
            HandsItemHitboxTracker.capture(ItemInHandRendererMixin.kimiko$handDisplayContext(player, this.kimiko$outlineHand), pose, state);
        }
        original.call(new Object[]{state, pose, collector, light, overlay, color});
    }

    @Unique
    private static class_811 kimiko$handDisplayContext(class_746 player, class_1268 hand) {
        boolean right = hand == class_1268.field_5808 == (player.method_6068() == class_1306.field_6183);
        return right ? class_811.field_4322 : class_811.field_4321;
    }

    @Unique
    private void kimiko$markCustomSwing(class_4587 matrices, class_1268 hand, float swingProgress) {
        this.kimiko$customSwingMatrices = matrices;
        this.kimiko$customSwingHand = hand;
        this.kimiko$customSwingProgress = swingProgress;
    }

    @Unique
    private boolean kimiko$consumeCustomSwing(class_4587 matrices, class_1268 hand, float swingProgress) {
        boolean matches;
        boolean bl = matches = this.kimiko$customSwingMatrices == matrices && this.kimiko$customSwingHand == hand && Float.compare(this.kimiko$customSwingProgress, swingProgress) == 0;
        if (matches) {
            this.kimiko$clearCustomSwing();
        }
        return matches;
    }

    @Unique
    private void kimiko$clearCustomSwing() {
        this.kimiko$customSwingMatrices = null;
        this.kimiko$customSwingHand = null;
        this.kimiko$customSwingProgress = 0.0f;
    }
}

