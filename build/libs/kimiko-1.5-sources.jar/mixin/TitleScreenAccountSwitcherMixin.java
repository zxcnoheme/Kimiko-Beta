/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.Drawable
 *  net.minecraft.client.gui.widget.ButtonWidget
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.TitleScreen
 *  net.minecraft.client.gui.Selectable
 *  net.minecraft.client.gui.widget.PressableTextWidget
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import java.util.ArrayList;
import java.util.List;
import mixin.ScreenAccessor;
import mods.acountswiher.ru.vidtu.ias.screen.AccountScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_6379;
import net.minecraft.class_7077;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_442.class})
public abstract class TitleScreenAccountSwitcherMixin
extends class_437 {
    protected TitleScreenAccountSwitcherMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"init"}, at={@At(value="TAIL")})
    private void kimiko$replaceRealmsWithAccountSwitcher(CallbackInfo ci) {
        class_442 screen = (class_442)(Object)this;
        ScreenAccessor access = (ScreenAccessor)((Object)this);
        List<class_4068> drawables = access.getRenderables();
        List<class_364> children = access.getChildren();
        List<class_6379> selectables = access.getNarratables();
        String realmsLabel = class_2561.method_43471((String)"menu.online").getString();
        class_4185 realmsButton = null;
        for (class_364 child : children) {
            class_4185 button;
            if (!(child instanceof class_4185) || !realmsLabel.equals((button = (class_4185)child).method_25369().getString())) continue;
            realmsButton = button;
            break;
        }
        int x = this.field_22789 / 2 - 100;
        int y = this.field_22790 / 4 + 96;
        int width = 200;
        int height = 20;
        if (realmsButton != null) {
            x = realmsButton.method_46426();
            y = realmsButton.method_46427();
            width = realmsButton.method_25368();
            height = realmsButton.method_25364();
            drawables.remove(realmsButton);
            children.remove(realmsButton);
            selectables.remove(realmsButton);
        }
        class_4185 switcher = class_4185.method_46430((class_2561)class_2561.method_43470((String)"Account Switcher"), elementCodec -> class_310.method_1551().method_1507((class_437)new AccountScreen((class_437)screen))).method_46434(x, y, width, height).method_46431();
        this.method_37063(switcher);
        for (class_364 child : new ArrayList<class_364>(children)) {
            if (!(child instanceof class_7077)) continue;
            class_7077 copyright = (class_7077)child;
            drawables.remove(copyright);
            children.remove(copyright);
            selectables.remove(copyright);
        }
    }

    @Redirect(method={"render"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)V"))
    private void kimiko$hideVersionText(class_332 graphics, class_327 font, String text, int x, int y, int color) {
    }
}

