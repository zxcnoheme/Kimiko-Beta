/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.client.render.entity.state.LivingEntityRenderState
 *  net.minecraft.client.render.entity.equipment.EquipmentRenderer
 *  net.minecraft.client.texture.Sprite
 *  net.minecraft.client.render.command.ModelCommandRenderer$CrumblingOverlayCommand
 *  net.minecraft.client.render.command.RenderCommandQueue
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.client.model.Model
 *  net.minecraft.client.util.math.MatrixStack
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_10042;
import net.minecraft.class_10197;
import net.minecraft.class_1058;
import net.minecraft.class_11683;
import net.minecraft.class_11785;
import net.minecraft.class_1921;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import rtx.kimiko.api.modules.impl.Visuals.HitColor;

@Mixin(value={class_10197.class})
public abstract class EquipmentLayerRendererMixin {
    @WrapOperation(method={"render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/util/Identifier;II)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/command/RenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V")}, require=0)
    private void kimiko$tintHitArmor(class_11785 collector, class_3879 model, Object state, class_4587 poseStack, class_1921 renderType, int light, int overlay, int color, class_1058 sprite, int outlineColor, class_11683.class_11792 crumblingOverlay, Operation<Void> original) {
        Integer n;
        if (state instanceof class_10042) {
            class_10042 livingState = (class_10042)state;
            n = HitColor.tintFor(livingState);
        } else {
            n = null;
        }
        Integer hitColor = n;
        original.call(new Object[]{collector, model, state, poseStack, renderType, light, overlay, hitColor != null ? hitColor : color, sprite, outlineColor, crumblingOverlay});
    }
}

