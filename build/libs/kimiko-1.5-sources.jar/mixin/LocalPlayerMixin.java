/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.PlayerInput
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_10185;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.game.CloseScreenEvent;
import rtx.kimiko.api.events.impl.player.PlayerMoveEvent;
import rtx.kimiko.api.events.impl.player.UsingItemEvent;

@Mixin(value={class_746.class})
public abstract class LocalPlayerMixin {
    @Inject(method={"closeHandledScreen"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$closeHandledScreenHook(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        class_437 screen = client == null ? null : client.field_1755;
        EventBus bus = EventBus.get();
        if (!bus.hasListeners(CloseScreenEvent.class)) {
            return;
        }
        CloseScreenEvent event = bus.post(new CloseScreenEvent(screen));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"tickMovement"}, at={@At(value="HEAD")})
    private void kimiko$onAiStep(CallbackInfo ci) {
        class_746 self = (class_746)(Object)this;
        if (self.field_3913 == null || self.field_3913.field_54155 == null) {
            return;
        }
        EventBus bus = EventBus.get();
        if (!bus.hasListeners(PlayerMoveEvent.class)) {
            return;
        }
        class_10185 current = self.field_3913.field_54155;
        PlayerMoveEvent event = bus.post(new PlayerMoveEvent(current.comp_3159(), current.comp_3160(), current.comp_3161(), current.comp_3162(), current.comp_3163(), current.comp_3165(), current.comp_3164()));
        if (event.isCancelled()) {
            self.field_3913.field_54155 = class_10185.field_54098;
        } else if (this.kimiko$inputChanged(current, event)) {
            self.field_3913.field_54155 = new class_10185(event.isForward(), event.isBackward(), event.isLeft(), event.isRight(), event.isJump(), event.isShift(), event.isSprint());
        }
    }

    @Inject(method={"tickMovement"}, at={@At(value="HEAD")})
    private void kimiko$onUsingItemPre(CallbackInfo ci) {
        class_746 self = (class_746)(Object)this;
        if (!self.method_6115()) {
            return;
        }
        EventBus bus = EventBus.get();
        if (bus.hasListeners(UsingItemEvent.class)) {
            bus.post(new UsingItemEvent(0));
        }
    }

    @Inject(method={"tickMovement"}, at={@At(value="RETURN")})
    private void kimiko$onUsingItemPost(CallbackInfo ci) {
        class_746 self = (class_746)(Object)this;
        if (!self.method_6115()) {
            return;
        }
        EventBus bus = EventBus.get();
        if (bus.hasListeners(UsingItemEvent.class)) {
            bus.post(new UsingItemEvent(1));
        }
    }

    @Unique
    private boolean kimiko$inputChanged(class_10185 current, PlayerMoveEvent event) {
        return current.comp_3159() != event.isForward() || current.comp_3160() != event.isBackward() || current.comp_3161() != event.isLeft() || current.comp_3162() != event.isRight() || current.comp_3163() != event.isJump() || current.comp_3165() != event.isSprint() || current.comp_3164() != event.isShift();
    }
}

