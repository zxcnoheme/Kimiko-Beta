/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.player.PlayerVelocityStrafeEvent;
import rtx.kimiko.api.modules.impl.Visuals.FakePlayer;
import rtx.kimiko.api.modules.impl.Visuals.custompet.entity.CustomPetEntity;

@Mixin(value={class_1297.class})
public abstract class EntityMixin {
    @Inject(method={"pushAwayFrom"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$cancelCustomPetPush(class_1297 other, CallbackInfo ci) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || (Object)this != player && other != player) {
            return;
        }
        if ((Object)this instanceof CustomPetEntity || other instanceof CustomPetEntity || FakePlayer.isFakePlayer((class_1297)(Object)this) || FakePlayer.isFakePlayer(other)) {
            ci.cancel();
        }
    }

    @Redirect(method={"updateVelocity"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/Entity;movementInputToVelocity(Lnet/minecraft/util/math/Vec3d;FF)Lnet/minecraft/util/math/Vec3d;"), require=0)
    private class_243 kimiko$fixMoveRelative(class_243 movementInput, float speed, float yaw) {
        if (this.kimiko$isLocalPlayer()) {
            PlayerVelocityStrafeEvent event = EventBus.get().post(new PlayerVelocityStrafeEvent(EntityMixin.kimiko$computeInputVector(movementInput, speed, yaw), movementInput, speed));
            return event.getVelocity();
        }
        return EntityMixin.kimiko$computeInputVector(movementInput, speed, yaw);
    }

    @Unique
    private boolean kimiko$isLocalPlayer() {
        class_746 player = class_310.method_1551().field_1724;
        return player != null && (Object)this == player;
    }

    @Unique
    private static class_243 kimiko$computeInputVector(class_243 input, float speed, float yaw) {
        double len = input.method_1027();
        if (len < 1.0E-7) {
            return class_243.field_1353;
        }
        class_243 scaled = (len > 1.0 ? input.method_1029() : input).method_1021((double)speed);
        float sin = class_3532.method_15374((double)(yaw * ((float)Math.PI / 180)));
        float cos = class_3532.method_15362((double)(yaw * ((float)Math.PI / 180)));
        return new class_243(scaled.field_1352 * (double)cos - scaled.field_1350 * (double)sin, scaled.field_1351, scaled.field_1350 * (double)cos + scaled.field_1352 * (double)sin);
    }
}

