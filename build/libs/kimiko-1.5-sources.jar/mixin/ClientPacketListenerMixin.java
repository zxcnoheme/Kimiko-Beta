/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Hand
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.world.World
 *  net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlaySoundFromEntityS2CPacket
 *  net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.sound.SoundEvent
 *  net.minecraft.client.network.ClientPlayNetworkHandler
 *  net.minecraft.component.DataComponentTypes
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2663;
import net.minecraft.class_2765;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_634;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.player.TotemPopEvent;
import rtx.kimiko.utils.entity.death.EntityDeathWatcher;
import rtx.kimiko.utils.entity.death.LocalDeathWatcher;

@Mixin(value={class_634.class})
public abstract class ClientPacketListenerMixin {
    @Inject(method={"onEntityStatus"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$onEntityEvent(class_2663 packet, CallbackInfo ci) {
        byte eventId = packet.method_11470();
        if (eventId != 35 && eventId != 3) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        class_1297 entity = packet.method_11469((class_1937)mc.field_1687);
        if (!(entity instanceof class_1309)) {
            return;
        }
        class_1309 living = (class_1309)entity;
        if (eventId == 3) {
            LocalDeathWatcher.notifyDeathAnimation((class_1297)living);
            return;
        }
        class_1799 totem = this.kimiko$findTotem(living);
        boolean enchanted = !totem.method_7960() && totem.method_7942();
        EventBus.get().post(new TotemPopEvent(living, enchanted));
    }

    @Inject(method={"onPlaySound"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$onServerSound(class_2767 packet, CallbackInfo ci) {
        EntityDeathWatcher.notifyServerSound(((class_3414)packet.method_11894().comp_349()).comp_3319(), packet.method_11890(), packet.method_11889(), packet.method_11893());
    }

    @Inject(method={"onPlaySoundFromEntity"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$onServerEntitySound(class_2765 packet, CallbackInfo ci) {
        EntityDeathWatcher.notifyServerEntitySound(((class_3414)packet.method_11882().comp_349()).comp_3319(), packet.method_11883());
    }

    @Unique
    private class_1799 kimiko$findTotem(class_1309 entity) {
        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = entity.method_5998(hand);
            if (!stack.method_57826(class_9334.field_54274) && !stack.method_31574(class_1802.field_8288)) continue;
            return stack;
        }
        return class_1799.field_8037;
    }
}

