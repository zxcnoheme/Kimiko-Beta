/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Item$TooltipContext
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.tooltip.TooltipType
 *  net.minecraft.text.Text
 *  net.minecraft.item.tooltip.TooltipData
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin.shulkerview;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import mods.shulkerview.ShulkerPreviewHelper;
import mods.shulkerview.tooltip.ShulkerPreviewTooltipComponent;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_5632;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1799.class})
public abstract class ItemStackMixin {
    @Inject(method={"getTooltipData"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$shulkerPreviewTooltipImage(CallbackInfoReturnable<Optional<class_5632>> cir) {
        class_1799 stack = (class_1799)(Object)this;
        if (ShulkerPreviewHelper.shouldShowPreview(stack)) {
            List<class_1799> items = ShulkerPreviewHelper.getItems(stack);
            cir.setReturnValue(Optional.of(new ShulkerPreviewTooltipComponent(stack.method_7972(), items, true)));
        }
    }

    @Inject(method={"getTooltip"}, at={@At(value="RETURN")}, cancellable=true)
    private void kimiko$shulkerPreviewTooltipLines(class_1792.class_9635 context, class_1657 player, class_1836 flag, CallbackInfoReturnable<List<class_2561>> cir) {
        class_1799 stack = (class_1799)(Object)this;
        ArrayList<class_2561> lines = new ArrayList<class_2561>((Collection)cir.getReturnValue());
        lines.addAll(ShulkerPreviewHelper.tooltipLines(stack));
        cir.setReturnValue(lines);
    }
}

