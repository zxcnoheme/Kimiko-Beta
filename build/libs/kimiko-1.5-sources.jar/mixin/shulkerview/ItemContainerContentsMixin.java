/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item$TooltipContext
 *  net.minecraft.item.tooltip.TooltipType
 *  net.minecraft.text.Text
 *  net.minecraft.component.type.ContainerComponent
 *  net.minecraft.component.ComponentsAccess
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin.shulkerview;

import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_9288;
import net.minecraft.class_9473;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Utils.ShulkerPreview;

@Mixin(value={class_9288.class})
public abstract class ItemContainerContentsMixin {
    @Inject(method={"appendTooltip"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$shulkerPreviewHideVanillaContainerTooltip(class_1792.class_9635 context, Consumer<class_2561> consumer, class_1836 flag, class_9473 components, CallbackInfo ci) {
        if (ShulkerPreview.enabled()) {
            ci.cancel();
        }
    }
}

