/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.LivingEntityRenderState
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.client.render.entity.PlayerEntityRenderer
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.text.StyleSpriteSource
 *  net.minecraft.text.StyleSpriteSource$Font
 *  net.minecraft.client.render.state.CameraRenderState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.text.Text
 *  net.minecraft.text.Style
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.render.entity.model.ModelWithHead
 *  net.minecraft.client.render.entity.feature.FeatureRenderer
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.render.entity.EntityRendererFactory$Context
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.model.ModelPart
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.entity.EntityAttachmentType
 *  net.minecraft.client.render.entity.LivingEntityRenderer
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11719;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3882;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_9064;
import net.minecraft.class_922;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.modules.impl.Utils.Globals;
import rtx.kimiko.api.modules.impl.Utils.StreamerMode;
import rtx.kimiko.api.modules.impl.Visuals.ChinaHat;
import rtx.kimiko.api.modules.impl.Visuals.HitColor;
import rtx.kimiko.api.modules.impl.Visuals.NameTags;
import rtx.kimiko.api.modules.impl.Visuals.SeeInvisible;
import rtx.kimiko.api.modules.impl.Visuals.SelfTag;
import rtx.kimiko.api.modules.impl.Visuals.customization.CustomizationLayer;
import rtx.kimiko.api.modules.impl.Visuals.seeinvisible.RevealTintHolder;
import rtx.kimiko.utils.net.ClientPresence;

@Mixin(value={class_922.class})
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
    @Shadow
    public abstract M getModel();

    @Shadow
    protected abstract void setupTransforms(S var1, class_4587 var2, float var3, float var4);

    @Shadow
    protected abstract void scale(S var1, class_4587 var2);

    @Shadow
    protected abstract boolean addFeature(class_3887<?, ?> var1);

    @Inject(method={"<init>"}, at={@At(value="RETURN")})
    private void kimiko$addCustomizationLayer(class_5617.class_5618 context, class_583<?> model, float shadowRadius, CallbackInfo ci) {
        if ((Object)this instanceof class_1007) {
            class_1007 renderer = (class_1007)(Object)this;
            this.addFeature(new CustomizationLayer(renderer));
        }
    }

    @Inject(method={"updateRenderState"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$extractState(T entity, S state, float partialTick, CallbackInfo ci) {
        boolean nameHidden;
        SeeInvisible module;
        if (state instanceof RevealTintHolder) {
            RevealTintHolder holder = (RevealTintHolder)state;
            holder.kimiko$setRevealTint(-1);
        }
        if (((class_10042)state).field_53333 && (module = SeeInvisible.getInstance()) != null && module.shouldReveal((class_1309)entity)) {
            ((class_10042)state).field_53461 = false;
            if (module.isSolid()) {
                ((class_10042)state).field_53333 = false;
            } else if (state instanceof RevealTintHolder) {
                RevealTintHolder holder = (RevealTintHolder)state;
                holder.kimiko$setRevealTint(module.ghostTint());
            }
        }
        if (nameHidden = NameTags.hidesNameTagFor(entity)) {
            ((class_10042)state).field_53337 = null;
        }
        if (!nameHidden && SelfTag.active()) {
            class_310 mc = class_310.method_1551();
            if (entity == mc.field_1724 && ((class_10042)state).field_53337 == null && !mc.field_1690.method_31044().method_31034()) {
                ((class_10042)state).field_53337 = entity.method_5476();
                ((class_10042)state).field_53338 = entity.method_56072().method_55675(class_9064.field_47745, 0, entity.method_36454());
            }
        }
        class_310 mcRef = class_310.method_1551();
        if (((class_10042)state).field_53337 != null && entity == mcRef.field_1724) {
            ((class_10042)state).field_53337 = StreamerMode.applySelfRank(((class_10042)state).field_53337);
        }
        if (((class_10042)state).field_53337 != null && entity instanceof class_1657) {
            class_1657 badgePlayer = (class_1657)entity;
            if (Globals.tagsBadge() && ClientPresence.INSTANCE.isKimikoUser(badgePlayer.method_7334().name())) {
                ((class_10042)state).field_53337 = class_2561.method_43473().method_10852((class_2561)class_2561.method_43470((String)"\ue000").method_10862(class_2583.field_24360.method_27704((class_11719)new class_11719.class_11721(class_2960.method_60655((String)"kimiko", (String)"badge"))).method_36139(9081843))).method_10852((class_2561)class_2561.method_43470((String)" ").method_10852(((class_10042)state).field_53337)).method_10852((class_2561)class_2561.method_43470((String)"  "));
            }
        }
        HitColor.captureTint(state, entity);
        if (HitColor.shouldTint(entity)) {
            ((class_10042)state).field_53460 = false;
        }
    }

    @Inject(method={"render"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$captureChinaHatTransform(S state, class_4587 poseStack, class_11659 collector, class_12075 camera, CallbackInfo ci) {
        if (!(state instanceof class_10055)) {
            return;
        }
        class_10055 avatarState = (class_10055)state;
        ChinaHat chinaHat = ChinaHat.getInstance();
        if (chinaHat == null || !chinaHat.isVisuallyActive()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        class_1297 entity = mc.field_1687.method_8469(avatarState.field_53528);
        if (!(entity instanceof class_742)) {
            return;
        }
        class_742 player = (class_742)entity;
        if (avatarState.field_53457 || ((class_10042)state).field_53333 || !chinaHat.shouldRender(player)) {
            return;
        }
        M model = this.getModel();
        if (!(model instanceof class_3882)) {
            return;
        }
        class_3882 headedModel = (class_3882)model;
        class_4587 local = new class_4587();
        local.method_22905(((class_10042)state).field_53453, ((class_10042)state).field_53453, ((class_10042)state).field_53453);
        this.setupTransforms(state, local, ((class_10042)state).field_53446, ((class_10042)state).field_53453);
        local.method_22905(-1.0f, -1.0f, 1.0f);
        this.scale(state, local);
        local.method_46416(0.0f, -1.501f, 0.0f);
        class_630 head = headedModel.method_2838();
        head.method_22703(local);
        local.method_22907((Quaternionfc)class_7833.field_40717.rotationDegrees(180.0f));
        local.method_22907((Quaternionfc)class_7833.field_40715.rotationDegrees(90.0f));
        chinaHat.captureTransform(player.method_5628(), new Matrix4f((Matrix4fc)local.method_23760().method_23761()));
    }

    @ModifyConstant(method={"render"}, constant={@Constant(intValue=0x26FFFFFF)}, require=0)
    private int kimiko$revealTint(int original, S state, class_4587 poseStack, class_11659 collector, class_12075 camera) {
        RevealTintHolder holder;
        int tint;
        if (state instanceof RevealTintHolder && (tint = (holder = (RevealTintHolder)state).kimiko$getRevealTint()) != -1) {
            return tint;
        }
        return original;
    }

    @Inject(method={"getMixColor"}, at={@At(value="RETURN")}, cancellable=true, require=0)
    private void kimiko$customHurtTint(S state, CallbackInfoReturnable<Integer> cir) {
        Integer tint = HitColor.tintFor(state);
        if (tint != null) {
            cir.setReturnValue(tint);
        }
    }
}

