/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.Box
 *  net.minecraft.particle.ParticleEffect
 *  net.minecraft.particle.ParticleTypes
 *  net.minecraft.client.particle.ParticleManager
 *  net.minecraft.client.particle.Particle
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.modules.impl.Utils.Optimization;
import rtx.kimiko.api.modules.impl.Visuals.NoRender;

@Mixin(value={class_702.class})
public abstract class ParticleEngineMixin {
    @Inject(method={"addParticle(Lnet/minecraft/client/particle/Particle;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$cullDistantParticles(class_703 particle, CallbackInfo ci) {
        if (ParticleEngineMixin.kimiko$noParticles()) {
            ci.cancel();
            return;
        }
        class_238 box = particle.method_3064();
        double x = (box.field_1323 + box.field_1320) * 0.5;
        double y = (box.field_1322 + box.field_1325) * 0.5;
        double z = (box.field_1321 + box.field_1324) * 0.5;
        if (!Optimization.allowParticle(x, y, z)) {
            ci.cancel();
        }
    }

    @Inject(method={"addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$noTotemEmitter(class_1297 entity, class_2394 options, CallbackInfo ci) {
        if (ParticleEngineMixin.kimiko$noParticles() || ParticleEngineMixin.kimiko$blockTotem(options)) {
            ci.cancel();
        }
    }

    @Inject(method={"addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$noTotemEmitterTimed(class_1297 entity, class_2394 options, int lifetime, CallbackInfo ci) {
        if (ParticleEngineMixin.kimiko$noParticles() || ParticleEngineMixin.kimiko$blockTotem(options)) {
            ci.cancel();
        }
    }

    @Inject(method={"addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$noTotemParticle(class_2394 options, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<class_703> cir) {
        if (ParticleEngineMixin.kimiko$noParticles() || ParticleEngineMixin.kimiko$blockTotem(options)) {
            cir.setReturnValue(null);
        }
    }

    @Inject(method={"addToBatch"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$noParticleExtract(CallbackInfo ci) {
        if (ParticleEngineMixin.kimiko$noParticles()) {
            ci.cancel();
        }
    }

    private static boolean kimiko$noParticles() {
        return NoRender.isActive("Частицы");
    }

    private static boolean kimiko$blockTotem(class_2394 options) {
        return options != null && options.method_10295() == class_2398.field_11220 && NoRender.isActive("Тотем");
    }
}

