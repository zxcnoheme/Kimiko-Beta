/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  net.minecraft.util.PlayerInput
 *  net.minecraft.client.util.Window
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.util.InputUtil
 *  net.minecraft.client.util.InputUtil$Key
 *  net.minecraft.client.util.InputUtil$Type
 *  net.minecraft.client.input.KeyboardInput
 *  org.lwjgl.glfw.GLFW
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 */
package mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_10185;
import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_743;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.input.InputEvent;
import rtx.kimiko.api.modules.impl.Visuals.emotions.EmotionWheelScreen;
import rtx.kimiko.api.ui.UI;
import rtx.kimiko.api.ui.crosshair.CrosshairEditorScreen;

@Mixin(value={class_743.class})
public abstract class KeyboardInputMixin {
    @ModifyExpressionValue(method={"tick"}, at={@At(value="NEW", target="(ZZZZZZZ)Lnet/minecraft/util/PlayerInput;")}, require=0)
    private class_10185 kimiko$tickHook(class_10185 original) {
        EventBus bus;
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.field_1755 != null) {
            original = UI.isOpen() && !UI.isSearchTyping() || mc.field_1755 instanceof CrosshairEditorScreen || mc.field_1755 instanceof EmotionWheelScreen ? this.kimiko$readRawMovement() : new class_10185(false, false, false, false, false, false, false);
        }
        if (!(bus = EventBus.get()).hasListeners(InputEvent.class)) {
            return original;
        }
        InputEvent event = bus.post(new InputEvent(original));
        return event.getInput();
    }

    @Unique
    private class_10185 kimiko$readRawMovement() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_22683() == null) {
            return new class_10185(false, false, false, false, false, false, false);
        }
        return new class_10185(this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1894), this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1881), this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1913), this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1849), this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1903), this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1832), this.kimiko$isRawKeyDown(mc, mc.field_1690.field_1867));
    }

    @Unique
    private boolean kimiko$isRawKeyDown(class_310 mc, class_304 mapping) {
        class_3675.class_306 key = class_3675.method_15981((String)mapping.method_1428());
        return switch (key.method_1442()) {
            case class_3675.class_307.field_1668 -> class_3675.method_15987((class_1041)mc.method_22683(), (int)key.method_1444());
            case class_3675.class_307.field_1672 -> {
                if (GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)key.method_1444()) == 1) {
                    yield true;
                }
                yield false;
            }
            default -> false;
        };
    }
}

