/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.command.OrderedRenderCommandQueueImpl
 *  net.minecraft.client.render.SubmittableBatch
 *  net.minecraft.client.render.state.CameraRenderState
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_11661;
import net.minecraft.class_11943;
import net.minecraft.class_12075;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.utils.render.modules.post.glowesp.GlowEspHook;

@Mixin(value={class_11943.class})
public class ParticlesRenderStateMixin {
    @Inject(method={"submit"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$glowBeforeParticles(class_11661 submitNodeStorage, class_12075 cameraRenderState, CallbackInfo ci) {
        try {
            GlowEspHook.renderBeforeParticles();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

