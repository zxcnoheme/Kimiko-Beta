/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.screen.ScreenHandler
 *  net.minecraft.screen.PlayerScreenHandler
 *  net.minecraft.text.Text
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.widget.PressableWidget
 *  net.minecraft.client.gui.screen.ingame.HandledScreen
 *  net.minecraft.client.gui.screen.ingame.InventoryScreen
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4264;
import net.minecraft.class_465;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.invmanager.InventoryManagerButtons;

@Mixin(value={class_490.class})
public abstract class InventoryManagerButtonMixin
extends class_465<class_1723> {
    @Unique
    private class_4264 kimiko$setsButton;
    @Unique
    private class_4264 kimiko$arrangeButton;

    protected InventoryManagerButtonMixin(class_1723 menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Inject(method={"init"}, at={@At(value="TAIL")})
    private void kimiko$addManagerButtons(CallbackInfo ci) {
        if (this.kimiko$setsButton != null) {
            this.method_37066((class_364)this.kimiko$setsButton);
        }
        if (this.kimiko$arrangeButton != null) {
            this.method_37066((class_364)this.kimiko$arrangeButton);
        }
        int bw = 90;
        int bx = this.field_2776 - bw - 4;
        this.kimiko$setsButton = (class_4264)this.method_37063(InventoryManagerButtons.createSetsButton(bx, this.field_2800, bw, 20));
        this.kimiko$arrangeButton = (class_4264)this.method_37063(InventoryManagerButtons.createArrangeButton(bx, this.field_2800 + 23, bw, 20));
    }

    @Inject(method={"render"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$tickArranger(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        InventoryManagerButtons.tickArranger(this);
    }
}

