/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.client.gui.hud.ChatHud
 *  net.minecraft.client.gui.widget.TextFieldWidget
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.ChatInputSuggestor
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_2561;
import net.minecraft.class_338;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.chat.commands.CommandManager;
import rtx.kimiko.api.chat.commands.suggestion.ClientCommandSuggestions;
import rtx.kimiko.utils.chat.ChatHistory;

@Mixin(value={class_408.class})
public abstract class ChatScreenMixin
extends class_437 {
    @Shadow
    protected class_342 chatField;
    @Shadow
    class_4717 chatInputSuggestor;
    @Unique
    private static boolean kimiko$historySeeded;

    @Shadow
    public abstract String normalize(String var1);

    protected ChatScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"init"}, at={@At(value="TAIL")})
    private void kimiko$replaceSuggestions(CallbackInfo ci) {
        CommandManager.get().refreshRuntimeState();
        this.chatInputSuggestor = new ClientCommandSuggestions(this.field_22787, this, this.chatField, this.field_22787.field_1772, false, false, 1, 10, true, -805306368);
        this.chatInputSuggestor.method_53869(false);
        this.chatInputSuggestor.method_23934();
        this.kimiko$seedHistory();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Unique
    private void kimiko$seedHistory() {
        if (kimiko$historySeeded) {
            return;
        }
        kimiko$historySeeded = true;
        if (this.field_22787 == null || this.field_22787.field_1705 == null) {
            return;
        }
        ChatHistory.seeding = true;
        try {
            class_338 chat = this.field_22787.field_1705.method_1743();
            for (String line : ChatHistory.entries()) {
                chat.method_1803(line);
            }
        }
        finally {
            ChatHistory.seeding = false;
        }
    }

    @Inject(method={"sendMessage"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$handleClientCommand(String message, boolean addToHistory, CallbackInfo ci) {
        CommandManager.get().refreshRuntimeState();
        String normalized = this.normalize(message);
        if (!CommandManager.get().isClientCommand(normalized)) {
            return;
        }
        if (addToHistory) {
            this.field_22787.field_1705.method_1743().method_1803(normalized);
        }
        String prefix = CommandManager.get().getPrefix();
        CommandManager.get().executeRaw(normalized.substring(prefix.length()));
        ci.cancel();
    }
}

