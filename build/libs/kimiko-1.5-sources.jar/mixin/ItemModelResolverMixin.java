/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.item.ItemModelManager
 *  net.minecraft.client.render.item.ItemRenderState
 *  net.minecraft.util.HeldItemContext
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.Items
 *  net.minecraft.world.World
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.item.ItemDisplayContext
 *  net.minecraft.component.type.CustomModelDataComponent
 *  net.minecraft.component.DataComponentTypes
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 */
package mixin;

import java.util.List;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_811;
import net.minecraft.class_9280;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import rtx.kimiko.api.modules.impl.Visuals.CustomSwords;

@Mixin(value={class_10442.class})
public abstract class ItemModelResolverMixin {
    @ModifyArg(method={"clearAndUpdate"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/item/ItemModelManager;update(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/world/World;Lnet/minecraft/util/HeldItemContext;I)V"), index=1)
    private class_1799 kimiko$replaceSwordModel(class_10444 renderState, class_1799 stack, class_811 displayContext, class_1937 level, class_11566 itemOwner, int seed) {
        CustomSwords module = CustomSwords.getInstance();
        String previewWeapon = CustomSwords.preview();
        if (previewWeapon != null) {
            if (!ItemModelResolverMixin.kimiko$isSword(stack)) {
                return stack;
            }
            return CustomSwords.previewStack(stack, previewWeapon);
        }
        if (module == null || !module.isEnabled() || !ItemModelResolverMixin.kimiko$isSword(stack)) {
            return stack;
        }
        if (module.isSelfOnly()) {
            class_310 minecraft = class_310.method_1551();
            if (minecraft.field_1724 == null || itemOwner != minecraft.field_1724) {
                return stack;
            }
        }
        class_1799 renderedStack = stack.method_7972();
        renderedStack.method_57379(class_9334.field_49637, new class_9280(List.of(), List.of(), List.of(module.getSelectedWeapon()), List.of()));
        return renderedStack;
    }

    private static boolean kimiko$isSword(class_1799 stack) {
        return stack.method_31574(class_1802.field_8091) || stack.method_31574(class_1802.field_8528) || stack.method_31574(class_1802.field_61338) || stack.method_31574(class_1802.field_8371) || stack.method_31574(class_1802.field_8845) || stack.method_31574(class_1802.field_8802) || stack.method_31574(class_1802.field_22022);
    }
}

