/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.BipedEntityRenderState
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.client.render.entity.model.BipedEntityModel
 *  net.minecraft.client.model.ModelPart
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_10034;
import net.minecraft.class_3532;
import net.minecraft.class_572;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Utils.guishare.GuiHoldPoseState;

@Mixin(value={class_572.class})
public abstract class HumanoidModelMixin {
    @Shadow
    @Final
    public class_630 rightArm;
    @Shadow
    @Final
    public class_630 leftArm;

    @Inject(method={"setAngles"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$applyGuiHoldPose(class_10034 state, CallbackInfo ci) {
        if (!(state instanceof GuiHoldPoseState)) {
            return;
        }
        GuiHoldPoseState holder = (GuiHoldPoseState)state;
        float[] pose = holder.kimiko$getGuiHoldPose();
        if (pose == null || pose.length < 5) {
            return;
        }
        float weight = pose[0];
        if (weight <= 0.0f) {
            return;
        }
        this.rightArm.field_3654 = class_3532.method_16439((float)weight, (float)this.rightArm.field_3654, (float)pose[1]);
        this.rightArm.field_3675 = class_3532.method_16439((float)weight, (float)this.rightArm.field_3675, (float)pose[2]);
        this.rightArm.field_3674 = class_3532.method_16439((float)weight, (float)this.rightArm.field_3674, (float)0.06f);
        this.leftArm.field_3654 = class_3532.method_16439((float)weight, (float)this.leftArm.field_3654, (float)pose[3]);
        this.leftArm.field_3675 = class_3532.method_16439((float)weight, (float)this.leftArm.field_3675, (float)pose[4]);
        this.leftArm.field_3674 = class_3532.method_16439((float)weight, (float)this.leftArm.field_3674, (float)-0.06f);
    }
}

