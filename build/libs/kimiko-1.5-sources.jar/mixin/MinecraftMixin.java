/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.util.crash.CrashReport
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.option.GameOptions
 *  net.minecraft.client.session.Session
 *  net.minecraft.sound.SoundCategory
 *  net.minecraft.client.gui.screen.DeathScreen
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.network.ClientPlayerEntity
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Mutable
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Coerce
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import mods.acountswiher.IasService;
import net.minecraft.class_128;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_320;
import net.minecraft.class_3419;
import net.minecraft.class_418;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.game.TickEvent;
import rtx.kimiko.api.events.impl.player.AttackEntityEvent;
import rtx.kimiko.api.modules.impl.Utils.Optimization;
import rtx.kimiko.api.modules.impl.Visuals.WastedDeath;
import rtx.kimiko.api.modules.impl.Visuals.custompet.entity.CustomPetEntity;
import rtx.kimiko.api.ui.window.WindowTitleAnimation;
import rtx.kimiko.utils.crash.CrashReporter;
import rtx.kimiko.utils.network.Network;
import rtx.kimiko.utils.session.SessionChanger;

@Mixin(value={class_310.class})
public abstract class MinecraftMixin {
    private static final String KIMIKO_DEFAULTS_MARKER = ".kimiko-defaults-applied";
    @Shadow
    @Final
    public class_315 options;
    @Shadow
    @Final
    public File runDirectory;
    @Shadow
    @Mutable
    private class_320 session;

    private void kimiko$setSession(class_320 newSession) {
        this.session = newSession;
    }

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    private void kimiko$initIas(CallbackInfo ci) {
        SessionChanger.setSessionSetter(this::kimiko$setSession);
        IasService.ensureInitialized();
    }

    @Inject(method={"stop"}, at={@At(value="HEAD")})
    private void kimiko$closeIas(CallbackInfo ci) {
        IasService.close();
    }

    @Inject(method={"onInitFinished"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$skipOnboarding(@Coerce Object cookie, CallbackInfoReturnable<Runnable> cir) {
        File marker = new File(this.runDirectory, KIMIKO_DEFAULTS_MARKER);
        if (!marker.exists()) {
            this.options.method_45578(class_3419.field_15253).method_41748(0.0);
            this.options.method_45578(class_3419.field_15252).method_41748(0.0);
            this.options.method_42474().method_41748(2);
            if (this.options.field_41785) {
                this.options.method_61127();
            } else {
                this.options.method_1640();
            }
            try {
                marker.createNewFile();
            }
            catch (IOException iOException) {
                // empty catch block
            }
            return;
        }
        if (this.options.field_41785) {
            this.options.method_61127();
        }
    }

    @Inject(method={"isMultiplayerEnabled"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$enableMultiplayer(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    private void kimiko$preTickEvent(CallbackInfo ci) {
        Network.tick();
        WindowTitleAnimation.get().tick();
        EventBus.get().post(TickEvent.PRE);
    }

    @Inject(method={"tick"}, at={@At(value="RETURN")})
    private void kimiko$postTickEvent(CallbackInfo ci) {
        EventBus.get().post(TickEvent.POST);
    }

    @Inject(method={"doAttack"}, at={@At(value="HEAD")})
    private void kimiko$clientAttackFallback(CallbackInfoReturnable<Boolean> cir) {
        try {
            class_310 mc = (class_310)(Object)this;
            class_746 player = mc.field_1724;
            if (player == null || mc.field_1687 == null) {
                return;
            }
            if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
                return;
            }
            double reach = player.method_55755();
            if (reach <= 0.0) {
                return;
            }
            class_243 eye = player.method_5836(1.0f);
            class_243 look = player.method_5828(1.0f);
            class_243 end = eye.method_1031(look.field_1352 * reach, look.field_1351 * reach, look.field_1350 * reach);
            class_1297 best = null;
            double bestDist = Double.MAX_VALUE;
            for (class_1297 entity : mc.field_1687.method_8333((class_1297)player, player.method_5829().method_1012(look.field_1352 * reach, look.field_1351 * reach, look.field_1350 * reach).method_1014(1.0), e -> e != null && e != player && !e.method_7325() && !(e instanceof CustomPetEntity))) {
                double d;
                Optional clip = entity.method_5829().method_1014(0.1).method_992(eye, end);
                if (!clip.isPresent() || !((d = eye.method_1025((class_243)clip.get())) < bestDist)) continue;
                bestDist = d;
                best = entity;
            }
            if (best != null) {
                EventBus.get().post(new AttackEntityEvent(best, true));
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Inject(method="printCrashReport(Lnet/minecraft/client/MinecraftClient;Ljava/io/File;Lnet/minecraft/util/crash/CrashReport;)V", at=@At(value="HEAD"))
    private static void kimiko$onCrash(class_310 minecraft, File file, class_128 report, CallbackInfo ci) {
        try {
            CrashReporter.report(report.method_561(), report.method_564());
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$interceptDeathScreen(class_437 screen, CallbackInfo ci) {
        if (!(screen instanceof class_418)) {
            return;
        }
        if (WastedDeath.interceptDeathScreen(screen) || WastedDeath.blocksDeathScreen()) {
            ci.cancel();
        }
    }

    @ModifyExpressionValue(method={"setScreen"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isDead()Z")}, require=0)
    private boolean kimiko$skipDeathScreenFallback(boolean original) {
        return original && !WastedDeath.blocksDeathScreen();
    }

    @ModifyReturnValue(method={"usesImprovedTransparency"}, at={@At(value="RETURN")}, require=0)
    private static boolean kimiko$forceFastTransparency(boolean original) {
        return Optimization.shaderTransparency(original);
    }
}

