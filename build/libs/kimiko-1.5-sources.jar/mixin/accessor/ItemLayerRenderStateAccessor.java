/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.item.ItemRenderState$Glint
 *  net.minecraft.client.render.item.ItemRenderState$LayerRenderState
 *  net.minecraft.client.render.item.model.special.SpecialModelRenderer
 *  net.minecraft.client.render.model.json.Transformation
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package mixin.accessor;

import net.minecraft.class_10444;
import net.minecraft.class_10515;
import net.minecraft.class_804;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_10444.class_10446.class})
public interface ItemLayerRenderStateAccessor {
    @Accessor(value="glint")
    public class_10444.class_10445 kimiko$getFoilType();

    @Accessor(value="transform")
    public class_804 kimiko$getItemTransform();

    @Accessor(value="useLight")
    public boolean kimiko$getUsesBlockLight();

    @Accessor(value="specialModelType")
    public class_10515<Object> kimiko$getSpecialRenderer();

    @Accessor(value="tints")
    public int[] kimiko$getTintLayers();
}

