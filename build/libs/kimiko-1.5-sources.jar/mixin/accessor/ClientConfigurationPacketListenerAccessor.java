/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.hud.ChatHud$ChatState
 *  net.minecraft.registry.DynamicRegistryManager$Immutable
 *  net.minecraft.resource.featuretoggle.FeatureSet
 *  net.minecraft.client.network.ClientConfigurationNetworkHandler
 *  net.minecraft.client.network.ClientRegistries
 *  net.minecraft.client.resource.ClientDataPackManager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package mixin.accessor;

import net.minecraft.class_338;
import net.minecraft.class_5455;
import net.minecraft.class_7699;
import net.minecraft.class_8674;
import net.minecraft.class_9173;
import net.minecraft.class_9247;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_8674.class})
public interface ClientConfigurationPacketListenerAccessor {
    @Accessor(value="clientRegistries")
    public class_9173 kimiko$getRegistryDataCollector();

    @Accessor(value="registryManager")
    public class_5455.class_6890 kimiko$getReceivedRegistries();

    @Accessor(value="enabledFeatures")
    public class_7699 kimiko$getEnabledFeatures();

    @Accessor(value="dataPackManager")
    public class_9247 kimiko$getKnownPacks();

    @Accessor(value="chatState")
    public class_338.class_9477 kimiko$getChatState();
}

