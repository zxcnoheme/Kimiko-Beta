/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.World
 *  net.minecraft.registry.RegistryKey
 *  net.minecraft.client.network.ClientPlayNetworkHandler
 *  net.minecraft.client.world.ClientWorld
 *  net.minecraft.client.world.ClientWorld$Properties
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package mixin.accessor;

import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_634.class})
public interface ClientPacketListenerAccessor {
    @Accessor(value="world")
    public void kimiko$setLevel(class_638 var1);

    @Accessor(value="worldProperties")
    public void kimiko$setLevelData(class_638.class_5271 var1);

    @Accessor(value="worldProperties")
    public class_638.class_5271 kimiko$getLevelData();

    @Accessor(value="chunkLoadDistance")
    public void kimiko$setServerChunkRadius(int var1);

    @Accessor(value="chunkLoadDistance")
    public int kimiko$getServerChunkRadius();

    @Accessor(value="simulationDistance")
    public void kimiko$setServerSimulationDistance(int var1);

    @Accessor(value="simulationDistance")
    public int kimiko$getServerSimulationDistance();

    @Accessor(value="worldKeys")
    public void kimiko$setLevels(Set<class_5321<class_1937>> var1);
}

