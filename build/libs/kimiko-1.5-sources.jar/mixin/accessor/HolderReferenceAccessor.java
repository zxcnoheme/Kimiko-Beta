/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.registry.entry.RegistryEntry$Reference
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Invoker
 */
package mixin.accessor;

import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_6880.class_6883.class})
public interface HolderReferenceAccessor<T> {
    @Invoker(value="setValue")
    public void kimiko$bindValue(T var1);
}

