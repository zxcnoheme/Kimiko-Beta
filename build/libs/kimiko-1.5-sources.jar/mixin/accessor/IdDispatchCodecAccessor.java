/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.handler.PacketCodecDispatcher
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package mixin.accessor;

import java.util.List;
import net.minecraft.class_9136;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_9136.class})
public interface IdDispatchCodecAccessor {
    @Accessor(value="packetTypes")
    public List<?> kimiko$getById();
}

