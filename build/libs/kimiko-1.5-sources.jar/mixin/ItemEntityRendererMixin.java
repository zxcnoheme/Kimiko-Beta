/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.ItemEntityRenderState
 *  net.minecraft.client.render.entity.state.ItemStackEntityRenderState
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.state.CameraRenderState
 *  net.minecraft.entity.ItemEntity
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.random.Random
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.client.render.entity.ItemEntityRenderer
 *  org.joml.Quaternionfc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import java.util.HashMap;
import java.util.WeakHashMap;
import net.minecraft.class_10039;
import net.minecraft.class_10428;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.ItemPhysics;

@Mixin(value={class_916.class})
public abstract class ItemEntityRendererMixin {
    @Unique
    private static final WeakHashMap<class_10039, Boolean> kimiko$groundStateMap = new WeakHashMap();
    @Unique
    private static final HashMap<Integer, Integer> kimiko$groundHoldMap = new HashMap();
    @Unique
    private class_10039 kimiko$currentState;

    @Inject(method={"updateRenderState"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$captureGroundState(class_1542 entity, class_10039 state, float tickDelta, CallbackInfo ci) {
        kimiko$groundStateMap.put(state, ItemEntityRendererMixin.kimiko$resolveGroundState(entity, entity.method_24828()));
    }

    @Redirect(method={"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V", ordinal=0), require=0)
    private void kimiko$translate(class_4587 matrices, float x, float y, float z, class_10039 state, class_4587 matricesArg, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        this.kimiko$currentState = state;
        boolean enabled = ItemEntityRendererMixin.kimiko$isItemPhysicsEnabled();
        boolean stableGround = kimiko$groundStateMap.getOrDefault(state, false);
        if ((enabled || stableGround) && state.field_55310 != null) {
            class_238 box = state.field_55310.method_72173();
            matrices.method_46416(x, -((float)box.field_1322) + 0.0625f, z);
        } else {
            matrices.method_46416(x, y, z);
        }
    }

    @Redirect(method={"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/render/entity/ItemEntityRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/ItemStackEntityRenderState;Lnet/minecraft/util/math/random/Random;Lnet/minecraft/util/math/Box;)V"), require=0)
    private void kimiko$renderPhysics(class_4587 matrices, class_11659 submitNodeCollector, int light, class_10428 stackState, class_5819 random, class_238 box) {
        if (ItemEntityRendererMixin.kimiko$isItemPhysicsEnabled() && this.kimiko$currentState != null) {
            boolean scaled;
            float age = this.kimiko$currentState.field_53328;
            float offset = this.kimiko$currentState.field_53435;
            boolean onGround = kimiko$groundStateMap.getOrDefault(this.kimiko$currentState, false);
            float scale = ItemEntityRendererMixin.kimiko$groundItemScale();
            boolean bl = scaled = Math.abs(scale - 1.0f) > 0.001f;
            if (scaled) {
                matrices.method_46416(0.0f, 0.0625f, 0.0f);
                matrices.method_22905(scale, scale, scale);
                matrices.method_46416(0.0f, -0.0625f, 0.0f);
            }
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotation(-class_1542.method_27314((float)age, (float)offset)));
            if (onGround) {
                matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(90.0f));
                matrices.method_46416(0.0f, -((float)box.method_17940() / 2.0f) + 0.0625f, 0.0f);
            } else {
                matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees((age * 15.0f + offset * 360.0f) % 360.0f));
            }
        }
        class_916.method_72986((class_4587)matrices, (class_11659)submitNodeCollector, (int)light, (class_10428)stackState, (class_5819)random, (class_238)box);
    }

    @Unique
    private static boolean kimiko$isItemPhysicsEnabled() {
        ItemPhysics itemPhysics = ItemPhysics.getInstance();
        return itemPhysics != null && itemPhysics.isEnabled() && itemPhysics.isNormalMode();
    }

    @Unique
    private static float kimiko$groundItemScale() {
        ItemPhysics itemPhysics = ItemPhysics.getInstance();
        return itemPhysics != null ? itemPhysics.groundItemScale() : 1.0f;
    }

    @Unique
    private static boolean kimiko$resolveGroundState(class_1542 entity, boolean onGround) {
        boolean lowMotion;
        int entityId = entity.method_5628();
        if (onGround) {
            kimiko$groundHoldMap.put(entityId, 8);
            ItemEntityRendererMixin.kimiko$trimGroundMap();
            return true;
        }
        Integer holdTicks = kimiko$groundHoldMap.get(entityId);
        if (holdTicks == null || holdTicks <= 0) {
            return false;
        }
        class_243 velocity = entity.method_18798();
        boolean bl = lowMotion = Math.abs(velocity.field_1352) <= 0.08 && Math.abs(velocity.field_1351) <= 0.08 && Math.abs(velocity.field_1350) <= 0.08;
        if (!lowMotion) {
            kimiko$groundHoldMap.remove(entityId);
            return false;
        }
        if (holdTicks == 1) {
            kimiko$groundHoldMap.remove(entityId);
        } else {
            kimiko$groundHoldMap.put(entityId, holdTicks - 1);
        }
        return true;
    }

    @Unique
    private static void kimiko$trimGroundMap() {
        if (kimiko$groundHoldMap.size() > 4096) {
            kimiko$groundHoldMap.clear();
        }
    }
}

