/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.biome.Biome
 *  net.minecraft.world.biome.Biome$Precipitation
 *  net.minecraft.util.math.BlockPos
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import net.minecraft.class_1959;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.modules.impl.Visuals.Ambience;

@Mixin(value={class_1959.class})
public abstract class BiomeWeatherMixin {
    @Inject(method={"hasPrecipitation"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$hasAmbiencePrecipitation(CallbackInfoReturnable<Boolean> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation != null) {
            cir.setReturnValue(precipitation != class_1959.class_1963.field_9384);
        }
    }

    @Inject(method={"getPrecipitation"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$getAmbiencePrecipitationAt(class_2338 pos, int seaLevel, CallbackInfoReturnable<class_1959.class_1963> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation != null) {
            cir.setReturnValue(precipitation);
        }
    }

    @Inject(method={"isCold"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$coldEnoughForAmbienceSnow(class_2338 pos, int seaLevel, CallbackInfoReturnable<Boolean> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation == class_1959.class_1963.field_9383) {
            cir.setReturnValue(true);
        } else if (precipitation == class_1959.class_1963.field_9382 || precipitation == class_1959.class_1963.field_9384) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"doesNotSnow"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$warmEnoughForAmbienceRain(class_2338 pos, int seaLevel, CallbackInfoReturnable<Boolean> cir) {
        Ambience ambience = Ambience.getInstance();
        class_1959.class_1963 precipitation = ambience != null ? ambience.getForcedPrecipitation() : null;
        if (precipitation == class_1959.class_1963.field_9383) {
            cir.setReturnValue(false);
        } else if (precipitation == class_1959.class_1963.field_9382) {
            cir.setReturnValue(true);
        }
    }
}

