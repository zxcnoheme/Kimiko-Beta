/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.gui.widget.EntryListWidget$Entry
 *  net.minecraft.client.gui.Element
 *  net.minecraft.client.gui.widget.ButtonWidget
 *  net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget
 *  net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget$ServerEntry
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen
 *  net.minecraft.client.network.ServerInfo
 *  net.minecraft.client.network.ServerInfo$ServerType
 *  net.minecraft.client.gui.tooltip.Tooltip
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.utils.network.PinnedServers;

@Mixin(value={class_500.class})
public abstract class JoinMultiplayerScreenMixin
extends class_437 {
    @Shadow
    protected class_4267 serverListWidget;
    @Shadow
    private class_4185 buttonEdit;
    @Shadow
    private class_4185 buttonDelete;

    protected JoinMultiplayerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"updateButtonActivationStates"}, at={@At(value="TAIL")})
    private void kimiko$protectPinnedServerControls(CallbackInfo ci) {
        class_4267.class_504 entry2 = this.serverListWidget.method_25334();
        if (entry2 instanceof class_4267.class_4270) {
            class_4267.class_4270 entry = (class_4267.class_4270)entry2;
            if (PinnedServers.isPinned(entry.method_20133().field_3761)) {
                this.buttonEdit.field_22763 = false;
                this.buttonDelete.field_22763 = false;
            }
        }
    }
}

