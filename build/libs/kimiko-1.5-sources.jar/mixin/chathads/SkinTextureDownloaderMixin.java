/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.minecraft.client.texture.NativeImage
 *  net.minecraft.client.texture.NativeImageBackedTexture
 *  net.minecraft.client.texture.AbstractTexture
 *  net.minecraft.client.texture.PlayerSkinTextureDownloader
 *  net.minecraft.util.AssetInfo$TextureAsset
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 */
package mixin.chathads;

import com.llamalad7.mixinextras.sugar.Local;
import java.util.function.Supplier;
import mods.chathads.ChatHeads;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_10538;
import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={class_10538.class})
public abstract class SkinTextureDownloaderMixin {
    @ModifyArg(method={"registerTexture"}, at=@At(value="INVOKE", target="Ljava/util/concurrent/CompletableFuture;supplyAsync(Ljava/util/function/Supplier;Ljava/util/concurrent/Executor;)Ljava/util/concurrent/CompletableFuture;"))
    private static Supplier<?> chatheads$registerBlendedHeadTexture(Supplier<?> supplier, @Local(argsOnly=true) class_12079.class_12081 texture, @Local(argsOnly=true) class_1011 image) {
        return () -> {
            class_2960 textureLocation = texture.comp_3627();
            if (textureLocation.method_12832().startsWith("skins/")) {
                class_310.method_1551().method_1531().method_4616(ChatHeads.getBlendedHeadLocation(textureLocation), (class_1044)new class_1043(() -> "Chat Head of " + textureLocation.method_12832(), ChatHeads.extractBlendedHead(image)));
                ChatHeads.blendedHeadTextures.add(textureLocation);
            }
            return supplier.get();
        };
    }
}

