/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.network.message.SignedMessage
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package mixin.chathads;

import mods.chathads.mixininterface.Ownable;
import net.minecraft.class_640;
import net.minecraft.class_7471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={class_7471.class})
public abstract class PlayerChatMessageMixin
implements Ownable {
    @Unique
    private class_640 chatheads$owner;

    @Override
    public void chatheads$setOwner(class_640 playerInfo) {
        this.chatheads$owner = playerInfo;
    }

    @Override
    public class_640 chatheads$getOwner() {
        return this.chatheads$owner;
    }
}

