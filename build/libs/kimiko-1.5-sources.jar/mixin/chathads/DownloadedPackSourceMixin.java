/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.resource.server.ServerResourcePackLoader
 *  net.minecraft.resource.ResourcePack
 *  net.minecraft.resource.ResourceType
 *  net.minecraft.resource.ResourcePackProfile
 *  net.minecraft.client.resource.server.ReloadScheduler$PackInfo
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin.chathads;

import java.util.List;
import mods.chathads.ChatHeads;
import net.minecraft.class_1066;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3288;
import net.minecraft.class_9041;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1066.class})
public abstract class DownloadedPackSourceMixin {
    @Inject(method={"toProfiles"}, at={@At(value="RETURN")})
    public void chatheads$checkForDisableResource(List<class_9041.class_9043> list, CallbackInfoReturnable<List<class_3288>> cir) {
        List<class_3288> packs = cir.getReturnValue();
        if (packs == null) {
            return;
        }
        for (class_3288 serverPack : packs) {
            try (class_3262 resources = serverPack.method_14458()) {
                if (resources != null && resources.method_14405(class_3264.field_14188, ChatHeads.DISABLE_RESOURCE) != null) {
                    ChatHeads.serverDisabledChatHeads = true;
                }
            }
        }
    }
}

