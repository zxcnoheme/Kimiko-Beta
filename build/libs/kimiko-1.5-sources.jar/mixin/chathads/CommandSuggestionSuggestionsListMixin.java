/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Share
 *  com.llamalad7.mixinextras.sugar.ref.LocalRef
 *  com.mojang.brigadier.suggestion.Suggestion
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.ChatInputSuggestor
 *  net.minecraft.client.gui.screen.ChatInputSuggestor$SuggestionWindow
 *  net.minecraft.client.network.ClientPlayNetworkHandler
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.client.util.math.Rect2i
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin.chathads;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.mojang.brigadier.suggestion.Suggestion;
import java.util.List;
import mods.chathads.ChatHeads;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4717;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_768;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4717.class_464.class})
public abstract class CommandSuggestionSuggestionsListMixin {
    @Shadow
    @Final
    private class_768 area;
    @Shadow
    @Final
    private List<Suggestion> suggestions;

    @ModifyVariable(method={"render"}, at=@At(value="HEAD"), argsOnly=true)
    public class_332 chatheads$captureGuiGraphics(class_332 guiGraphics, @Share(value="graphics") LocalRef<class_332> graphicsRef) {
        graphicsRef.set(guiGraphics);
        return guiGraphics;
    }

    @Inject(method={"<init>"}, at={@At(value="RETURN")})
    public void chatheads$fixOutOfBoundChatHeads(class_4717 commandSuggestions, int x, int y, int width, List<Suggestion> suggestions, boolean narrateFirstSuggestion, CallbackInfo ci) {
        class_634 connection = class_310.method_1551().method_1562();
        if (connection == null) {
            return;
        }
        if (this.area.method_3321() - (ChatHeads.headWidth(false) + 2) < 3) {
            for (Suggestion suggestion : this.suggestions) {
                class_640 playerInfo = connection.method_2874(suggestion.getText());
                if (playerInfo == null) continue;
                this.area.method_35779(3 + (ChatHeads.headWidth(false) + 2), this.area.method_3322());
                break;
            }
        }
    }

    @ModifyVariable(method={"render"}, at=@At(value="STORE"), ordinal=0)
    public Suggestion chatheads$captureSuggestion(Suggestion suggestion, @Share(value="player") LocalRef<class_640> playerRef) {
        class_634 connection = class_310.method_1551().method_1562();
        if (connection == null) {
            return suggestion;
        }
        playerRef.set(connection.method_2874(suggestion.getText()));
        return suggestion;
    }

    @ModifyArg(method={"render"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V", ordinal=4), index=0)
    public int chatheads$enlargeBackground(int x, @Share(value="player") LocalRef<class_640> playerRef) {
        if (playerRef.get() != null) {
            return x - (ChatHeads.headWidth(false) + 2);
        }
        return x;
    }

    @ModifyArg(method={"render"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)V", ordinal=0), index=3)
    public int chatheads$renderChatHead(int y, @Share(value="player") LocalRef<class_640> playerRef, @Share(value="graphics") LocalRef<class_332> graphicsRef) {
        int x = this.area.method_3321() - ChatHeads.headWidth(false);
        if (playerRef.get() != null) {
            ChatHeads.renderChatHead((class_332)graphicsRef.get(), x, y, (class_640)playerRef.get(), 1.0f, false);
        }
        return y;
    }
}

