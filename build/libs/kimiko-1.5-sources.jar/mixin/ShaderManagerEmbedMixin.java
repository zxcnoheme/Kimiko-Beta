/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gl.ShaderLoader
 *  net.minecraft.util.Identifier
 *  net.minecraft.resource.ResourcePack
 *  net.minecraft.resource.Resource
 *  net.minecraft.resource.ResourceManager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package mixin;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.class_10151;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rtx.kimiko.utils.render.shaders.EmbeddedShaders;

@Mixin(value={class_10151.class})
public abstract class ShaderManagerEmbedMixin {
    @Redirect(method={"prepare"}, at=@At(value="INVOKE", target="Lnet/minecraft/resource/ResourceManager;findResources(Ljava/lang/String;Ljava/util/function/Predicate;)Ljava/util/Map;"))
    private Map<class_2960, class_3298> kimiko$injectEmbeddedShaders(class_3300 manager, String path, Predicate<class_2960> filter) {
        Map resources = manager.method_14488(path, filter);
        if (EmbeddedShaders.SOURCES.isEmpty()) {
            return resources;
        }
        class_3262 pack = null;
        Iterator iterator = resources.values().iterator();
        if (iterator.hasNext()) {
            class_3298 resource = (class_3298)iterator.next();
            pack = resource.method_45304();
        }
        if (pack == null) {
            return resources;
        }
        HashMap<class_2960, class_3298> merged = new HashMap<class_2960, class_3298>(resources);
        for (Map.Entry<String, String> entry : EmbeddedShaders.SOURCES.entrySet()) {
            class_2960 id = class_2960.method_60655((String)"kimiko", (String)("shaders/" + entry.getKey()));
            byte[] bytes = entry.getValue().getBytes(StandardCharsets.UTF_8);
            merged.putIfAbsent(id, new class_3298(pack, () -> new ByteArrayInputStream(bytes)));
        }
        return merged;
    }
}

