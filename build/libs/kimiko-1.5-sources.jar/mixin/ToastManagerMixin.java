/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.toast.Toast
 *  net.minecraft.client.toast.SystemToast
 *  net.minecraft.client.toast.SystemToast$Type
 *  net.minecraft.client.toast.ToastManager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_368;
import net.minecraft.class_370;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_374.class})
public class ToastManagerMixin {
    @Inject(method={"add"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$dropUnsecureChatWarning(class_368 toast, CallbackInfo ci) {
        class_370 systemToast;
        if (toast instanceof class_370 && (systemToast = (class_370)toast).method_1989() == class_370.class_9037.field_47589) {
            ci.cancel();
        }
    }
}

