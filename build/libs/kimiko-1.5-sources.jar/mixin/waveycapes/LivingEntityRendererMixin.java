/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.LivingEntityRenderState
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.client.render.entity.feature.FeatureRenderer
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.render.entity.LivingEntityRenderer
 *  net.minecraft.client.render.entity.feature.CapeFeatureRenderer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin.waveycapes;

import mods.waveycapes.support.ModSupport;
import mods.waveycapes.support.SupportManager;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_3887;
import net.minecraft.class_583;
import net.minecraft.class_922;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_922.class})
public class LivingEntityRendererMixin<S extends class_1309, T extends class_10042, M extends class_583<? super T>> {
    @Inject(method={"addFeature"}, at={@At(value="HEAD")}, cancellable=true)
    private void addLayer(class_3887<T, M> renderLayer, CallbackInfoReturnable<Boolean> info) {
        if (renderLayer instanceof class_972) {
            info.cancel();
            return;
        }
        for (ModSupport support : SupportManager.getSupportedMods()) {
            if (!support.blockFeatureRenderer(renderLayer)) continue;
            info.cancel();
            return;
        }
    }
}

