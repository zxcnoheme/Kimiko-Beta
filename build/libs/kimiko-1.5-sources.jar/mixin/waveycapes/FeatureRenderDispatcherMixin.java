/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.command.RenderDispatcher
 *  org.spongepowered.asm.mixin.Mixin
 */
package mixin.waveycapes;

import net.minecraft.class_11684;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={class_11684.class})
public class FeatureRenderDispatcherMixin {
}

