/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.AssetInfo$TextureAssetInfo
 *  net.minecraft.util.AssetInfo$TextureAsset
 *  net.minecraft.util.Identifier
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.entity.player.SkinTextures
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin.waveycapes;

import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.Kimiko;
import rtx.kimiko.api.modules.impl.Visuals.Customization;
import rtx.kimiko.utils.render.others.cape.CapeGradient;

@Mixin(value={class_742.class})
public class CustomCapeMixin {
    @Unique
    private static final class_2960 KIMIKO_CAPE_ASSET_ID = class_2960.method_60655((String)Kimiko.namespace(), (String)"capes/cape");
    @Unique
    private static final class_2960 KIMIKO_CAPE_TEXTURE = class_2960.method_60655((String)Kimiko.namespace(), (String)"textures/capes/cape.png");
    @Unique
    private static final class_2960 VANILLA_ELYTRA_ASSET_ID = class_2960.method_60655((String)"minecraft", (String)"entity/equipment/wings/elytra");
    @Unique
    private static final class_2960 VANILLA_ELYTRA_TEXTURE = class_2960.method_60655((String)"minecraft", (String)"textures/entity/equipment/wings/elytra.png");
    @Unique
    private static final class_12079.class_12081 KIMIKO_CAPE_ASSET = new class_12079.class_10726(KIMIKO_CAPE_ASSET_ID, KIMIKO_CAPE_TEXTURE);
    @Unique
    private static final class_12079.class_12081 VANILLA_ELYTRA_ASSET = new class_12079.class_10726(VANILLA_ELYTRA_ASSET_ID, VANILLA_ELYTRA_TEXTURE);

    @Inject(method={"getSkin"}, at={@At(value="RETURN")}, cancellable=true)
    private void kimiko$replaceCape(CallbackInfoReturnable<class_8685> cir) {
        class_742 player = (class_742)(Object)this;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || !CustomCapeMixin.kimiko$shouldUseCustomCape(player, (class_742)client.field_1724)) {
            return;
        }
        Customization customization = Customization.getInstance();
        if (customization != null && customization.wingsEnabledFor(player)) {
            return;
        }
        CapeGradient.tick();
        class_8685 skin = (class_8685)cir.getReturnValue();
        cir.setReturnValue(new class_8685(skin.comp_1626(), CapeGradient.asset(), skin.comp_1628() == null ? VANILLA_ELYTRA_ASSET : skin.comp_1628(), skin.comp_1629(), skin.comp_1630()));
    }

    @Unique
    private static boolean kimiko$shouldUseCustomCape(class_742 player, class_742 localPlayer) {
        return player.method_5667().equals(localPlayer.method_5667());
    }
}

