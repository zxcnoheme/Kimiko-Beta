/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.client.Keyboard
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.screen.Screen
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.input.KeyPressEvent;
import rtx.kimiko.api.modules.ModuleManager;
import rtx.kimiko.api.modules.impl.Interface.ClickGui;
import rtx.kimiko.api.ui.UI;
import rtx.kimiko.api.voice.VoiceBindManager;
import rtx.kimiko.utils.sounds.Sounds;

@Mixin(value={class_309.class})
public abstract class KeyboardHandlerMixin {
    @Inject(method={"onKey"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$onKeyPress(long window, int action, class_11908 keyEvent, CallbackInfo ci) {
        KeyPressEvent event;
        if (action == 1) {
            VoiceBindManager.INSTANCE.noteInput();
            ClickGui clickGui = ModuleManager.get().get(ClickGui.class);
            if (clickGui != null && keyEvent.comp_4795() == clickGui.getBind().getCode()) {
                class_310 mc = class_310.method_1551();
                if (mc.field_1687 != null && mc.field_1724 != null && mc.field_1755 == null) {
                    mc.method_1507((class_437)UI.INSTANCE);
                    Sounds.play("gui_open");
                    ci.cancel();
                    return;
                }
            }
        }
        if ((event = EventBus.get().post(new KeyPressEvent(keyEvent.comp_4795(), keyEvent.comp_4796(), keyEvent.comp_4797(), KeyPressEvent.Action.of(action)))).isCancelled()) {
            ci.cancel();
        }
    }
}

