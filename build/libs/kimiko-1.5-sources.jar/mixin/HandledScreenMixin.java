/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.entity.player.PlayerInventory
 *  net.minecraft.screen.ScreenHandler
 *  net.minecraft.screen.slot.Slot
 *  net.minecraft.item.ItemStack
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.ingame.HandledScreen
 *  org.jetbrains.annotations.Nullable
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.events.EventBus;
import rtx.kimiko.api.events.impl.inventory.HandledScreenEvent;
import rtx.kimiko.api.invmanager.InventoryTemplates;
import rtx.kimiko.api.modules.impl.Visuals.BetterMinecraft;
import rtx.kimiko.api.modules.impl.Visuals.ItemHighlight;
import rtx.kimiko.utils.render.others.anim.ItemMoveAnimator;

@Mixin(value={class_465.class})
public abstract class HandledScreenMixin {
    @Shadow
    protected int x;
    @Shadow
    protected int y;
    @Shadow
    @Final
    protected int backgroundWidth;
    @Shadow
    @Final
    protected int backgroundHeight;
    @Shadow
    @Final
    protected class_1703 handler;
    @Shadow
    @Nullable
    protected class_1735 focusedSlot;
    @Unique
    private boolean kimiko$panelAnimated;
    @Unique
    private boolean kimiko$contentsAnimated;

    @Inject(method={"init"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$trackInventoryOpen(CallbackInfo ci) {
        BetterMinecraft.markInventoryOpen();
    }

    @Inject(method={"renderBackground"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/screen/Screen;renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V", shift=At.Shift.AFTER)}, require=0)
    private void kimiko$animatePanel(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        this.kimiko$panelAnimated = BetterMinecraft.inventoryAnimationEnabled();
        if (!this.kimiko$panelAnimated) {
            return;
        }
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(0.0f, BetterMinecraft.inventorySlideOffset());
    }

    @Inject(method={"renderBackground"}, at={@At(value="RETURN")}, require=0)
    private void kimiko$endPanelAnimation(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (!this.kimiko$panelAnimated) {
            return;
        }
        this.kimiko$panelAnimated = false;
        graphics.method_51448().popMatrix();
    }

    @Inject(method={"renderMain"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$beginContentsAnimation(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        this.kimiko$contentsAnimated = BetterMinecraft.inventoryAnimationEnabled();
        if (!this.kimiko$contentsAnimated) {
            return;
        }
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(0.0f, BetterMinecraft.inventorySlideOffset());
    }

    @Inject(method={"renderMain"}, at={@At(value="RETURN")}, require=0)
    private void kimiko$endContentsAnimation(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (this.kimiko$contentsAnimated) {
            this.kimiko$contentsAnimated = false;
            graphics.method_51448().popMatrix();
        }
        EventBus.get().post(new HandledScreenEvent(graphics, this.focusedSlot, this.backgroundWidth, this.backgroundHeight));
    }

    @Inject(method={"drawSlot"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$slotHighlightBackground(class_332 graphics, class_1735 slot, int mouseX, int mouseY, CallbackInfo ci) {
        if (slot == null || graphics == null) {
            return;
        }
        ItemHighlight module = ItemHighlight.getInstance();
        if (module == null) {
            return;
        }
        int argb = module.backgroundFor(slot.method_7677(), false);
        if (argb != 0) {
            module.drawSlotBackground(graphics, slot.field_7873, slot.field_7872, argb);
        }
    }

    @Inject(method={"drawSlots"}, at={@At(value="HEAD")}, require=0)
    private void kimiko$beginSlotAnim(class_332 graphics, int mouseX, int mouseY, CallbackInfo ci) {
        if (BetterMinecraft.itemMoveAnimationEnabled()) {
            ItemMoveAnimator.beginFrame(this.handler, mouseX, mouseY, this.x, this.y);
        }
    }

    @WrapOperation(method={"drawSlots"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/screen/ingame/HandledScreen;drawSlot(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/screen/slot/Slot;II)V")}, require=0)
    private void kimiko$animateSlot(class_465<?> instance, class_332 graphics, class_1735 slot, int mouseX, int mouseY, Operation<Void> original) {
        float[] off;
        float[] fArray = off = BetterMinecraft.itemMoveAnimationEnabled() ? ItemMoveAnimator.offset(slot) : null;
        if (off == null) {
            original.call(new Object[]{instance, graphics, slot, mouseX, mouseY});
            return;
        }
        graphics.method_51448().pushMatrix();
        if (off[2] != 1.0f) {
            float cx = (float)slot.field_7873 + 8.0f;
            float cy = (float)slot.field_7872 + 8.0f;
            graphics.method_51448().translate(cx, cy);
            graphics.method_51448().scale(off[2], off[2]);
            graphics.method_51448().translate(-cx, -cy);
        } else {
            graphics.method_51448().translate(off[0], off[1]);
        }
        original.call(new Object[]{instance, graphics, slot, mouseX, mouseY});
        graphics.method_51448().popMatrix();
    }

    @Inject(method={"drawSlots"}, at={@At(value="TAIL")}, require=0)
    private void kimiko$renderGhostSlots(class_332 graphics, int mouseX, int mouseY, CallbackInfo ci) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null) {
                return;
            }
            InventoryTemplates.Template template = InventoryTemplates.active();
            if (template == null) {
                return;
            }
            class_1661 inventory = mc.field_1724.method_31548();
            Map<String, Integer> missing = HandledScreenMixin.missingCounts(template, inventory);
            for (class_1735 slot : this.handler.field_7761) {
                class_1799 ghost;
                int missingCount;
                InventoryTemplates.Entry entry;
                if (slot.field_7871 != inventory || !slot.method_7682() || (entry = template.slots.get(slot.method_34266())) == null || !slot.method_7677().method_7960() || (missingCount = HandledScreenMixin.takeMissing(missing, entry)) <= 0 || (ghost = InventoryTemplates.stackFor(entry)).method_7960()) continue;
                graphics.method_51445(ghost, slot.field_7873, slot.field_7872);
                graphics.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + 16, slot.field_7872 + 16, -1198222184);
                HandledScreenMixin.drawMissingCount(graphics, missingCount, slot.field_7873, slot.field_7872);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static Map<String, Integer> missingCounts(InventoryTemplates.Template template, class_1661 inventory) {
        HashMap<String, Integer> result = new HashMap<String, Integer>();
        InventoryTemplates.missingFor(template, inventory).forEach((key, item) -> result.put((String)key, item.count));
        return result;
    }

    private static int takeMissing(Map<String, Integer> missing, InventoryTemplates.Entry entry) {
        String key = InventoryTemplates.entryLayoutKey(entry);
        int count = missing.getOrDefault(key, 0);
        int used = Math.min(count, entry.count());
        if (used > 0) {
            missing.put(key, count - used);
        }
        return used;
    }

    private static void drawMissingCount(class_332 graphics, int count, int x, int y) {
        if (count <= 1) {
            return;
        }
        String text = String.valueOf(count);
        class_327 font = class_310.method_1551().field_1772;
        graphics.method_51433(font, text, x + 17 - font.method_1727(text), y + 9, -4671304, true);
    }
}

