/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.option.ServerList
 *  net.minecraft.client.network.ServerInfo
 *  net.minecraft.client.network.ServerInfo$ServerType
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import java.util.Iterator;
import java.util.List;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.utils.network.PinnedServers;

@Mixin(value={class_641.class})
public abstract class ServerListPinnedServerMixin {
    @Shadow
    @Final
    private List<class_642> servers;
    @Shadow
    @Final
    private List<class_642> hiddenServers;

    @Inject(method={"loadFile"}, at={@At(value="RETURN")})
    private void kimiko$pinPartnerServers(CallbackInfo ci) {
        boolean ordered;
        int index;
        class_642 server;
        class_642[] pinned = new class_642[PinnedServers.ADDRESSES.length];
        boolean changed = false;
        Iterator<class_642> iterator = this.servers.iterator();
        while (iterator.hasNext()) {
            server = iterator.next();
            index = PinnedServers.indexOf(server.field_3761);
            if (index < 0) continue;
            if (pinned[index] == null) {
                pinned[index] = server;
                continue;
            }
            iterator.remove();
            changed = true;
        }
        iterator = this.hiddenServers.iterator();
        while (iterator.hasNext()) {
            server = iterator.next();
            index = PinnedServers.indexOf(server.field_3761);
            if (index < 0) continue;
            iterator.remove();
            if (pinned[index] == null) {
                pinned[index] = server;
            }
            changed = true;
        }
        for (int i = 0; i < pinned.length; ++i) {
            String name = PinnedServers.NAMES[i];
            String address = PinnedServers.ADDRESSES[i];
            if (pinned[i] == null) {
                pinned[i] = new class_642(name, address, class_642.class_8678.field_45611);
                changed = true;
            }
            if (name.equals(pinned[i].field_3752) && address.equals(pinned[i].field_3761)) continue;
            pinned[i].field_3752 = name;
            pinned[i].field_3761 = address;
            changed = true;
        }
        boolean bl = ordered = this.servers.size() >= pinned.length;
        if (ordered) {
            for (int i = 0; i < pinned.length; ++i) {
                if (this.servers.get(i) == pinned[i]) continue;
                ordered = false;
                break;
            }
        }
        if (!ordered) {
            for (class_642 server2 : pinned) {
                this.servers.remove(server2);
            }
            for (int i = pinned.length - 1; i >= 0; --i) {
                this.servers.addFirst(pinned[i]);
            }
            changed = true;
        }
        if (changed) {
            ((class_641)(Object)this).method_2987();
        }
    }

    @Inject(method={"add"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$preventDuplicate(class_642 server, boolean hidden, CallbackInfo ci) {
        int index = PinnedServers.indexOf(server.field_3761);
        if (index < 0) {
            return;
        }
        for (class_642 existing : this.servers) {
            if (PinnedServers.indexOf(existing.field_3761) != index) continue;
            ci.cancel();
            return;
        }
    }

    @Inject(method={"remove"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$preventRemoval(class_642 server, CallbackInfo ci) {
        if (PinnedServers.isPinned(server.field_3761)) {
            ci.cancel();
        }
    }

    @Inject(method={"swapEntries"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$preventMove(int first, int second, CallbackInfo ci) {
        if (PinnedServers.isPinned(this.servers.get((int)first).field_3761) || PinnedServers.isPinned(this.servers.get((int)second).field_3761)) {
            ci.cancel();
        }
    }

    @Inject(method={"set"}, at={@At(value="HEAD")}, cancellable=true)
    private void kimiko$preventEdit(int index, class_642 replacement, CallbackInfo ci) {
        if (PinnedServers.isPinned(this.servers.get((int)index).field_3761)) {
            ci.cancel();
        }
    }
}

