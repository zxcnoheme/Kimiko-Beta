/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.command.ModelCommandRenderer$CrumblingOverlayCommand
 *  net.minecraft.client.render.block.entity.state.BlockEntityRenderState
 *  net.minecraft.util.math.Position
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.block.entity.BlockEntity
 *  net.minecraft.client.render.block.entity.BlockEntityRenderManager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package mixin;

import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rtx.kimiko.api.modules.impl.Utils.Optimization;

@Mixin(value={class_824.class})
public abstract class OptimizationBlockEntityMixin {
    @Shadow
    private class_243 cameraPos;

    @Inject(method={"getRenderState"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private <E extends class_2586, S extends class_11954> void kimiko$cullDistantBlockEntities(E blockEntity, float partialTick, class_11683.class_11792 crumblingOverlay, CallbackInfoReturnable<S> cir) {
        if (this.cameraPos == null) {
            return;
        }
        double distSq = blockEntity.method_11016().method_19770((class_2374)this.cameraPos);
        if (!Optimization.allowBlockEntity(distSq)) {
            cir.setReturnValue(null);
        }
    }
}

