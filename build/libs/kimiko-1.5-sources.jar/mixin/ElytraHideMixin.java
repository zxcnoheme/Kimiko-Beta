/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.BipedEntityRenderState
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.entity.Entity
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.render.entity.feature.ElytraFeatureRenderer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package mixin;

import net.minecraft.class_10034;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_979;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rtx.kimiko.api.modules.impl.Visuals.Customization;

@Mixin(value={class_979.class})
public abstract class ElytraHideMixin {
    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void kimiko$hideElytra(class_4587 poseStack, class_11659 collector, int lightCoords, class_10034 state, float yRot, float xRot, CallbackInfo ci) {
        class_742 player;
        if (!(state instanceof class_10055)) {
            return;
        }
        class_10055 avatarState = (class_10055)state;
        Customization customization = Customization.getInstance();
        if (customization == null) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        class_1297 entity = mc.field_1687.method_8469(avatarState.field_53528);
        if (entity instanceof class_742 && customization.wingsEnabledFor(player = (class_742)entity)) {
            ci.cancel();
        }
    }
}

